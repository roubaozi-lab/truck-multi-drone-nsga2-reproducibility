# -*- coding: utf-8 -*-
"""
MOPSO parameter-configuration experiment for the truck--multi-drone model.

Design:
- Representative instance: Solomon r101, first 100 customers
- Fixed budget: swarm size 100, maximum 100 generations
- Taguchi L9(3^4):
    A. personal-best guidance probability
    B. archive-leader guidance probability
    C. random mutation probability
    D. external archive capacity
- Ten fixed random seeds: 4201--4210
- Selection score identical to Section 6.1:
    0.35 HV + 0.25 front size + 0.15 cost + 0.15 completion time + 0.10 delay

The script is resumable. Each completed run is saved immediately.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
import random
import sys
import time
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import pandas as pd

from precompute_inputs import ensure_precomputed

BASE_DIR = Path(__file__).resolve().parent
CORE_FILE = BASE_DIR / "heuristic_hpp_v29_fast.py"
SOLOMON_DIR = BASE_DIR / "solomon_data"
PRECOMP_DIR = BASE_DIR / "precomputed_inputs"
RESULTS_DIR = Path(os.environ.get("MOPSO_RESULTS_DIR", BASE_DIR / "results"))
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INSTANCE_FILE = "r101.txt"
N_CUSTOMERS = 100
FACILITY_SEED = 42
POP_SIZE = 100
N_GEN = 100
RUN_SEEDS = list(range(4201, 4211))
HV_REF = (1000.0, 50000.0, 100000.0)

# MOPSO-specific candidate levels. Population size and generation budget are
# intentionally fixed so that the later algorithm comparison remains fair.
PBEST_LEVELS = [0.20, 0.40, 0.60]
LEADER_LEVELS = [0.20, 0.40, 0.60]
MUTATION_LEVELS = [0.05, 0.10, 0.15]
ARCHIVE_LEVELS = [50, 100, 150]

# Taguchi L9(3^4), zero-based actual level indices.
# This is a level-permuted form of the standard L9 array. Orthogonality is
# unchanged, while Exp.1 becomes the current manuscript MOPSO setting:
# 0.40 / 0.40 / 0.10 / 100. This gives a direct incumbent reference.
L9 = [
    (1, 1, 1, 1),
    (1, 0, 0, 0),
    (1, 2, 2, 2),
    (0, 1, 0, 2),
    (0, 0, 2, 1),
    (0, 2, 1, 0),
    (2, 1, 2, 0),
    (2, 0, 1, 2),
    (2, 2, 0, 1),
]

RUNLEVEL_FILE = RESULTS_DIR / "MOPSO_Taguchi_RunLevel.csv"
SUMMARY_FILE = RESULTS_DIR / "MOPSO_Taguchi_Summary.csv"
BEST_FILE = RESULTS_DIR / "MOPSO_Taguchi_Best.json"
REPORT_FILE = RESULTS_DIR / "MOPSO_Taguchi_Report.txt"
DESIGN_FILE = RESULTS_DIR / "MOPSO_L9_Design.csv"


def load_core():
    spec = importlib.util.spec_from_file_location("mopso_core_v29", str(CORE_FILE))
    if spec is None or spec.loader is None:
        raise Exception(f"Cannot load core file: {CORE_FILE}")
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    return core


core = load_core()


def fleet_caps_override(n: int) -> Tuple[int, int]:
    # Same fleet setting used for N=100 in the manuscript experiments.
    if int(n) == 100:
        return 15, 5
    return min(15, max(1, int(math.ceil(int(n) / 10.0)))), 5


core.fleet_caps = fleet_caps_override


def build_design() -> pd.DataFrame:
    rows = []
    for exp_id, (a, b, c, d) in enumerate(L9, start=1):
        rows.append(
            {
                "ExpID": exp_id,
                "P_PBest": PBEST_LEVELS[a],
                "P_Leader": LEADER_LEVELS[b],
                "P_Mutation": MUTATION_LEVELS[c],
                "Archive_Capacity": ARCHIVE_LEVELS[d],
                "Population_Size": POP_SIZE,
                "Max_Generations": N_GEN,
            }
        )
    return pd.DataFrame(rows)


DESIGN_DF = build_design()
DESIGN_DF.to_csv(DESIGN_FILE, index=False)


def nondominated_subset(population, objectives):
    """Return only the first non-dominated front for metric calculation."""
    if not objectives:
        return [], []
    fronts = core.fast_nondominated_sort(core.normalize_objs(objectives))
    if not fronts or not fronts[0]:
        return [], []
    idx = fronts[0]
    return [population[i] for i in idx], [objectives[i] for i in idx]


def truncate_archive(population, objectives, capacity: int):
    """Use the same NSGA-II sorting/diversity rule as the manuscript MOPSO baseline."""
    if not population:
        return [], []
    capacity = max(1, int(capacity))
    k = min(capacity, len(population))
    return core.select_nsga2(population, objectives, k)


def run_discrete_mopso_param(
    seed_value: int,
    n_customers: int,
    p_pbest: float,
    p_leader: float,
    p_mutation: float,
    archive_capacity: int,
    pop_size: int = POP_SIZE,
    n_gen: int = N_GEN,
):
    """Parameterized version of the discrete archive-guided MOPSO baseline."""
    random.seed(int(seed_value))
    np.random.seed(int(seed_value))
    start_time = time.time()

    particles = core.init_population_random(int(pop_size), int(n_customers))
    objectives = [core.evaluate_individual(p) for p in particles]

    personal_best = [list(p) for p in particles]
    personal_best_objectives = list(objectives)

    front0 = core.fast_nondominated_sort(core.normalize_objs(objectives))[0]
    archive = [list(particles[i]) for i in front0]
    archive_objectives = [objectives[i] for i in front0]
    archive, archive_objectives = truncate_archive(
        archive, archive_objectives, int(archive_capacity)
    )

    history_cost = [min(o[0] for o in objectives)]
    convergence_gen = int(n_gen)

    for gen in range(int(n_gen)):
        updated_particles = []
        for i, original_particle in enumerate(particles):
            particle = list(original_particle)
            leader = random.choice(archive) if archive else personal_best[i]

            if random.random() < float(p_pbest):
                particle, _ = core.crossover(particle, personal_best[i])
            if random.random() < float(p_leader):
                particle, _ = core.crossover(particle, leader)
            if random.random() < float(p_mutation):
                particle, = core.random_mode_mutation(particle)

            updated_particles.append(core.repair_individual(particle))

        particles = updated_particles
        objectives = [core.evaluate_individual(p) for p in particles]

        for i in range(int(pop_size)):
            if core.dominates(objectives[i], personal_best_objectives[i]):
                personal_best[i] = list(particles[i])
                personal_best_objectives[i] = objectives[i]

        archive.extend([list(p) for p in particles])
        archive_objectives.extend(objectives)
        archive, archive_objectives = truncate_archive(
            archive, archive_objectives, int(archive_capacity)
        )

        history_cost.append(min(o[0] for o in archive_objectives))
        # Preserve the convergence rule used by the current MOPSO baseline.
        if gen >= 40 and convergence_gen == int(n_gen):
            if abs(history_cost[-1] - history_cost[-40]) < 0.05:
                convergence_gen = gen
                break

    pareto_front, pareto_objs = nondominated_subset(archive, archive_objectives)
    local_metric = time.time() - start_time
    return pareto_front, pareto_objs, local_metric, history_cost, convergence_gen


def compute_selection_score(summary_df: pd.DataFrame) -> pd.DataFrame:
    df = summary_df.copy()
    for col in ["HV_Mean", "Front_Size_Mean"]:
        mn, mx = df[col].min(), df[col].max()
        if abs(mx - mn) < 1e-12:
            df[col + "_Norm"] = 1.0
        else:
            df[col + "_Norm"] = (df[col] - mn) / (mx - mn)

    for col in ["Cost_Mean_Mean", "Time_Mean_Mean", "Pen_Mean_Mean"]:
        mn, mx = df[col].min(), df[col].max()
        if abs(mx - mn) < 1e-12:
            df[col + "_Norm"] = 1.0
        else:
            df[col + "_Norm"] = (mx - df[col]) / (mx - mn)

    df["Selection_Score"] = (
        0.35 * df["HV_Mean_Norm"]
        + 0.25 * df["Front_Size_Mean_Norm"]
        + 0.15 * df["Cost_Mean_Mean_Norm"]
        + 0.15 * df["Time_Mean_Mean_Norm"]
        + 0.10 * df["Pen_Mean_Mean_Norm"]
    )
    return df


def rebuild_summary(run_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for exp_id in sorted(run_df["ExpID"].unique()):
        sub = run_df[run_df["ExpID"] == exp_id]
        design = DESIGN_DF[DESIGN_DF["ExpID"] == exp_id].iloc[0]
        rows.append(
            {
                "ExpID": int(exp_id),
                "P_PBest": float(design["P_PBest"]),
                "P_Leader": float(design["P_Leader"]),
                "P_Mutation": float(design["P_Mutation"]),
                "Archive_Capacity": int(design["Archive_Capacity"]),
                "Runs_Completed": int(len(sub)),
                "HV_Best": sub["HV"].max(),
                "HV_Mean": sub["HV"].mean(),
                "HV_Std": sub["HV"].std(ddof=0),
                "Front_Size_Mean": sub["Front_Size"].mean(),
                "Front_Size_Std": sub["Front_Size"].std(ddof=0),
                "Cost_Mean_Mean": sub["Cost_Mean"].mean(),
                "Cost_Mean_Std": sub["Cost_Mean"].std(ddof=0),
                "Time_Mean_Mean": sub["Time_Mean"].mean(),
                "Time_Mean_Std": sub["Time_Mean"].std(ddof=0),
                "Pen_Mean_Mean": sub["Pen_Mean"].mean(),
                "Pen_Mean_Std": sub["Pen_Mean"].std(ddof=0),
                "LocalMetric_Mean": sub["LocalMetric"].mean(),
                "LocalMetric_Std": sub["LocalMetric"].std(ddof=0),
                "Conv_Gen_Mean": sub["Conv_Gen"].mean(),
            }
        )

    summary = pd.DataFrame(rows)
    # A fair final ranking is produced only when every L9 group has the same run count.
    if len(summary) == 9 and summary["Runs_Completed"].nunique() == 1:
        summary = compute_selection_score(summary)
        summary = summary.sort_values(
            ["Selection_Score", "HV_Mean"], ascending=[False, False]
        ).reset_index(drop=True)
    else:
        summary = summary.sort_values("ExpID").reset_index(drop=True)
    return summary


def write_report(summary: pd.DataFrame, expected_runs: int) -> None:
    lines = [
        "MOPSO Taguchi L9 parameter-configuration report",
        f"Instance: {INSTANCE_FILE}, N={N_CUSTOMERS}",
        f"Fixed population={POP_SIZE}, max generations={N_GEN}",
        f"Expected runs per group={expected_runs}",
        "Selection weights: HV 0.35; front size 0.25; cost 0.15; time 0.15; delay 0.10",
        "",
    ]
    if summary.empty:
        lines.append("No completed runs.")
    else:
        lines.append(summary.to_string(index=False))
        if "Selection_Score" in summary.columns and len(summary) == 9:
            best = summary.iloc[0]
            lines.extend(
                [
                    "",
                    "BEST CONFIGURATION AMONG THE TESTED L9 COMBINATIONS:",
                    f"ExpID={int(best['ExpID'])}",
                    f"P_PBest={best['P_PBest']}",
                    f"P_Leader={best['P_Leader']}",
                    f"P_Mutation={best['P_Mutation']}",
                    f"Archive_Capacity={int(best['Archive_Capacity'])}",
                    f"Selection_Score={best['Selection_Score']}",
                ]
            )
    REPORT_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_int_list(text: str) -> List[int]:
    values = []
    for part in text.split(","):
        part = part.strip()
        if part:
            values.append(int(part))
    return values


def main() -> None:
    parser = argparse.ArgumentParser(description="Run resumable MOPSO Taguchi L9 tuning.")
    parser.add_argument(
        "--mode",
        choices=["smoke", "full"],
        default="smoke",
        help="smoke: Exp.1/seed4201 only; full: all selected groups and seeds",
    )
    parser.add_argument(
        "--exp-ids",
        default="",
        help="Optional comma-separated ExpIDs, e.g. 1,2,3. Default: all 1-9 in full mode.",
    )
    parser.add_argument(
        "--seeds",
        default="",
        help="Optional comma-separated seeds. Default: 4201-4210 in full mode.",
    )
    parser.add_argument(
        "--restart",
        action="store_true",
        help="Delete prior run-level/summary output before starting.",
    )
    args = parser.parse_args()

    if args.restart:
        for path in [RUNLEVEL_FILE, SUMMARY_FILE, BEST_FILE, REPORT_FILE]:
            if path.exists():
                path.unlink()
    if args.mode == "smoke":
        exp_ids = [1] if not args.exp_ids else parse_int_list(args.exp_ids)
        seeds = [4201] if not args.seeds else parse_int_list(args.seeds)
    else:
        exp_ids = list(range(1, 10)) if not args.exp_ids else parse_int_list(args.exp_ids)
        seeds = RUN_SEEDS if not args.seeds else parse_int_list(args.seeds)

    invalid = [e for e in exp_ids if e < 1 or e > 9]
    if invalid:
        raise ValueError(f"Invalid ExpID(s): {invalid}; valid range is 1-9.")

    pre = ensure_precomputed(
        INSTANCE_FILE,
        N_CUSTOMERS,
        solomon_dir=SOLOMON_DIR,
        output_dir=PRECOMP_DIR,
        facility_seed=FACILITY_SEED,
        rebuild=False,
    )

    if RUNLEVEL_FILE.exists():
        run_df = pd.read_csv(RUNLEVEL_FILE)
    else:
        run_df = pd.DataFrame()

    completed = set()
    if not run_df.empty:
        completed = set(zip(run_df["ExpID"].astype(int), run_df["Seed"].astype(int)))

    total_requested = len(exp_ids) * len(seeds)
    pending = [(e, s) for e in exp_ids for s in seeds if (e, s) not in completed]
    print(f"Requested runs: {total_requested}; already completed: {total_requested - len(pending)}; pending: {len(pending)}")

    for counter, (exp_id, seed) in enumerate(pending, start=1):
        design = DESIGN_DF[DESIGN_DF["ExpID"] == exp_id].iloc[0]
        print(
            f"[{counter}/{len(pending)}] Exp={exp_id}, seed={seed}, "
            f"pbest={design['P_PBest']}, leader={design['P_Leader']}, "
            f"mutation={design['P_Mutation']}, archive={int(design['Archive_Capacity'])}",
            flush=True,
        )

        # Crucial: reset all instance-dependent global state and caches before every run.
        core.set_environment_from_precomputed(pre)

        pareto_front, pareto_objs, local_metric, _, conv_gen = run_discrete_mopso_param(
            seed_value=seed,
            n_customers=N_CUSTOMERS,
            p_pbest=float(design["P_PBest"]),
            p_leader=float(design["P_Leader"]),
            p_mutation=float(design["P_Mutation"]),
            archive_capacity=int(design["Archive_Capacity"]),
            pop_size=POP_SIZE,
            n_gen=N_GEN,
        )

        if not pareto_objs:
            raise Exception(f"Empty Pareto front for Exp={exp_id}, seed={seed}")

        row = core.build_run_row(
            N_CUSTOMERS,
            seed,
            "Discrete-MOPSO-Taguchi",
            pareto_front,
            pareto_objs,
            local_metric,
            conv_gen,
            HV_REF,
            "FULL",
            pen_cap=None,
        )
        row.update(
            {
                "Instance": INSTANCE_FILE,
                "ExpID": int(exp_id),
                "Seed": int(seed),
                "P_PBest": float(design["P_PBest"]),
                "P_Leader": float(design["P_Leader"]),
                "P_Mutation": float(design["P_Mutation"]),
                "Archive_Capacity": int(design["Archive_Capacity"]),
                "Population_Size": POP_SIZE,
                "Max_Generations": N_GEN,
                "Front_Size": len(pareto_objs),
            }
        )

        new_row_df = pd.DataFrame([row])
        if RUNLEVEL_FILE.exists():
            new_row_df.to_csv(RUNLEVEL_FILE, mode="a", header=False, index=False)
        else:
            new_row_df.to_csv(RUNLEVEL_FILE, index=False)

        run_df = pd.read_csv(RUNLEVEL_FILE)
        summary = rebuild_summary(run_df)
        summary.to_csv(SUMMARY_FILE, index=False)
        write_report(summary, expected_runs=len(seeds))

        if "Selection_Score" in summary.columns and len(summary) == 9:
            best = summary.iloc[0].to_dict()
            with open(BEST_FILE, "w", encoding="utf-8") as f:
                json.dump(best, f, ensure_ascii=False, indent=2, default=float)

        print(
            f"  done: front={len(pareto_objs)}, HV={row['HV']}, "
            f"cost_mean={row['Cost_Mean']}, time_mean={row['Time_Mean']}, "
            f"delay_mean={row['Pen_Mean']}, local_metric={local_metric:.3f}s",
            flush=True,
        )

    if RUNLEVEL_FILE.exists():
        run_df = pd.read_csv(RUNLEVEL_FILE)
        summary = rebuild_summary(run_df)
        summary.to_csv(SUMMARY_FILE, index=False)
        write_report(summary, expected_runs=len(seeds))
        print("\nCurrent summary:")
        print(summary.to_string(index=False))

    print(f"\nDesign: {DESIGN_FILE}")
    print(f"Run-level results: {RUNLEVEL_FILE}")
    print(f"Summary: {SUMMARY_FILE}")
    print(f"Report: {REPORT_FILE}")


if __name__ == "__main__":
    main()
