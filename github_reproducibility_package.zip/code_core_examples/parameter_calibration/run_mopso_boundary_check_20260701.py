# -*- coding: utf-8 -*-
"""
Lightweight boundary sensitivity check for the calibrated MOPSO baseline.

This is a supplementary check only. The formal MOPSO comparison has already
been rerun across all nine Solomon instances and 30 seeds per instance-scale
combination. Here we only test local boundary alternatives on r101, N=100.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
COMPARISON_SCRIPT = BASE_DIR.parent / "6.3算法性能，规模对比" / "校准后MOPSO对比" / "run_calibrated_mopso_table8.py"
RESULTS_DIR = BASE_DIR / "mopso_boundary_check_20260701"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

RUN_SEEDS = list(range(4201, 4211))
INSTANCE = "r101.txt"
N_CUSTOMERS = 100

RUNLEVEL_FILE = RESULTS_DIR / "MOPSO_Boundary_Check_RunLevel.csv"
SUMMARY_FILE = RESULTS_DIR / "MOPSO_Boundary_Check_Summary.csv"
DESIGN_FILE = RESULTS_DIR / "MOPSO_Boundary_Check_Design.csv"
REPORT_FILE = RESULTS_DIR / "MOPSO_Boundary_Check_Report.txt"


def load_module(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise Exception(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = load_module("mopso_calibrated_base_for_boundary", COMPARISON_SCRIPT)

CONFIGS = [
    {
        "ConfigID": "Current_Calibrated",
        "P_PBest": 0.20,
        "P_Leader": 0.60,
        "P_Mutation": 0.10,
        "Archive_Capacity": 50,
        "Note": "Selected calibrated MOPSO setting.",
    },
    {
        "ConfigID": "M1_PBest_0.10",
        "P_PBest": 0.10,
        "P_Leader": 0.60,
        "P_Mutation": 0.10,
        "Archive_Capacity": 50,
        "Note": "Lower-side local boundary check for P_PBest.",
    },
    {
        "ConfigID": "M2_Leader_0.70",
        "P_PBest": 0.20,
        "P_Leader": 0.70,
        "P_Mutation": 0.10,
        "Archive_Capacity": 50,
        "Note": "Upper-side local boundary check for P_Leader.",
    },
    {
        "ConfigID": "M3_Mutation_0.15",
        "P_PBest": 0.20,
        "P_Leader": 0.60,
        "P_Mutation": 0.15,
        "Archive_Capacity": 50,
        "Note": "Higher mutation local check.",
    },
    {
        "ConfigID": "M4_Archive_25",
        "P_PBest": 0.20,
        "P_Leader": 0.60,
        "P_Mutation": 0.10,
        "Archive_Capacity": 25,
        "Note": "Lower archive-capacity boundary check.",
    },
    {
        "ConfigID": "M5_Archive_75",
        "P_PBest": 0.20,
        "P_Leader": 0.60,
        "P_Mutation": 0.10,
        "Archive_Capacity": 75,
        "Note": "Near-boundary archive-capacity check.",
    },
]


def load_run_df() -> pd.DataFrame:
    if RUNLEVEL_FILE.exists():
        return pd.read_csv(RUNLEVEL_FILE)
    return pd.DataFrame()


def completed_keys(run_df: pd.DataFrame) -> set:
    if run_df.empty:
        return set()
    return set(zip(run_df["ConfigID"].astype(str), run_df["Run"].astype(int)))


def append_row(row: Dict) -> None:
    row_df = pd.DataFrame([row])
    if RUNLEVEL_FILE.exists():
        row_df.to_csv(RUNLEVEL_FILE, mode="a", header=False, index=False)
    else:
        row_df.to_csv(RUNLEVEL_FILE, index=False)


def compute_selection_score(summary_df: pd.DataFrame) -> pd.DataFrame:
    df = summary_df.copy()
    for col in ["HV_Mean", "Front_Size_Mean"]:
        mn, mx = df[col].min(), df[col].max()
        df[col + "_Norm"] = 1.0 if abs(mx - mn) < 1e-12 else (df[col] - mn) / (mx - mn)
    for col in ["Cost_Mean_Mean", "Time_Mean_Mean", "Pen_Mean_Mean"]:
        mn, mx = df[col].min(), df[col].max()
        df[col + "_Norm"] = 1.0 if abs(mx - mn) < 1e-12 else (mx - df[col]) / (mx - mn)
    df["Selection_Score"] = (
        0.35 * df["HV_Mean_Norm"]
        + 0.25 * df["Front_Size_Mean_Norm"]
        + 0.15 * df["Cost_Mean_Mean_Norm"]
        + 0.15 * df["Time_Mean_Mean_Norm"]
        + 0.10 * df["Pen_Mean_Mean_Norm"]
    )
    return df


def rebuild_summary() -> None:
    run_df = load_run_df()
    if run_df.empty:
        return
    if "Front_Size" not in run_df.columns and "Pareto_Count" in run_df.columns:
        run_df["Front_Size"] = run_df["Pareto_Count"]
    rows = []
    for config_id, sub in run_df.groupby("ConfigID", dropna=False):
        first = sub.iloc[0]
        rows.append(
            {
                "ConfigID": config_id,
                "P_PBest": float(first["P_PBest"]),
                "P_Leader": float(first["P_Leader"]),
                "P_Mutation": float(first["P_Mutation"]),
                "Archive_Capacity": int(first["Archive_Capacity"]),
                "Runs": int(len(sub)),
                "HV_Best": sub["HV"].max(),
                "HV_Mean": sub["HV"].mean(),
                "HV_Std": sub["HV"].std(ddof=0),
                "Front_Size_Mean": sub["Front_Size"].mean(),
                "Front_Size_Std": sub["Front_Size"].std(ddof=0),
                "Cost_Mean_Mean": sub["Cost_Mean"].mean(),
                "Time_Mean_Mean": sub["Time_Mean"].mean(),
                "Pen_Mean_Mean": sub["Pen_Mean"].mean(),
                "LocalMetric_Mean": sub["LocalMetric"].mean(),
                "LocalMetric_Std": sub["LocalMetric"].std(ddof=0),
            }
        )
    summary = compute_selection_score(pd.DataFrame(rows))
    summary = summary.sort_values(["Selection_Score", "HV_Mean"], ascending=[False, False])
    summary.to_csv(SUMMARY_FILE, index=False)
    lines = [
        "MOPSO Boundary Check",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        summary[
            [
                "ConfigID",
                "P_PBest",
                "P_Leader",
                "P_Mutation",
                "Archive_Capacity",
                "Runs",
                "HV_Mean",
                "Front_Size_Mean",
                "Cost_Mean_Mean",
                "Time_Mean_Mean",
                "Pen_Mean_Mean",
                "LocalMetric_Mean",
                "Selection_Score",
            ]
        ].to_string(index=False),
    ]
    REPORT_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def set_config(cfg: Dict) -> None:
    base.P_PBEST = float(cfg["P_PBest"])
    base.P_LEADER = float(cfg["P_Leader"])
    base.P_MUTATION = float(cfg["P_Mutation"])
    base.ARCHIVE_CAPACITY = int(cfg["Archive_Capacity"])


def run_one(cfg: Dict, seed: int, precomputed) -> Dict:
    set_config(cfg)
    base.core.set_environment_from_precomputed(precomputed)
    pareto_front, pareto_objs, local_metric, _, conv_gen = base.run_calibrated_mopso(seed, N_CUSTOMERS)
    if not pareto_objs:
        raise Exception(f"Empty Pareto front: {cfg['ConfigID']}, seed={seed}")
    row = base.core.build_run_row(
        N_CUSTOMERS,
        int(seed),
        "MOPSO_boundary_check",
        pareto_front,
        pareto_objs,
        local_metric,
        conv_gen,
        base.HV_REF,
        "BOUNDARY_CHECK",
        pen_cap=None,
    )
    row.update(
        {
            "Instance": INSTANCE,
            "ConfigID": cfg["ConfigID"],
            "P_PBest": float(cfg["P_PBest"]),
            "P_Leader": float(cfg["P_Leader"]),
            "P_Mutation": float(cfg["P_Mutation"]),
            "Archive_Capacity": int(cfg["Archive_Capacity"]),
        }
    )
    return row


def main() -> None:
    pd.DataFrame(CONFIGS).to_csv(DESIGN_FILE, index=False)

    precomputed = base.precompute.ensure_precomputed(
        INSTANCE,
        N_CUSTOMERS,
        solomon_dir=base.SOLOMON_DIR,
        output_dir=base.PRECOMP_DIR,
        facility_seed=base.FACILITY_SEED,
        rebuild=False,
    )

    run_df = load_run_df()
    done = completed_keys(run_df)
    tasks = [(cfg, seed) for cfg in CONFIGS for seed in RUN_SEEDS if (cfg["ConfigID"], int(seed)) not in done]
    print(f"Requested runs: {len(CONFIGS) * len(RUN_SEEDS)}; already completed: {len(CONFIGS) * len(RUN_SEEDS) - len(tasks)}; pending: {len(tasks)}")
    print(f"Results dir: {RESULTS_DIR}")

    for idx, (cfg, seed) in enumerate(tasks, start=1):
        print(f"[{idx}/{len(tasks)}] config={cfg['ConfigID']}, seed={seed}", flush=True)
        row = run_one(cfg, int(seed), precomputed)
        append_row(row)
        rebuild_summary()
        print(
            f"  done: HV={row['HV']:.6f}, front={row.get('Pareto_Count', '')}, "
            f"local_metric={row['LocalMetric']:.3f}s",
            flush=True,
        )

    rebuild_summary()
    print(f"Done. Summary: {SUMMARY_FILE}")


if __name__ == "__main__":
    main()
