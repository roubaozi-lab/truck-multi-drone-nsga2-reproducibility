# -*- coding: utf-8 -*-
"""
6.1 参数配置优化实验（针对 v29）
只跑 HPP-init-NSGA2，用 Taguchi L9 风格参数组合找当前最优配置。
与 heuristic_hpp_v29_synced.py、run_compare_batches_v29_fast.py 的环境、车队规模、
随机种子口径和 v29 主流程保持一致。
"""

import json
import math
import random
import re
import time
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

# ============================================================
# A. 配置区
# ============================================================
BASE_DIR = Path(__file__).resolve().parent
CORE_FILE = BASE_DIR / "heuristic_hpp_v29_synced.py"
SOLOMON_DIR = BASE_DIR / "solomon_data"
RESULTS_DIR = BASE_DIR / "Param_Config_v29"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INSTANCE_FILE = "r101.txt"
N_CUSTOMERS = 100
FACILITY_SEED = 42
RUN_SEEDS = list(range(4201, 4211))   # 10 runs

FLEET_BY_N = {
    100: (15, 5),
}

N_GEN = 100

# L9 参数水平
CX_LEVELS = [0.6, 0.7, 0.8]
MUT_LEVELS = [0.05, 0.10, 0.15]
POP_LEVELS = [60, 80, 100]
ELITE_RATIO_LEVELS = [0.05, 0.10, 0.15]

L9 = [
    (0, 0, 0, 0),
    (0, 1, 1, 1),
    (0, 2, 2, 2),
    (1, 0, 1, 2),
    (1, 1, 2, 0),
    (1, 2, 0, 1),
    (2, 0, 2, 1),
    (2, 1, 0, 2),
    (2, 2, 1, 0),
]

HV_REF = (1000.0, 50000.0, 100000.0)


# ============================================================
# B. 加载 core
# ============================================================
def load_core():
    spec = importlib.util.spec_from_file_location("core_v29", str(CORE_FILE))
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    return core


core = load_core()


# ============================================================
# C. 读取 Solomon txt 并写回 core
# ============================================================
def parse_solomon_txt(file_path):
    rows = []
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            nums = re.findall(r"-?\d+", line)
            if len(nums) >= 7:
                vals = list(map(int, nums[:7]))
                rows.append(vals)

    rows = sorted(rows, key=lambda r: r[0])
    depot = rows[0]
    customers = rows[1:]

    warehouse_xy = (depot[1] * 100.0, depot[2] * 100.0)
    positions = [(r[1] * 100.0, r[2] * 100.0) for r in customers]
    weights = [0] + [r[3] for r in customers]

    # 与当前启发式一致：Ready 统一为 0，Due * 10
    tw = [(0, depot[5] * 10)]
    tw.extend((0, r[5] * 10) for r in customers)
    return warehouse_xy, positions, weights, tw


def load_instance_into_core(instance_file):
    path = SOLOMON_DIR / instance_file
    warehouse_xy, positions, weights, tw = parse_solomon_txt(path)
    core.warehouse_position = warehouse_xy
    core.ORIGINAL_POSITIONS = positions
    core.ORIGINAL_WEIGHTS = weights
    core.ORIGINAL_TW = tw
    core.SEED = FACILITY_SEED


def fleet_caps_override(N):
    if N in FLEET_BY_N:
        return FLEET_BY_N[N]
    return (15, 5)


core.fleet_caps = fleet_caps_override


# ============================================================
# D. 参数化 evolve / run（按 v29 主流程）
# ============================================================
def evolve_one_generation_param(pop, objs, cx_pb, mut_pb_base, elite_ratio, use_elite=True, stagnated=False):
    if len(pop) < 2:
        return pop, objs, []
    elite_memory = []
    if use_elite:
        front = core.fast_nondominated_sort(core.normalize_objs(objs))[0]
        if front:
            dist = core.crowding_distance(front, objs)
            keep_n = max(1, int(math.ceil(len(front) * elite_ratio)))
            keep_idx = sorted(front, key=lambda i: -dist[i])[:keep_n]
            elite_pool = [core.repair_individual(list(pop[i])) for i in keep_idx]
            dedup = {}
            for ind in elite_pool:
                dedup[tuple(ind)] = ind
            elite_memory = list(dedup.values())[:100]

    offspring = []
    active_mut_pb = min(0.25, mut_pb_base * 3.0) if stagnated else mut_pb_base
    active_cx_pb = cx_pb

    while len(offspring) < len(pop):
        i, j = random.sample(range(len(pop)), 2)
        p1 = pop[i] if core.dominates(objs[i], objs[j]) else pop[j]
        i, j = random.sample(range(len(pop)), 2)
        p2 = pop[i] if core.dominates(objs[i], objs[j]) else pop[j]

        c1, c2 = list(p1), list(p2)

        if random.random() < active_cx_pb:
            if elite_memory and random.random() < 0.10:
                elite = random.choice(elite_memory)
                a, b = sorted(random.sample(range(len(c1)), 2))
                c1[a:b], c2[a:b] = elite[a:b], elite[a:b]
            else:
                c1, c2 = core.crossover(c1, c2)

        for c in [c1, c2]:
            if random.random() < active_mut_pb:
                if elite_memory and random.random() < 0.20:
                    elite = random.choice(elite_memory)
                    pos = random.randrange(len(c))
                    c[pos] = elite[pos]
                else:
                    if stagnated:
                        strategies = ['TW', 'ECO', 'R']
                        weights = [30, 50, 20]
                    else:
                        strategies = ['TW', 'ECO', 'R']
                        weights = [45, 40, 15]
                    choice = random.choices(strategies, weights=weights, k=1)[0]
                    if choice == 'TW':
                        c, = core.time_window_aware_mutation(c)
                    elif choice == 'ECO':
                        c, = core.economic_structure_mutation(c)
                    else:
                        c, = core.random_mode_mutation(c)

            offspring.append(core.repair_individual(c))

    off_objs = [core.evaluate_individual(ind) for ind in offspring]
    new_pop, new_objs = core.select_nsga2(pop + offspring, objs + off_objs, len(pop))
    return new_pop, new_objs, elite_memory




def refill_population(pop, objs, target_size, n_customers):
    """确保参数实验过程中种群规模始终不少于 2 且回补到目标规模。"""
    pop = list(pop)
    objs = list(objs)

    if len(pop) == 0:
        seed_pop = core.init_population_hpp(min(max(2, target_size), target_size), n_customers)
        pop.extend(seed_pop)
        objs.extend([core.evaluate_individual(ind) for ind in seed_pop])
    elif len(pop) == 1:
        clone = list(pop[0])
        try:
            clone = core.repair_individual(core.random_mode_mutation(clone)[0])
        except Exception:
            clone = core.init_population_random(1, n_customers)[0]
        pop.append(clone)
        objs.append(core.evaluate_individual(clone))

    while len(pop) < target_size:
        need = target_size - len(pop)
        fresh = core.init_population_random(need, n_customers)
        pop.extend(fresh)
        objs.extend([core.evaluate_individual(ind) for ind in fresh])

    if len(pop) > target_size:
        pop, objs = core.select_nsga2(pop, objs, target_size)

    return pop, objs


def run_hpp_param(seed_val, n_customers, cx_pb, mut_pb, pop_size, elite_ratio, n_gen=N_GEN):
    random.seed(seed_val)
    np.random.seed(seed_val)
    st = time.time()

    pop = core.init_population_hpp(pop_size, n_customers)
    objs = core.rebuild_penalty_maps(pop)
    pop, objs = refill_population(pop, objs, pop_size, n_customers)

    service_archive = []
    cost_archive = []
    cost_feasible_archive = []
    high_pen_streak = {}

    global_archive = []
    global_archive_objs = []
    global_archive, global_archive_objs = core.update_global_pareto_archive(global_archive, global_archive_objs, pop, objs, cap=180)

    stag_cnt = 0
    best_pen_hist = float('inf')
    history_cost = [min(o[0] for o in objs)]

    for gen in range(1, n_gen + 1):
        curr_min_pen = min(o[2] for o in objs)
        curr_min_time = min(o[1] for o in objs)

        if curr_min_pen > 0 and abs(curr_min_pen - best_pen_hist) < 1e-5:
            stag_cnt += 1
        else:
            stag_cnt, best_pen_hist = 0, curr_min_pen

        stagnated = stag_cnt >= 10

        pop, objs = refill_population(pop, objs, pop_size, n_customers)
        pop, objs, elite_memory = evolve_one_generation_param(
            pop, objs, cx_pb, mut_pb, elite_ratio, use_elite=True, stagnated=stagnated
        )
        objs = core.rebuild_penalty_maps(pop)

        has_zero_penalty = any(o[2] <= 1e-6 for o in objs)
        service_archive = core.update_service_archive(service_archive, pop, objs, cap=12)
        cost_archive = core.update_cost_archive(cost_archive, pop, objs, cap=12)
        cost_feasible_archive = core.update_cost_feasible_archive(cost_feasible_archive, pop, objs, cap=12, pen_cap=100.0)

        if service_archive and (cost_archive or cost_feasible_archive) and ((gen % 4 == 0) or stagnated):
            bridge_children = []
            cost_parent_pool = cost_feasible_archive if cost_feasible_archive else cost_archive
            for _ in range(2):
                cost_ind, _ = random.choice(cost_parent_pool[:min(6, len(cost_parent_pool))])
                service_ind, _ = random.choice(service_archive[:min(6, len(service_archive))])
                bridge_children.append(core.guided_bridge_recombine(cost_ind, service_ind))
            bridge_children = [core.repair_individual(ind) for ind in bridge_children]
            pop.extend(bridge_children)
            objs.extend([core.evaluate_individual(ind) for ind in bridge_children])

        if gen <= int(0.50 * n_gen) and ((gen % 4 == 0) or stagnated):
            exploratory_idx = sorted(range(len(objs)), key=lambda i: (objs[i][0], objs[i][2], objs[i][1]))[:max(3, pop_size // 20)]
            exploratory_children = []
            for wi in exploratory_idx[:3]:
                try:
                    if random.random() < 0.5:
                        exploratory_children.append(core.inter_cluster_exchange_mutation(list(pop[wi]), top_m=3)[0])
                    else:
                        exploratory_children.append(core.cooperative_block_mutation(list(pop[wi]), block_size=3)[0])
                except Exception:
                    pass
            if exploratory_children:
                exploratory_children = [core.repair_individual(ind) for ind in exploratory_children]
                pop.extend(exploratory_children)
                objs.extend([core.evaluate_individual(ind) for ind in exploratory_children])

        if not has_zero_penalty:
            direct_target, car_target = core.adaptive_air_quota(curr_min_pen, curr_min_time)

            near_feasible = sorted(range(len(objs)), key=lambda i: (objs[i][2], objs[i][1], objs[i][0]))[:max(3, pop_size // 16)]
            low_cost_infeasible = [i for i in range(len(objs)) if objs[i][2] > 0]
            low_cost_infeasible = sorted(low_cost_infeasible, key=lambda i: (objs[i][0], objs[i][2], objs[i][1]))[:max(3, pop_size // 16)]
            target_idx = sorted(set(near_feasible + low_cost_infeasible))[:6]

            if (gen % 4 == 0) or stagnated:
                for wi in target_idx:
                    old_ind = pop[wi]
                    old_obj = objs[wi]

                    best_ind, best_obj = core.direct_rescue_lns(old_ind, top_m=2)
                    if best_obj[2] <= 1e-6 and (best_obj[1], best_obj[0]) <= (old_obj[1], old_obj[0]):
                        pop[wi], objs[wi] = best_ind, best_obj
                        continue

                    candidates = [(old_ind, old_obj), (best_ind, best_obj)]
                    candidates.append(core.service_first_multimode_lns(old_ind, top_m=2, sweeps=1))
                    if old_obj[2] > 50 or stagnated:
                        candidates.append(core.force_air_quota_repair(old_ind, direct_target, car_target))
                    if gen % 6 == 0:
                        c_ind = core.economic_structure_mutation(list(old_ind))[0]
                        c_ind = core.repair_individual(c_ind)
                        candidates.append((c_ind, core.evaluate_individual(c_ind)))

                    best_ind, best_obj = min(candidates, key=lambda x: (x[1][2], x[1][1], x[1][0]))
                    if ((best_obj[2] < old_obj[2] - 1e-6) or
                        (abs(best_obj[2] - old_obj[2]) < 1e-6 and best_obj[1] < old_obj[1] - 1e-6) or
                        (abs(best_obj[2] - old_obj[2]) < 1e-6 and abs(best_obj[1] - old_obj[1]) < 1e-6 and best_obj[0] < old_obj[0] - 1e-6)):
                        pop[wi], objs[wi] = best_ind, best_obj

            if curr_min_pen <= 100 and ((gen % 3 == 0) or stagnated):
                near_zero_idx = sorted(
                    [i for i in range(len(objs)) if 0 < objs[i][2] <= 100],
                    key=lambda i: (objs[i][2], objs[i][1], objs[i][0])
                )[:max(2, pop_size // 20)]

                for wi in near_zero_idx:
                    old_ind = pop[wi]
                    old_obj = objs[wi]
                    new_ind, new_obj = core.last_mile_zero_penalty_repair(old_ind, pen_cap=100)
                    if (new_obj[2], new_obj[1], new_obj[0]) < (old_obj[2], old_obj[1], old_obj[0]):
                        pop[wi], objs[wi] = new_ind, new_obj
        else:
            zero_like = sorted([i for i in range(len(objs)) if objs[i][2] <= 1e-6], key=lambda i: (objs[i][0], objs[i][1]))[:max(3, pop_size // 18)]

            if (gen % 4 == 0) or stagnated:
                for wi in zero_like:
                    old_ind = pop[wi]
                    old_obj = objs[wi]
                    candidates = [(old_ind, old_obj)]
                    candidates.append(core.time_squeeze_lns(old_ind, sample_n=3))
                    candidates.append(core.cost_cleanup_lns(old_ind, sample_n=3))
                    best_ind, best_obj = min(candidates, key=lambda x: (x[1][2], x[1][0], x[1][1]))
                    if ((best_obj[2] < old_obj[2] - 1e-6) or
                        (abs(best_obj[2] - old_obj[2]) < 1e-6 and best_obj[1] < old_obj[1] - 1e-6) or
                        (abs(best_obj[2] - old_obj[2]) < 1e-6 and abs(best_obj[1] - old_obj[1]) < 1e-6 and best_obj[0] < old_obj[0] - 1e-6)):
                        pop[wi], objs[wi] = best_ind, best_obj

            residual_idx = sorted(
                [i for i in range(len(objs)) if 0 < objs[i][2] <= 100.0],
                key=lambda i: (objs[i][2], objs[i][1], objs[i][0])
            )[:max(2, pop_size // 24)]
            if residual_idx and ((gen % 5 == 0) or stagnated):
                for wi in residual_idx:
                    old_ind = pop[wi]
                    old_obj = objs[wi]
                    cand_ind, cand_obj = core.direct_rescue_lns(old_ind, top_m=2)
                    if (cand_obj[2], cand_obj[1], cand_obj[0]) < (old_obj[2], old_obj[1], old_obj[0]):
                        pop[wi], objs[wi] = cand_ind, cand_obj

            if (gen % 3 == 0) or stagnated:
                cost_focus_idx = sorted(
                    [i for i in range(len(objs)) if objs[i][2] <= 100.0],
                    key=lambda i: (objs[i][0], objs[i][2], objs[i][1])
                )[:max(3, pop_size // 18)]

                for wi in cost_focus_idx:
                    old_ind = pop[wi]
                    old_obj = objs[wi]
                    c1 = core.repair_individual(core.economic_structure_mutation(list(old_ind))[0])
                    c3, c3_obj = core.cost_cleanup_lns(old_ind, sample_n=4)
                    candidates = [
                        (old_ind, old_obj),
                        (c1, core.evaluate_individual(c1)),
                        (c3, c3_obj),
                    ]
                    if cost_feasible_archive and service_archive and gen % 6 == 0:
                        try:
                            base_ind, _ = random.choice(cost_feasible_archive[:min(4, len(cost_feasible_archive))])
                            srv_ind, _ = random.choice(service_archive[:min(4, len(service_archive))])
                            cb = core.repair_individual(core.guided_bridge_recombine(base_ind, srv_ind))
                            candidates.append((cb, core.evaluate_individual(cb)))
                        except Exception:
                            pass

                    def _cost_focus_rank(item):
                        obj = item[1]
                        return (0 if obj[2] <= 1e-6 else 1, min(obj[2], 100.0), obj[0], obj[1])

                    best_ind, best_obj = min(candidates, key=_cost_focus_rank)
                    if _cost_focus_rank((best_ind, best_obj)) < _cost_focus_rank((old_ind, old_obj)):
                        pop[wi], objs[wi] = best_ind, best_obj

        has_zero_penalty = any(o[2] <= 1e-6 for o in objs)
        service_archive = core.update_service_archive(service_archive, pop, objs, cap=12)
        cost_archive = core.update_cost_archive(cost_archive, pop, objs, cap=12)
        cost_feasible_archive = core.update_cost_feasible_archive(
            cost_feasible_archive, pop, objs, cap=12,
            pen_cap=(0.0 if has_zero_penalty else 100.0)
        )

        if gen >= int(0.70 * n_gen):
            best_pen_now = min(o[2] for o in objs)
            high_pen_streak = core.update_high_penalty_streak(high_pen_streak, pop, objs, best_pen_now)
            pop, objs = core.soft_filter_persistent_high_penalty(pop, objs, high_pen_streak, best_pen_now, keep_quota=2)

        uniq = {}
        for ind_i, obj_i in zip(pop, objs):
            key = tuple(ind_i)
            if key not in uniq or (obj_i[2], obj_i[1], obj_i[0]) < (uniq[key][1][2], uniq[key][1][1], uniq[key][1][0]):
                uniq[key] = (ind_i, obj_i)
        pop = [v[0] for v in uniq.values()]
        objs = [v[1] for v in uniq.values()]
        pop, objs = refill_population(pop, objs, max(2, min(pop_size, pop_size)), n_customers)

        pop, objs = core.structured_competitive_reselect(pop, objs, pop_size)
        objs = core.rebuild_penalty_maps(pop)
        pop, objs = refill_population(pop, objs, pop_size, n_customers)

        global_archive, global_archive_objs = core.update_global_pareto_archive(global_archive, global_archive_objs, pop, objs, cap=180)
        history_cost.append(min(o[0] for o in objs))

    return global_archive, global_archive_objs, time.time() - st, history_cost


# ============================================================
# E. 计算 summary
# ============================================================
def summarize_front(pareto_front, pareto_objs):
    curr_hv = core.hv.hypervolume(pareto_objs, HV_REF)
    return {
        "HV": curr_hv,
        "Front_Size": len(pareto_objs),
        "Cost_Min": min(o[0] for o in pareto_objs),
        "Time_Min": min(o[1] for o in pareto_objs),
        "Pen_Min": min(o[2] for o in pareto_objs),
        "Cost_Mean": float(np.mean([o[0] for o in pareto_objs])),
        "Time_Mean": float(np.mean([o[1] for o in pareto_objs])),
        "Pen_Mean": float(np.mean([o[2] for o in pareto_objs])),
    }


def compute_selection_score(df):
    score_df = df.copy()

    for col in ["HV_Mean", "Front_Size_Mean"]:
        mn, mx = score_df[col].min(), score_df[col].max()
        score_df[col + "_Norm"] = 1.0 if abs(mx - mn) < 1e-12 else (score_df[col] - mn) / (mx - mn)

    for col in ["Cost_Mean_Mean", "Time_Mean_Mean", "Pen_Mean_Mean"]:
        mn, mx = score_df[col].min(), score_df[col].max()
        score_df[col + "_Norm"] = 1.0 if abs(mx - mn) < 1e-12 else (mx - score_df[col]) / (mx - mn)

    score_df["Selection_Score"] = (
        0.35 * score_df["HV_Mean_Norm"] +
        0.25 * score_df["Front_Size_Mean_Norm"] +
        0.15 * score_df["Cost_Mean_Mean_Norm"] +
        0.15 * score_df["Time_Mean_Mean_Norm"] +
        0.10 * score_df["Pen_Mean_Mean_Norm"]
    )
    return score_df


# ============================================================
# F. 主流程
# ============================================================
def main():
    load_instance_into_core(INSTANCE_FILE)
    core.set_environment_for_N(N_CUSTOMERS)

    run_rows = []
    exp_defs = []

    for exp_id, (a, b, c, d) in enumerate(L9, start=1):
        cfg = {
            "ExpID": exp_id,
            "cx_pb": CX_LEVELS[a],
            "mut_pb": MUT_LEVELS[b],
            "pop_size": POP_LEVELS[c],
            "elite_ratio": ELITE_RATIO_LEVELS[d],
        }
        exp_defs.append(cfg)

    pd.DataFrame(exp_defs).to_csv(RESULTS_DIR / "ParamConfig_L9_Design.csv", index=False)

    for cfg in exp_defs:
        print(f"\n=== Exp {cfg['ExpID']} | cx={cfg['cx_pb']} mut={cfg['mut_pb']} pop={cfg['pop_size']} elite={cfg['elite_ratio']} ===")
        for seed in RUN_SEEDS:
            pareto_front, pareto_objs, rt, history_cost = run_hpp_param(
                seed, N_CUSTOMERS,
                cfg["cx_pb"], cfg["mut_pb"], cfg["pop_size"], cfg["elite_ratio"], n_gen=N_GEN
            )
            summ = summarize_front(pareto_front, pareto_objs)
            row = {
                "Instance": INSTANCE_FILE,
                "N": N_CUSTOMERS,
                "Seed": seed,
                **cfg,
                "LocalMetric": rt,
                **summ
            }
            run_rows.append(row)

    run_df = pd.DataFrame(run_rows)
    run_df.to_csv(RESULTS_DIR / "ParamConfig_RunLevel.csv", index=False)

    summary = []
    for exp_id, sub in run_df.groupby("ExpID"):
        cfg = sub.iloc[0]
        summary.append({
            "ExpID": int(exp_id),
            "cx_pb": cfg["cx_pb"],
            "mut_pb": cfg["mut_pb"],
            "pop_size": int(cfg["pop_size"]),
            "elite_ratio": cfg["elite_ratio"],
            "HV_Best": sub["HV"].max(),
            "HV_Mean": sub["HV"].mean(),
            "HV_Std": sub["HV"].std(ddof=0),
            "Front_Size_Mean": sub["Front_Size"].mean(),
            "Front_Size_Std": sub["Front_Size"].std(ddof=0),
            "Cost_Mean_Mean": sub["Cost_Mean"].mean(),
            "Time_Mean_Mean": sub["Time_Mean"].mean(),
            "Pen_Mean_Mean": sub["Pen_Mean"].mean(),
            "LocalMetric_Mean": sub["LocalMetric"].mean(),
            "LocalMetric_Std": sub["LocalMetric"].std(ddof=0),
        })

    summary_df = pd.DataFrame(summary)
    summary_df = compute_selection_score(summary_df)
    summary_df = summary_df.sort_values(["Selection_Score", "HV_Mean"], ascending=[False, False])
    summary_df.to_csv(RESULTS_DIR / "ParamConfig_Summary.csv", index=False)

    best_row = summary_df.iloc[0].to_dict()
    with open(RESULTS_DIR / "ParamConfig_Best.json", "w", encoding="utf-8") as f:
        json.dump(best_row, f, ensure_ascii=False, indent=2)

    print("\n✅ 参数配置实验完成。")
    print("最优组合：")
    print(best_row)


if __name__ == "__main__":
    main()
