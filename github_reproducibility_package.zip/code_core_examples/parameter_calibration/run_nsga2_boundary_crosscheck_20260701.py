# -*- coding: utf-8 -*-
"""
Additional parameter checks for Section 6.1.

Purpose:
1. Local boundary sensitivity check around the selected improved NSGA-II setting.
2. Cross-instance robustness check on clustered, random, and mixed Solomon cases.

This script only saves experiment results. It does not modify any manuscript file.
It is resumable: completed (phase, config, instance, seed) rows are skipped.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List

import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
BASE_SCRIPT = BASE_DIR / "run_param_config_v29_synced_fixed.py"
RESULTS_DIR = BASE_DIR / "nsga2_param_boundary_crosscheck_20260701"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

RUN_SEEDS = list(range(4201, 4211))
N_CUSTOMERS = 100
N_GEN = 100

RUNLEVEL_FILE = RESULTS_DIR / "NSGA2_Param_Check_RunLevel.csv"
BOUNDARY_SUMMARY_FILE = RESULTS_DIR / "NSGA2_Boundary_Summary.csv"
CROSS_BY_INSTANCE_FILE = RESULTS_DIR / "NSGA2_CrossInstance_ByInstance.csv"
CROSS_OVERALL_FILE = RESULTS_DIR / "NSGA2_CrossInstance_Overall.csv"
DESIGN_FILE = RESULTS_DIR / "NSGA2_Param_Check_Design.csv"
REPORT_FILE = RESULTS_DIR / "NSGA2_Param_Check_Report.txt"


def load_module(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise Exception(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


base = load_module("nsga2_param_base_20260701", BASE_SCRIPT)


SELECTED = {
    "ConfigID": "Current_Exp3",
    "ConfigRole": "selected",
    "Pc": 0.60,
    "Pm": 0.15,
    "Npop": 100,
    "ER": 0.15,
    "Note": "Selected setting in Table 5 / Section 6.1.",
}

BOUNDARY_CONFIGS = [
    SELECTED,
    {
        "ConfigID": "B1_Pc_0.50",
        "ConfigRole": "boundary",
        "Pc": 0.50,
        "Pm": 0.15,
        "Npop": 100,
        "ER": 0.15,
        "Note": "Lower-side boundary extension for Pc.",
    },
    {
        "ConfigID": "B2_Pc_0.70",
        "ConfigRole": "local_neighbor",
        "Pc": 0.70,
        "Pm": 0.15,
        "Npop": 100,
        "ER": 0.15,
        "Note": "One-factor local check for a higher Pc with other selected settings fixed.",
    },
    {
        "ConfigID": "B3_Pm_0.20",
        "ConfigRole": "boundary",
        "Pc": 0.60,
        "Pm": 0.20,
        "Npop": 100,
        "ER": 0.15,
        "Note": "Upper-side boundary extension for Pm.",
    },
    {
        "ConfigID": "B4_Npop_120",
        "ConfigRole": "budget_extension",
        "Pc": 0.60,
        "Pm": 0.15,
        "Npop": 120,
        "ER": 0.15,
        "Note": "Moderate population-size extension.",
    },
    {
        "ConfigID": "B5_Npop_150",
        "ConfigRole": "budget_extension",
        "Pc": 0.60,
        "Pm": 0.15,
        "Npop": 150,
        "ER": 0.15,
        "Note": "Larger population-size extension; changes computational budget.",
    },
    {
        "ConfigID": "B6_ER_0.20",
        "ConfigRole": "boundary",
        "Pc": 0.60,
        "Pm": 0.15,
        "Npop": 100,
        "ER": 0.20,
        "Note": "Upper-side boundary extension for elite retention ratio.",
    },
]

L9_REFERENCE_CONFIGS = [
    SELECTED,
    {
        "ConfigID": "L9_Exp5",
        "ConfigRole": "l9_second",
        "Pc": 0.70,
        "Pm": 0.10,
        "Npop": 100,
        "ER": 0.05,
        "Note": "Second-ranked original L9 setting by Table 5 score.",
    },
    {
        "ConfigID": "L9_Exp4",
        "ConfigRole": "l9_third",
        "Pc": 0.70,
        "Pm": 0.05,
        "Npop": 80,
        "ER": 0.15,
        "Note": "Third-ranked original L9 setting by Table 5 score.",
    },
]

BOUNDARY_INSTANCE = "r101.txt"
CROSS_INSTANCES = ["c101.txt", "r101.txt", "rc101.txt"]


def base_row(phase: str, instance: str, cfg: Dict, seed: int) -> Dict:
    return {
        "Phase": phase,
        "Instance": instance,
        "N": N_CUSTOMERS,
        "Seed": int(seed),
        "ConfigID": cfg["ConfigID"],
        "ConfigRole": cfg["ConfigRole"],
        "Pc": float(cfg["Pc"]),
        "Pm": float(cfg["Pm"]),
        "Npop": int(cfg["Npop"]),
        "ER": float(cfg["ER"]),
        "Gmax": N_GEN,
    }


def load_run_df() -> pd.DataFrame:
    if RUNLEVEL_FILE.exists():
        return pd.read_csv(RUNLEVEL_FILE)
    return pd.DataFrame()


def completed_keys(run_df: pd.DataFrame) -> set:
    if run_df.empty:
        return set()
    return set(
        zip(
            run_df["Phase"].astype(str),
            run_df["ConfigID"].astype(str),
            run_df["Instance"].astype(str),
            run_df["Seed"].astype(int),
        )
    )


def append_run(row: Dict) -> None:
    row_df = pd.DataFrame([row])
    if RUNLEVEL_FILE.exists():
        row_df.to_csv(RUNLEVEL_FILE, mode="a", header=False, index=False)
    else:
        row_df.to_csv(RUNLEVEL_FILE, index=False)


def summarize_grouped(run_df: pd.DataFrame, group_cols: List[str]) -> pd.DataFrame:
    rows = []
    for key, sub in run_df.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)
        item = dict(zip(group_cols, key))
        first = sub.iloc[0]
        item.update(
            {
                "Runs": int(len(sub)),
                "Pc": float(first["Pc"]),
                "Pm": float(first["Pm"]),
                "Npop": int(first["Npop"]),
                "ER": float(first["ER"]),
                "HV_Best": sub["HV"].max(),
                "HV_Mean": sub["HV"].mean(),
                "HV_Std": sub["HV"].std(ddof=0),
                "Front_Size_Mean": sub["Front_Size"].mean(),
                "Front_Size_Std": sub["Front_Size"].std(ddof=0),
                "Cost_Mean_Mean": sub["Cost_Mean"].mean(),
                "Time_Mean_Mean": sub["Time_Mean"].mean(),
                "Pen_Mean_Mean": sub["Pen_Mean"].mean(),
                "LocalMetric_Mean": sub["LocalMetric"].mean(),
                "LocalMetric_Std": sub["LocalMetric"].std(ddof=0),
            }
        )
        rows.append(item)
    return pd.DataFrame(rows)


def score_summary(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    return base.compute_selection_score(df)


def rebuild_summaries() -> None:
    run_df = load_run_df()
    if run_df.empty:
        return

    boundary = run_df[run_df["Phase"] == "boundary"].copy()
    if not boundary.empty:
        boundary_summary = summarize_grouped(boundary, ["Phase", "ConfigID"])
        boundary_summary = score_summary(boundary_summary)
        boundary_summary = boundary_summary.sort_values(
            ["Selection_Score", "HV_Mean"], ascending=[False, False]
        )
        boundary_summary.to_csv(BOUNDARY_SUMMARY_FILE, index=False)

    cross = run_df[run_df["Phase"] == "cross_instance"].copy()
    if not cross.empty:
        scored_parts = []
        for inst, sub in cross.groupby("Instance", dropna=False):
            inst_summary = summarize_grouped(sub, ["Phase", "Instance", "ConfigID"])
            inst_summary = score_summary(inst_summary)
            scored_parts.append(inst_summary)
        by_instance = pd.concat(scored_parts, ignore_index=True)
        by_instance = by_instance.sort_values(
            ["Instance", "Selection_Score", "HV_Mean"],
            ascending=[True, False, False],
        )
        by_instance.to_csv(CROSS_BY_INSTANCE_FILE, index=False)

        overall = summarize_grouped(cross, ["Phase", "ConfigID"])
        score_avg = (
            by_instance.groupby("ConfigID", dropna=False)["Selection_Score"]
            .mean()
            .rename("Mean_Instance_Selection_Score")
            .reset_index()
        )
        overall = overall.merge(score_avg, on="ConfigID", how="left")
        overall = overall.sort_values(
            ["Mean_Instance_Selection_Score", "HV_Mean"],
            ascending=[False, False],
        )
        overall.to_csv(CROSS_OVERALL_FILE, index=False)

    write_report()


def write_design(cross_configs: Iterable[Dict]) -> None:
    rows = []
    for phase, instance, configs in [
        ("boundary", BOUNDARY_INSTANCE, BOUNDARY_CONFIGS),
        ("cross_instance", ",".join(CROSS_INSTANCES), list(cross_configs)),
    ]:
        for cfg in configs:
            row = dict(cfg)
            row["Phase"] = phase
            row["Instance"] = instance
            row["N"] = N_CUSTOMERS
            row["Seeds"] = f"{RUN_SEEDS[0]}-{RUN_SEEDS[-1]}"
            rows.append(row)
    pd.DataFrame(rows).to_csv(DESIGN_FILE, index=False)


def choose_boundary_best_for_cross() -> Dict | None:
    if not BOUNDARY_SUMMARY_FILE.exists():
        return None
    summary = pd.read_csv(BOUNDARY_SUMMARY_FILE)
    if summary.empty:
        return None
    non_current = summary[summary["ConfigID"] != SELECTED["ConfigID"]]
    if non_current.empty:
        return None
    best_id = str(non_current.iloc[0]["ConfigID"])
    for cfg in BOUNDARY_CONFIGS:
        if cfg["ConfigID"] == best_id:
            picked = dict(cfg)
            picked["ConfigRole"] = "best_boundary_from_r101"
            picked["Note"] = "Best non-current boundary setting from r101 boundary check."
            return picked
    return None


def run_one(phase: str, instance: str, cfg: Dict, seed: int) -> Dict:
    base.load_instance_into_core(instance)
    base.core.set_environment_for_N(N_CUSTOMERS)
    pareto_front, pareto_objs, local_metric, _ = base.run_hpp_param(
        int(seed),
        N_CUSTOMERS,
        float(cfg["Pc"]),
        float(cfg["Pm"]),
        int(cfg["Npop"]),
        float(cfg["ER"]),
        n_gen=N_GEN,
    )
    if not pareto_objs:
        raise Exception(f"Empty Pareto front: {phase}, {instance}, {cfg['ConfigID']}, seed={seed}")
    row = base_row(phase, instance, cfg, seed)
    row.update({"LocalMetric": local_metric})
    row.update(base.summarize_front(pareto_front, pareto_objs))
    return row


def run_tasks(tasks: List[tuple]) -> None:
    run_df = load_run_df()
    done = completed_keys(run_df)
    pending = [t for t in tasks if (t[0], t[2]["ConfigID"], t[1], int(t[3])) not in done]
    print(f"Requested tasks: {len(tasks)}; already completed: {len(tasks)-len(pending)}; pending: {len(pending)}")
    print(f"Results dir: {RESULTS_DIR}")

    for idx, (phase, instance, cfg, seed) in enumerate(pending, start=1):
        print(
            f"[{idx}/{len(pending)}] phase={phase}, instance={instance}, "
            f"config={cfg['ConfigID']}, seed={seed}",
            flush=True,
        )
        row = run_one(phase, instance, cfg, seed)
        append_run(row)
        rebuild_summaries()
        print(
            f"  done: HV={row['HV']:.6f}, front={row['Front_Size']}, "
            f"cost_mean={row['Cost_Mean']:.4f}, time_mean={row['Time_Mean']:.4f}, "
            f"pen_mean={row['Pen_Mean']:.4f}, local_metric={row['LocalMetric']:.3f}s",
            flush=True,
        )


def write_report() -> None:
    lines = [
        "NSGA-II Parameter Boundary and Cross-Instance Check",
        f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "Boundary summary:",
    ]
    if BOUNDARY_SUMMARY_FILE.exists():
        b = pd.read_csv(BOUNDARY_SUMMARY_FILE)
        cols = [
            "ConfigID",
            "Pc",
            "Pm",
            "Npop",
            "ER",
            "Runs",
            "HV_Mean",
            "Front_Size_Mean",
            "Cost_Mean_Mean",
            "Time_Mean_Mean",
            "Pen_Mean_Mean",
            "LocalMetric_Mean",
            "Selection_Score",
        ]
        lines.append(b[[c for c in cols if c in b.columns]].to_string(index=False))
    else:
        lines.append("(not available yet)")

    lines.extend(["", "Cross-instance overall summary:"])
    if CROSS_OVERALL_FILE.exists():
        c = pd.read_csv(CROSS_OVERALL_FILE)
        cols = [
            "ConfigID",
            "Pc",
            "Pm",
            "Npop",
            "ER",
            "Runs",
            "HV_Mean",
            "Front_Size_Mean",
            "Cost_Mean_Mean",
            "Time_Mean_Mean",
            "Pen_Mean_Mean",
            "LocalMetric_Mean",
            "Mean_Instance_Selection_Score",
        ]
        lines.append(c[[x for x in cols if x in c.columns]].to_string(index=False))
    else:
        lines.append("(not available yet)")
    REPORT_FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    boundary_tasks = [
        ("boundary", BOUNDARY_INSTANCE, cfg, seed)
        for cfg in BOUNDARY_CONFIGS
        for seed in RUN_SEEDS
    ]
    run_tasks(boundary_tasks)

    boundary_best = choose_boundary_best_for_cross()
    cross_configs = list(L9_REFERENCE_CONFIGS)
    if boundary_best and all(c["ConfigID"] != boundary_best["ConfigID"] for c in cross_configs):
        cross_configs.append(boundary_best)

    write_design(cross_configs)

    cross_tasks = [
        ("cross_instance", inst, cfg, seed)
        for inst in CROSS_INSTANCES
        for cfg in cross_configs
        for seed in RUN_SEEDS
    ]
    run_tasks(cross_tasks)
    rebuild_summaries()
    print(f"\nDone. Report: {REPORT_FILE}")


if __name__ == "__main__":
    main()
