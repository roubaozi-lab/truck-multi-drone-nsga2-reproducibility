# -*- coding: utf-8 -*-
"""
Rerun the Table 8 MOPSO baseline with the calibrated MOPSO parameters.

Calibration selected by the L9 experiment:
    P_PBest = 0.20
    P_Leader = 0.60
    P_Mutation = 0.10
    Archive_Capacity = 50

The script is resumable. It saves run-level and summary CSV files after each
completed run.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
import random
import sys
import time
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd


BASE_DIR = Path(__file__).resolve().parent
REVIEW_DIR = BASE_DIR.parents[1]
TUNING_DIR = REVIEW_DIR / "6.1算法最优配置" / "mopso_taguchi_tuning"
CORE_FILE = TUNING_DIR / "heuristic_hpp_v29_fast.py"
PRECOMPUTE_FILE = TUNING_DIR / "precompute_inputs.py"
SOLOMON_DIR = REVIEW_DIR / "6.3算法性能，规模对比" / "gurobi和改进做对比" / "solomon_data"
PRECOMP_DIR = BASE_DIR / "precomputed_inputs"
RESULTS_DIR = BASE_DIR / "results_calibrated_mopso"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INSTANCE_FILES = [
    "c101.txt", "c102.txt", "c103.txt",
    "r101.txt", "r102.txt", "r103.txt",
    "rc101.txt", "rc102.txt", "rc103.txt",
]
N_LIST = [50, 100]
RUN_SEEDS = list(range(4201, 4231))
FACILITY_SEED = 42
FLEET_BY_N = {
    50: (8, 3),
    100: (15, 5),
}

POP_SIZE = 100
N_GEN = 100
HV_REF = (1000.0, 50000.0, 100000.0)

P_PBEST = 0.20
P_LEADER = 0.60
P_MUTATION = 0.10
ARCHIVE_CAPACITY = 50

ALGO_NAME = "MOPSO"

RUNLEVEL_FILE = RESULTS_DIR / "Calibrated_MOPSO_RunLevel.csv"
SUMMARY_BY_N_FILE = RESULTS_DIR / "Calibrated_MOPSO_Table8_ByN.csv"
SUMMARY_BY_INSTANCE_FILE = RESULTS_DIR / "Calibrated_MOPSO_ByInstance.csv"
BEST_CONFIG_FILE = RESULTS_DIR / "Calibrated_MOPSO_Config.json"


def load_module(module_name: str, path: Path):
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise Exception(f"Cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


core = load_module("heuristic_hpp_v29_fast_calibrated_mopso", CORE_FILE)
precompute = load_module("precompute_inputs_calibrated_mopso", PRECOMPUTE_FILE)


def fleet_caps_override(n: int) -> Tuple[int, int]:
    n = int(n)
    if n in FLEET_BY_N:
        return FLEET_BY_N[n]
    return min(15, max(1, int(math.ceil(n / 10.0)))), 5


core.fleet_caps = fleet_caps_override


def nondominated_subset(population, objectives):
    if not objectives:
        return [], []
    fronts = core.fast_nondominated_sort(core.normalize_objs(objectives))
    if not fronts or not fronts[0]:
        return [], []
    idx = fronts[0]
    return [population[i] for i in idx], [objectives[i] for i in idx]


def truncate_archive(population, objectives, capacity: int):
    if not population:
        return [], []
    k = min(max(1, int(capacity)), len(population))
    return core.select_nsga2(population, objectives, k)


def run_calibrated_mopso(seed_value: int, n_customers: int):
    random.seed(int(seed_value))
    np.random.seed(int(seed_value))
    start_time = time.time()

    particles = core.init_population_random(int(POP_SIZE), int(n_customers))
    objectives = [core.evaluate_individual(p) for p in particles]

    personal_best = [list(p) for p in particles]
    personal_best_objectives = list(objectives)

    front0 = core.fast_nondominated_sort(core.normalize_objs(objectives))[0]
    archive = [list(particles[i]) for i in front0]
    archive_objectives = [objectives[i] for i in front0]
    archive, archive_objectives = truncate_archive(
        archive, archive_objectives, ARCHIVE_CAPACITY
    )

    history_cost = [min(o[0] for o in objectives)]
    convergence_gen = int(N_GEN)

    for gen in range(int(N_GEN)):
        updated_particles = []
        for i, original_particle in enumerate(particles):
            particle = list(original_particle)
            leader = random.choice(archive) if archive else personal_best[i]

            if random.random() < P_PBEST:
                particle, _ = core.crossover(particle, personal_best[i])
            if random.random() < P_LEADER:
                particle, _ = core.crossover(particle, leader)
            if random.random() < P_MUTATION:
                particle, = core.random_mode_mutation(particle)

            updated_particles.append(core.repair_individual(particle))

        particles = updated_particles
        objectives = [core.evaluate_individual(p) for p in particles]

        for i in range(int(POP_SIZE)):
            if core.dominates(objectives[i], personal_best_objectives[i]):
                personal_best[i] = list(particles[i])
                personal_best_objectives[i] = objectives[i]

        archive.extend([list(p) for p in particles])
        archive_objectives.extend(objectives)
        archive, archive_objectives = truncate_archive(
            archive, archive_objectives, ARCHIVE_CAPACITY
        )

        history_cost.append(min(o[0] for o in archive_objectives))
        if gen >= 40 and convergence_gen == int(N_GEN):
            if abs(history_cost[-1] - history_cost[-40]) < 0.05:
                convergence_gen = gen
                break

    pareto_front, pareto_objs = nondominated_subset(archive, archive_objectives)
    local_metric = time.time() - start_time
    return pareto_front, pareto_objs, local_metric, history_cost, convergence_gen


def parse_int_list(text: str) -> List[int]:
    values = []
    for part in text.split(","):
        part = part.strip()
        if part:
            values.append(int(part))
    return values


def parse_str_list(text: str) -> List[str]:
    return [part.strip() for part in text.split(",") if part.strip()]


def write_config() -> None:
    config = {
        "algorithm": ALGO_NAME,
        "p_pbest": P_PBEST,
        "p_leader": P_LEADER,
        "p_mutation": P_MUTATION,
        "archive_capacity": ARCHIVE_CAPACITY,
        "population_size": POP_SIZE,
        "max_generations": N_GEN,
        "instances": INSTANCE_FILES,
        "n_list": N_LIST,
        "seeds": RUN_SEEDS,
        "facility_seed": FACILITY_SEED,
        "fleet_by_n": FLEET_BY_N,
        "hv_ref": HV_REF,
    }
    BEST_CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")


def load_run_df() -> pd.DataFrame:
    if RUNLEVEL_FILE.exists():
        return pd.read_csv(RUNLEVEL_FILE)
    return pd.DataFrame()


def completed_keys(run_df: pd.DataFrame):
    if run_df.empty:
        return set()
    return set(
        zip(
            run_df["Instance"].astype(str),
            run_df["N"].astype(int),
            run_df["Run"].astype(int),
        )
    )


def rebuild_summaries() -> None:
    run_df = load_run_df()
    if run_df.empty:
        return

    by_instance_rows = []
    for (inst, n), sub in run_df.groupby(["Instance", "N"], dropna=False):
        by_instance_rows.append({
            "Instance": inst,
            "N": int(n),
            "Algorithm": ALGO_NAME,
            "Runs": int(len(sub)),
            "HV_Mean": round(sub["HV"].mean(), 6),
            "HV_Std": round(sub["HV"].std(ddof=0), 6),
            "LocalMetric_Mean": round(sub["LocalMetric"].mean(), 6),
            "LocalMetric_Std": round(sub["LocalMetric"].std(ddof=0), 6),
            "Cost_Min_Mean": round(sub["Cost_Min"].mean(), 6),
            "Cost_Min_Std": round(sub["Cost_Min"].std(ddof=0), 6),
            "Time_Min_Mean": round(sub["Time_Min"].mean(), 6),
            "Time_Min_Std": round(sub["Time_Min"].std(ddof=0), 6),
            "Pen_Min_Mean": round(sub["Pen_Min"].mean(), 6),
            "Pen_Min_Std": round(sub["Pen_Min"].std(ddof=0), 6),
            "ZeroPenalty_Ratio_Mean": round(sub["ZeroPenalty_Ratio"].mean(), 6),
        })
    pd.DataFrame(by_instance_rows).sort_values(["N", "Instance"]).to_csv(
        SUMMARY_BY_INSTANCE_FILE, index=False
    )

    by_n_rows = []
    for n, sub in run_df.groupby("N", dropna=False):
        by_n_rows.append({
            "N": int(n),
            "Algorithm": ALGO_NAME,
            "Runs": int(len(sub)),
            "HV_Mean": round(sub["HV"].mean(), 6),
            "HV_Std": round(sub["HV"].std(ddof=0), 6),
            "LocalMetric_Mean": round(sub["LocalMetric"].mean(), 6),
            "LocalMetric_Std": round(sub["LocalMetric"].std(ddof=0), 6),
            "Cost_Min_Mean": round(sub["Cost_Min"].mean(), 6),
            "Cost_Min_Std": round(sub["Cost_Min"].std(ddof=0), 6),
            "Time_Min_Mean": round(sub["Time_Min"].mean(), 6),
            "Time_Min_Std": round(sub["Time_Min"].std(ddof=0), 6),
            "Pen_Min_Mean": round(sub["Pen_Min"].mean(), 6),
            "Pen_Min_Std": round(sub["Pen_Min"].std(ddof=0), 6),
            "ZeroPenalty_Ratio_Mean": round(sub["ZeroPenalty_Ratio"].mean(), 6),
        })
    pd.DataFrame(by_n_rows).sort_values(["N"]).to_csv(SUMMARY_BY_N_FILE, index=False)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run calibrated MOPSO for Table 8 replacement rows.")
    parser.add_argument("--instances", default="", help="Comma-separated instance files; default: all nine.")
    parser.add_argument("--n-list", default="", help="Comma-separated N values; default: 50,100.")
    parser.add_argument("--seeds", default="", help="Comma-separated seeds; default: 4201-4230.")
    parser.add_argument("--restart", action="store_true", help="Delete existing run and summary outputs first.")
    args = parser.parse_args()

    if args.restart:
        for path in [RUNLEVEL_FILE, SUMMARY_BY_N_FILE, SUMMARY_BY_INSTANCE_FILE]:
            if path.exists():
                path.unlink()
    write_config()

    instances = parse_str_list(args.instances) if args.instances else INSTANCE_FILES
    n_list = parse_int_list(args.n_list) if args.n_list else N_LIST
    seeds = parse_int_list(args.seeds) if args.seeds else RUN_SEEDS

    run_df = load_run_df()
    done = completed_keys(run_df)

    tasks = [
        (inst, int(n), int(seed))
        for inst in instances
        for n in n_list
        for seed in seeds
        if (inst, int(n), int(seed)) not in done
    ]
    total = len(instances) * len(n_list) * len(seeds)
    print(f"Requested runs: {total}; already completed: {total - len(tasks)}; pending: {len(tasks)}")
    print(f"Results dir: {RESULTS_DIR}")

    pre_cache = {}
    for counter, (inst, n, seed) in enumerate(tasks, start=1):
        print(f"[{counter}/{len(tasks)}] instance={inst}, N={n}, seed={seed}", flush=True)
        cache_key = (inst, n)
        if cache_key not in pre_cache:
            pre_cache[cache_key] = precompute.ensure_precomputed(
                inst,
                n,
                solomon_dir=SOLOMON_DIR,
                output_dir=PRECOMP_DIR,
                facility_seed=FACILITY_SEED,
                rebuild=False,
            )

        core.set_environment_from_precomputed(pre_cache[cache_key])
        pareto_front, pareto_objs, local_metric, _, conv_gen = run_calibrated_mopso(seed, n)
        if not pareto_objs:
            raise Exception(f"Empty Pareto front for {inst}, N={n}, seed={seed}")

        row = core.build_run_row(
            n,
            seed,
            ALGO_NAME,
            pareto_front,
            pareto_objs,
            local_metric,
            conv_gen,
            HV_REF,
            "FULL",
            pen_cap=None,
        )
        row.update({
            "Instance": inst,
            "P_PBest": P_PBEST,
            "P_Leader": P_LEADER,
            "P_Mutation": P_MUTATION,
            "Archive_Capacity": ARCHIVE_CAPACITY,
        })

        row_df = pd.DataFrame([row])
        if RUNLEVEL_FILE.exists():
            row_df.to_csv(RUNLEVEL_FILE, mode="a", header=False, index=False)
        else:
            row_df.to_csv(RUNLEVEL_FILE, index=False)

        rebuild_summaries()
        print(
            f"  done: pareto={len(pareto_objs)}, HV={row['HV']}, "
            f"cost_min={row['Cost_Min']}, time_min={row['Time_Min']}, "
            f"pen_min={row['Pen_Min']}, local_metric={local_metric:.3f}s",
            flush=True,
        )

    rebuild_summaries()
    if SUMMARY_BY_N_FILE.exists():
        print("\nSummary by N:")
        print(pd.read_csv(SUMMARY_BY_N_FILE).to_string(index=False))

    print(f"\nRun-level results: {RUNLEVEL_FILE}")
    print(f"Summary by N: {SUMMARY_BY_N_FILE}")
    print(f"Summary by instance: {SUMMARY_BY_INSTANCE_FILE}")


if __name__ == "__main__":
    main()
