import random
import math
import time
import numpy as np
import pandas as pd
from deap.tools._hypervolume import hv
import heapq
from collections import defaultdict
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# =====================================================================
# 【一】 基础物理参数与全局数据
# =====================================================================
ALGO_VERSION = 'v29_hpp_cost_front_boost_fast'
DEFAULT_CX_PB = 0.6
DEFAULT_BASE_MUT_PB = 0.15
DEFAULT_ELITE_RATIO = 0.15

SEED = 42
warehouse_position = (35 * 100, 35 * 100)
wait_time = 10.0
VEHICLE_SPEED = 10.0
vehicle_speed = 10.0
DRONE_SPEED = 20.0
VEHICLE_UNIT_COST = 1.5 / 7.3 / 1000.0
DRONE_UNIT_COST = 0.5 / 7.3 / 1000.0
CAR_DRONE_UNIT_COST = 0.5 / 7.3 / 1000.0
WAIT_COST_PER_SEC = CAR_DRONE_UNIT_COST * DRONE_SPEED

# 按论文口径统一：运输成本按 USD/m，固定启用成本按 100 元 / 20 元换算成 USD
TRUCK_FIXED_COST = 100.0 / 7.3
DIRECT_DRONE_FIXED_COST = 20.0 / 7.3
CAR_DRONE_FIXED_COST = 20.0 / 7.3

# 子问题缓存：不改变算法含义，只减少重复求解
ROUTE_EVAL_CACHE = {}
DRONE_SET_CACHE = {}
# Static precomputation handles loaded from precomputed_inputs/*.pkl
CAR_RANGE_OK_MATRIX = None
RECOVERY_CANDIDATES_MAP = None

drone_payload = 30
car_drone_payload = 30
scale = 100.0

FACILITY_NOISE_THRESHOLD_DB = 40.0
DRONE_MAX_RANGE = 10000
CAR_DRONE_MAX_RANGE = 10000
DRONE_LW = 86.6
ALPHA = 0.005

ORIGINAL_POSITIONS = [
    (41 * 100, 49 * 100), (35 * 100, 17 * 100), (55 * 100, 45 * 100), (55 * 100, 20 * 100), (15 * 100, 30 * 100),
    (25 * 100, 30 * 100), (20 * 100, 50 * 100), (10 * 100, 43 * 100), (55 * 100, 60 * 100), (30 * 100, 60 * 100),
    (20 * 100, 65 * 100), (50 * 100, 35 * 100), (30 * 100, 25 * 100), (15 * 100, 10 * 100), (30 * 100, 5 * 100),
    (10 * 100, 20 * 100), (5 * 100, 30 * 100), (20 * 100, 40 * 100), (15 * 100, 60 * 100), (45 * 100, 65 * 100),
    (45 * 100, 20 * 100), (45 * 100, 10 * 100), (55 * 100, 5 * 100), (65 * 100, 35 * 100), (65 * 100, 20 * 100),
    (45 * 100, 30 * 100), (35 * 100, 40 * 100), (41 * 100, 37 * 100), (64 * 100, 42 * 100), (40 * 100, 60 * 100),
    (31 * 100, 52 * 100), (35 * 100, 69 * 100), (53 * 100, 52 * 100), (65 * 100, 55 * 100), (63 * 100, 65 * 100),
    (2 * 100, 60 * 100), (20 * 100, 20 * 100), (5 * 100, 5 * 100), (60 * 100, 12 * 100), (40 * 100, 25 * 100),
    (42 * 100, 7 * 100), (24 * 100, 12 * 100), (23 * 100, 3 * 100), (11 * 100, 14 * 100), (6 * 100, 38 * 100),
    (2 * 100, 48 * 100), (8 * 100, 56 * 100), (13 * 100, 52 * 100), (6 * 100, 68 * 100), (47 * 100, 47 * 100),
    (49 * 100, 58 * 100), (27 * 100, 43 * 100), (37 * 100, 31 * 100), (57 * 100, 29 * 100), (63 * 100, 23 * 100),
    (53 * 100, 12 * 100), (32 * 100, 12 * 100), (36 * 100, 26 * 100), (21 * 100, 24 * 100), (17 * 100, 34 * 100),
    (12 * 100, 24 * 100), (24 * 100, 58 * 100), (27 * 100, 69 * 100), (15 * 100, 77 * 100), (62 * 100, 77 * 100),
    (49 * 100, 73 * 100), (67 * 100, 5 * 100), (56 * 100, 39 * 100), (37 * 100, 47 * 100), (37 * 100, 56 * 100),
    (57 * 100, 68 * 100), (47 * 100, 16 * 100), (44 * 100, 17 * 100), (46 * 100, 13 * 100), (49 * 100, 11 * 100),
    (49 * 100, 42 * 100), (53 * 100, 43 * 100), (61 * 100, 52 * 100), (57 * 100, 48 * 100), (56 * 100, 37 * 100),
    (55 * 100, 54 * 100), (15 * 100, 47 * 100), (14 * 100, 37 * 100), (11 * 100, 31 * 100), (16 * 100, 22 * 100),
    (4 * 100, 18 * 100), (28 * 100, 18 * 100), (26 * 100, 52 * 100), (26 * 100, 35 * 100), (31 * 100, 67 * 100),
    (15 * 100, 19 * 100), (22 * 100, 22 * 100), (18 * 100, 24 * 100), (26 * 100, 27 * 100), (25 * 100, 24 * 100),
    (22 * 100, 27 * 100), (25 * 100, 21 * 100), (19 * 100, 21 * 100), (20 * 100, 26 * 100), (18 * 100, 18 * 100)
]
# 严格按照 r101.txt 修正：ID 49 修正为 30, ID 50 修正为 13 等
ORIGINAL_WEIGHTS = [
    0, 10, 7, 13, 19, 26, 3, 5, 9, 16, 16, 12, 19, 23, 20, 8, 19, 2, 12, 17,
    9, 11, 18, 29, 3, 6, 17, 16, 16, 9, 21, 27, 23, 11, 14, 8, 5, 8, 16, 31,
    9, 5, 5, 7, 18, 16, 1, 27, 36, 30, 13, 10, 9, 14, 18, 2, 6, 7, 18, 28,
    3, 13, 19, 10, 9, 20, 25, 25, 36, 6, 5, 15, 25, 9, 8, 18, 13, 14, 3, 23,
    6, 26, 16, 11, 7, 41, 35, 26, 9, 15, 3, 1, 2, 22, 27, 20, 11, 12, 10, 9, 17
]

# 严格按照 r101.txt 修正：仓库 DueDate 修正为 2300，其余 DueDate = Solomon_Due * 10
# 注意：为了匹配你之前的启发式简化逻辑，Ready Time 统一保持为 0
ORIGINAL_TW = [
    (0, 2300), (0, 1710), (0, 600), (0, 1260), (0, 1590), (0, 440), (0, 1090), (0, 910), (0, 1050), (0, 1070),
    (0, 1340), (0, 770), (0, 730), (0, 1690), (0, 420), (0, 710), (0, 850), (0, 1670), (0, 970), (0, 860),
    (0, 1360), (0, 720), (0, 1070), (0, 780), (0, 1630), (0, 1820), (0, 1420), (0, 470), (0, 490), (0, 730),
    (0, 810), (0, 600), (0, 1510), (0, 470), (0, 1270), (0, 1530), (0, 510), (0, 1440), (0, 930), (0, 540),
    (0, 950), (0, 1070), (0, 410), (0, 1420), (0, 790), (0, 420), (0, 1270), (0, 610), (0, 1750), (0, 1180),
    (0, 1340), (0, 980), (0, 620), (0, 1050), (0, 1500), (0, 1460), (0, 1400), (0, 1110), (0, 2100), (0, 280),
    (0, 1720), (0, 860), (0, 680), (0, 440), (0, 830), (0, 610), (0, 1370), (0, 930), (0, 1520), (0, 600),
    (0, 1920), (0, 870), (0, 450), (0, 880), (0, 1590), (0, 790), (0, 830), (0, 1890), (0, 1060), (0, 1020),
    (0, 1920), (0, 1040), (0, 650), (0, 540), (0, 1110), (0, 1010), (0, 1040), (0, 1030), (0, 840), (0, 1860),
    (0, 1050), (0, 1700), (0, 280), (0, 1980), (0, 1100), (0, 490), (0, 1450), (0, 1430), (0, 680), (0, 930),
    (0, 1950)
]
facility_positions = [(35 * 100, 35 * 100), (45 * 100, 45 * 100)]


# =====================================================================
# 【二】 底层物理与 ALNS 评估 (修正量纲：绝对美元成本)
# =====================================================================
def calculate_distance(a, b): return math.hypot(a[0] - b[0], a[1] - b[1])


def calculate_distance_from_warehouse(pos): return calculate_distance(warehouse_position, pos)


def manhattan_distance(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1])


def attenuated_LA_at_point(src_pos, recv_pos):
    d = max(math.hypot(src_pos[0] - recv_pos[0], src_pos[1] - recv_pos[1]), 0.1)
    return DRONE_LW - 20 * math.log10(d) - ALPHA * d


def precompute_data(cust_pos):
    global precomputed_manhattan, PRECOMPUTED_EUCLIDEAN
    all_points = np.array([warehouse_position] + list(cust_pos))

    # 利用 NumPy 广播机制，瞬间算出 N*N 的坐标差矩阵
    diff = all_points[:, np.newaxis, :] - all_points[np.newaxis, :, :]

    # 预计算欧式距离矩阵 (Euclidean)
    PRECOMPUTED_EUCLIDEAN = np.sqrt(np.sum(diff ** 2, axis=-1))

    # 顺手把你的曼哈顿距离也用矩阵化加速了，省掉双层 for 循环
    precomputed_manhattan = np.sum(np.abs(diff), axis=-1)


def solve_vrptw_alns(veh_customers, customer_positions, time_windows, alpha=0.5, max_iter=10):
    local_nodes = [0] + list(veh_customers)
    local_pos = {node: idx for idx, node in enumerate(local_nodes)}
    dist_mat = precomputed_manhattan[np.ix_(local_nodes, local_nodes)]

    remaining = set(veh_customers)
    route = [0]
    T_cur = 0.0
    prev = 0
    while remaining:
        i_loc = local_pos[prev]
        delta, slack = {}, {}
        for j in remaining:
            j_loc = local_pos[j]
            Delta = dist_mat[i_loc, j_loc] / VEHICLE_SPEED
            T_hat = T_cur + Delta
            _, L_j = time_windows[j]
            delta[j] = Delta
            slack[j] = max(0.0, L_j - T_hat)

        d_vals, s_vals = delta.values(), slack.values()
        d_min, d_max = min(d_vals), max(d_vals)
        s_min, s_max = min(s_vals), max(s_vals)

        best_j, best_score = None, float('inf')
        for j in remaining:
            Dn = (delta[j] - d_min) / (d_max - d_min + 1e-6) if d_max > d_min else 0
            Sn = (s_max - slack[j]) / (s_max - s_min + 1e-6) if s_max > s_min else 0
            score = alpha * Dn + (1 - alpha) * Sn
            if score < best_score:
                best_score, best_j = score, j

        route.append(best_j)
        T_cur += delta[best_j]
        prev = best_j
        remaining.remove(best_j)

    route.append(0)
    local_route = [local_pos[g] for g in route]

    def evaluate_local_route(rt):
        t_curr, pen, dst = 0.0, 0.0, 0.0
        max_node_pen = 0.0
        worst_n = None
        for i in range(len(rt) - 1):
            u, v = rt[i], rt[i + 1]
            d = dist_mat[u][v]
            dst += d
            t_curr += (d / VEHICLE_SPEED)
            if v != 0:
                global_v = local_nodes[v]
                _, L_v = time_windows[global_v]
                if t_curr > L_v:
                    node_p = t_curr - L_v
                    pen += node_p
                    if node_p > max_node_pen:
                        max_node_pen = node_p
                        worst_n = v
                t_curr += wait_time
        return pen, dst, worst_n

    best_pen, best_dist, worst0 = evaluate_local_route(local_route)
    best_lr = local_route[:]
    if best_pen == 0:
        return [local_nodes[idx] for idx in best_lr], dist_mat

    current_lr, current_pen, current_dist, current_worst = best_lr[:], best_pen, best_dist, worst0
    temperature, cooling_rate = 100.0, 0.95

    for iteration in range(max_iter):
        removed_node = current_worst if (random.random() < 0.70 and current_worst is not None) else None
        if removed_node is None and len(current_lr) > 3:
            removed_node = random.choice(current_lr[1:-1])
        if removed_node is None:
            break

        temp_lr = [n for n in current_lr if n != removed_node]
        best_repair, repair_pen, repair_dist, repair_worst = None, float('inf'), float('inf'), None

        for i in range(1, len(temp_lr)):
            test_lr = temp_lr[:i] + [removed_node] + temp_lr[i:]
            p, d, w = evaluate_local_route(test_lr)
            if p < repair_pen or (p == repair_pen and d < repair_dist):
                repair_pen, repair_dist, repair_worst = p, d, w
                best_repair = test_lr

        if repair_pen < current_pen or (repair_pen == current_pen and repair_dist < current_dist):
            current_lr, current_pen, current_dist, current_worst = best_repair, repair_pen, repair_dist, repair_worst
            if current_pen < best_pen or (current_pen == best_pen and current_dist < best_dist):
                best_lr, best_pen, best_dist = current_lr, current_pen, current_dist
        else:
            delta_E = (repair_pen - current_pen) * 100 + (repair_dist - current_dist)
            if delta_E > 0 and temperature > 0.01 and random.random() < math.exp(-delta_E / temperature):
                current_lr, current_pen, current_dist, current_worst = best_repair, repair_pen, repair_dist, repair_worst

        temperature *= cooling_rate
        if best_pen == 0:
            break

    improved = True
    while improved:
        improved = False
        for i in range(1, len(best_lr) - 2):
            for j in range(i + 1, len(best_lr) - 1):
                u, v = best_lr[i - 1], best_lr[i]
                x, y = best_lr[j], best_lr[j + 1]
                delta_d = dist_mat[u][x] + dist_mat[v][y] - dist_mat[u][v] - dist_mat[x][y]
                if delta_d < -1e-6:
                    test_opt = best_lr[:i] + best_lr[i:j + 1][::-1] + best_lr[j + 1:]
                    p, d, _ = evaluate_local_route(test_opt)
                    if p <= best_pen:
                        best_lr, best_pen, best_dist = test_opt, p, d
                        improved = True
                        break
            if improved:
                break
    return [local_nodes[idx] for idx in best_lr], dist_mat


def evaluate_vehicle(global_route, dist_matrix, cust_list, wait_time):
    """Truck 时间口径修正版：arrival 不包含当前客户自己的 wait_time。"""
    drive_dist, total_time, arrivals = 0.0, 0.0, {}
    local_idx = {cust: idx + 1 for idx, cust in enumerate(cust_list)}
    for u, v in zip(global_route[:-1], global_route[1:]):
        lu = 0 if u == 0 else local_idx[u]
        lv = 0 if v == 0 else local_idx[v]
        d = dist_matrix[lu][lv]
        drive_dist += d
        seg = d / VEHICLE_SPEED
        total_time += seg
        if v != 0:
            arrivals[v] = total_time
            total_time += wait_time
    return drive_dist * VEHICLE_UNIT_COST, total_time, arrivals


def recovery_candidates(i, j, nodes):
    """Candidate recovery nodes for a truck-mounted drone task i -> j -> p.

    Prefer the precomputed candidate set when available. This avoids rebuilding
    the same recovery-node list in every seed/run and keeps the heuristic and
    Gurobi code on the same static feasible domain.
    """
    global RECOVERY_CANDIDATES_MAP
    if RECOVERY_CANDIDATES_MAP is not None:
        cand = RECOVERY_CANDIDATES_MAP.get((int(i), int(j)))
        if cand is not None:
            return list(cand)
    if i == 0:
        return [p for p in nodes if p != j]
    return [p for p in nodes if p != i and p != j]


def is_car_trip_range_feasible(launch_node, cust_idx, recovery_node):
    """Range check for the complete truck-mounted-drone sortie i -> j -> p.

    If a precomputed matrix is loaded, this is an O(1) table lookup. Otherwise
    it falls back to the original distance calculation.
    """
    global CAR_RANGE_OK_MATRIX
    if CAR_RANGE_OK_MATRIX is not None:
        return bool(CAR_RANGE_OK_MATRIX[int(launch_node), int(cust_idx), int(recovery_node)])
    return (PRECOMPUTED_EUCLIDEAN[launch_node, cust_idx] +
            PRECOMPUTED_EUCLIDEAN[cust_idx, recovery_node] <= CAR_DRONE_MAX_RANGE + 1e-9)


def _build_car_range_ok_matrix(N):
    """Fallback builder used only when no external precomputed file is loaded."""
    mat = np.zeros((N + 1, N + 1, N + 1), dtype=bool)
    nodes = range(N + 1)
    for launch_node in nodes:
        for cust_idx in range(1, N + 1):
            if launch_node == cust_idx:
                continue
            for recovery_node in recovery_candidates(launch_node, cust_idx, nodes):
                mat[launch_node, cust_idx, recovery_node] = (
                    PRECOMPUTED_EUCLIDEAN[launch_node, cust_idx] +
                    PRECOMPUTED_EUCLIDEAN[cust_idx, recovery_node] <= CAR_DRONE_MAX_RANGE + 1e-9
                )
    return mat


def has_any_car_range_feasible(cust_idx):
    """Customer-level prefilter: keep car-drone mode only if at least one i -> j -> p sortie is range-feasible."""
    global CAR_RANGE_OK_MATRIX
    if CAR_RANGE_OK_MATRIX is not None:
        return bool(np.any(CAR_RANGE_OK_MATRIX[:, int(cust_idx), :]))
    nodes = range(num_customers + 1)
    for launch_node in nodes:
        if launch_node == cust_idx:
            continue
        for recovery_node in recovery_candidates(launch_node, cust_idx, nodes):
            if is_car_trip_range_feasible(launch_node, cust_idx, recovery_node):
                return True
    return False


def evaluate_car_drone(car_assignments, customer_positions, vehicle_routes, veh_arrivals, time_windows, wait_time=0.0):
    for vid in range(num_vehicles):
        vehicle_routes.setdefault(vid, [0, 0])
    drone_ready, last_ret_index, used_rel_points, drone_log = defaultdict(float), {}, defaultdict(set), defaultdict(list)
    total_time, total_cost, arrivals = 0.0, 0.0, {}

    for vid, cdid, cust_idx in car_assignments:
        key = (vid, cdid)
        route = vehicle_routes[vid]
        dr_ready = drone_ready[key]
        start_i = last_ret_index.get(key, 0)
        launch_idxs = list(range(start_i, min(len(route), start_i + 3)))
        candidates = []

        for i in launch_idxs:
            rel = route[i]
            if rel in used_rel_points[key]:
                continue

            rtime = max(veh_arrivals.get(rel, 0.0), dr_ready)
            out_d = PRECOMPUTED_EUCLIDEAN[rel, cust_idx]
            out_t = out_d / DRONE_SPEED

            for j in range(i, min(len(route), i + 3)):
                ret = route[j]
                back_d = PRECOMPUTED_EUCLIDEAN[cust_idx, ret]
                if not is_car_trip_range_feasible(rel, cust_idx, ret):
                    continue
                back_t = back_d / DRONE_SPEED
                atime = rtime + out_t
                rctime = rtime + out_t + back_t

                if ret == 0:
                    # 仓库回收按最终独立回收处理：允许晚于卡车回仓，不产生等待成本
                    wait_duration = 0.0
                    candidates.append((atime + rctime, i, j, rel, ret, rtime, atime, rctime,
                                       out_t, back_t, wait_duration, out_d, back_d))
                else:
                    # 非仓库回收必须与 truck-visited recovery 节点同步
                    ret_ready = veh_arrivals.get(ret, 0.0)
                    if rctime <= ret_ready:
                        wait_duration = max(0.0, ret_ready - rctime)
                        candidates.append((atime + rctime, i, j, rel, ret, rtime, atime, rctime,
                                           out_t, back_t, wait_duration, out_d, back_d))

        infeasible_car_trip = False
        if candidates:
            _, rel_idx, ret_idx, rel, ret, rtime, atime, rctime, out_t, back_t, wait_duration, out_d, back_d = min(
                candidates, key=lambda x: x[0]
            )
        else:
            # 若局部窗口中无可行非仓库回收，则允许最终回仓库独立回收，
            # 但仍必须满足完整 i -> j -> 0 续航约束。
            feasible_depot_launches = [r for r in route if is_car_trip_range_feasible(r, cust_idx, 0)]
            if feasible_depot_launches:
                rel = min(feasible_depot_launches, key=lambda r: PRECOMPUTED_EUCLIDEAN[r, cust_idx])
                rtime = max(veh_arrivals.get(rel, 0.0), dr_ready)
                out_d = PRECOMPUTED_EUCLIDEAN[rel, cust_idx]
                out_t = out_d / DRONE_SPEED
                back_d = PRECOMPUTED_EUCLIDEAN[cust_idx, 0]
                back_t = back_d / DRONE_SPEED
                atime = rtime + out_t
                rctime = rtime + out_t + back_t
                wait_duration, ret_idx, ret = 0.0, len(route) - 1, 0
            else:
                # Route-specific infeasibility: assign an extreme arrival time so NSGA-II eliminates this chromosome.
                rel, ret, ret_idx = 0, 0, len(route) - 1
                rtime = dr_ready
                atime = rctime = 1e9 + cust_idx
                out_t = back_t = wait_duration = out_d = back_d = 0.0
                infeasible_car_trip = True

        arrivals[cust_idx] = atime
        drone_ready[key] = rctime
        last_ret_index[key] = ret_idx
        used_rel_points[key].add(rel)
        total_time += (out_t + back_t) + wait_duration
        total_cost += (out_d + back_d) * CAR_DRONE_UNIT_COST
        if infeasible_car_trip:
            total_time += 1e6
            total_cost += 1e6
        if ret != 0:
            total_cost += wait_duration * WAIT_COST_PER_SEC
        drone_log[key].append((rel, ret, cust_idx, rtime, atime, rctime, wait_duration))

    return total_cost, total_time, arrivals, drone_log


def _repair_orphan_car_assignments(individual):
    """
    与 Gurobi 可行域对齐：车载无人机所属 truck 至少需要有一个 truck-served customer，
    否则该 truck 实际上并未形成有效 truck route。
    """
    repaired = list(individual)
    truck_nodes = defaultdict(list)
    for idx, gene in enumerate(repaired):
        if gene[0] == 0:
            truck_nodes[gene[1]].append(idx)

    def _centers(nodes_dict):
        centers = {}
        for vid, nodes in nodes_dict.items():
            if nodes:
                centers[vid] = (
                    sum(customer_positions[i][0] for i in nodes) / len(nodes),
                    sum(customer_positions[i][1] for i in nodes) / len(nodes),
                )
        return centers

    centers = _centers(truck_nodes)

    for idx, gene in enumerate(repaired):
        if gene[0] != 2:
            continue
        vid, cdid = gene[1], gene[2]
        if vid in truck_nodes and truck_nodes[vid]:
            continue

        allow = customer_allowed[idx]
        if centers:
            near_vid = min(centers.keys(), key=lambda t: calculate_distance(customer_positions[idx], centers[t]))
            repaired[idx] = (2, near_vid, min(cdid, num_car_drones - 1))
        elif 1 in allow:
            repaired[idx] = (1, sample_direct_id(repaired))
        else:
            new_vid = vid if 0 <= vid < num_vehicles else 0
            repaired[idx] = (0, new_vid)
            truck_nodes[new_vid].append(idx)
            centers = _centers(truck_nodes)

    return repair_individual(repaired)


def evaluate_drone(drone_assignments, customer_positions, time_windows):
    """
    直飞无人机调度（修正版）
    - 输入保留染色体中的 drone_id
    - 每个直飞客户只能由其基因指定的那架直飞无人机服务
    - 客户完成时间按方案 A：到达客户时刻
    """
    key = tuple(sorted(drone_assignments))
    cached = DRONE_SET_CACHE.get(key)
    if cached is not None:
        return cached

    tasks_by_drone = defaultdict(list)
    total_cost = 0.0
    for did, cust in drone_assignments:
        d = PRECOMPUTED_EUCLIDEAN[0, cust]
        total_cost += (d * 2) * DRONE_UNIT_COST
        one_way_t = d / DRONE_SPEED
        round_trip_t = (d * 2) / DRONE_SPEED
        slack = time_windows[cust][1] - one_way_t
        tasks_by_drone[did].append((cust, one_way_t, round_trip_t, slack))

    arrivals = {}
    resource_finish = 0.0
    for did, tasks in tasks_by_drone.items():
        tasks.sort(key=lambda x: x[3])
        current_t = 0.0
        for cust, one_way_t, round_trip_t, slack in tasks:
            arrivals[cust] = current_t + one_way_t
            current_t += round_trip_t
        resource_finish = max(resource_finish, current_t)

    result = (total_cost, resource_finish, arrivals)
    DRONE_SET_CACHE[key] = result
    return result


def evaluate_individual(individual):
    individual = _repair_orphan_car_assignments(individual)
    veh_c, car_c, drn_assign = [], [], []
    for i, gene in enumerate(individual, start=1):
        if gene[0] == 0:
            veh_c.append((gene[1], i))
        elif gene[0] == 1:
            drn_assign.append((gene[1], i))
        else:
            car_c.append((gene[1], gene[2], i))

    veh_cost, veh_time, veh_arrivals, vehicle_routes = 0.0, 0.0, {}, {}
    cust_by_vehicle = defaultdict(list)
    for vid, cust in veh_c:
        cust_by_vehicle[vid].append(cust)

    for vid, cl in cust_by_vehicle.items():
        route_key = tuple(sorted(cl))
        cached = ROUTE_EVAL_CACHE.get(route_key)
        if cached is None:
            rt, mat = solve_vrptw_alns(cl, customer_positions, time_windows, alpha=0.5, max_iter=10)
            c, t, arr = evaluate_vehicle(rt, mat, cl, wait_time)
            cached = (rt, c, t, arr)
            ROUTE_EVAL_CACHE[route_key] = cached
        rt, c, t, arr = cached
        vehicle_routes[vid] = rt
        veh_cost += c
        veh_time += t
        veh_arrivals.update(arr)

    carv_cost, carv_time, car_arrivals, drone_log = evaluate_car_drone(
        car_c, customer_positions, vehicle_routes, veh_arrivals, time_windows, wait_time=wait_time)

    drn_cost, drn_resource_finish, drn_arrivals = evaluate_drone(drn_assign, customer_positions, time_windows)
    all_arrivals = {**veh_arrivals, **car_arrivals, **drn_arrivals}

    vehicle_return_times = {}
    for vid, route in vehicle_routes.items():
        cust_route = [n for n in route if n != 0]
        if cust_route:
            last_cust = cust_route[-1]
            vehicle_return_times[vid] = veh_arrivals[last_cust] + wait_time + manhattan_distance(
                customer_positions[last_cust - 1], warehouse_position) / VEHICLE_SPEED
        else:
            vehicle_return_times[vid] = 0.0

    delivery_time = max(
        max(all_arrivals.values()) if all_arrivals else 0.0,
        max(vehicle_return_times.values()) if vehicle_return_times else 0.0
    )

    total_penalty = 0.0
    penalties = []
    for cust_idx in range(1, len(individual) + 1):
        T = all_arrivals.get(cust_idx, float('inf'))
        _, L_i = time_windows[cust_idx]
        if T > L_i:
            pen = T - L_i
            total_penalty += pen
            penalties.append((cust_idx, pen))

    sorted_penalties = sorted(penalties, key=lambda x: x[1], reverse=True)
    key = tuple(individual)
    WORST_NODE_DICT[key] = sorted_penalties[0][0] - 1 if sorted_penalties else None
    TOP_TARDY_NODES_DICT[key] = [cid - 1 for cid, _ in sorted_penalties[:6]]

    active_trucks = {vid for vid, _ in veh_c} | {vid for vid, _, _ in car_c}
    active_direct_drones = {did for did, _ in drn_assign}
    active_car_drones = {(vid, cdid) for vid, cdid, _ in car_c}
    fixed_cost = (
        len(active_trucks) * TRUCK_FIXED_COST +
        len(active_direct_drones) * DIRECT_DRONE_FIXED_COST +
        len(active_car_drones) * CAR_DRONE_FIXED_COST
    )

    total_cost = veh_cost + carv_cost + drn_cost + fixed_cost
    return total_cost, delivery_time, total_penalty

def custom_kmeans(data, k, n_init=5, max_iter=50):
    if k >= len(data): return [i % k for i in range(len(data))]
    best_inertia, best_labels = float('inf'), None
    for _ in range(n_init):
        centroids = random.sample(data, k)
        labels = [-1] * len(data)
        for _ in range(max_iter):
            changed = False
            clusters = [[] for _ in range(k)]
            for i, p in enumerate(data):
                c_idx = int(np.argmin([(p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 for c in centroids]))
                if labels[i] != c_idx: labels[i] = c_idx; changed = True
                clusters[c_idx].append(p)
            if not changed: break
            for c_idx in range(k):
                if clusters[c_idx]: centroids[c_idx] = (sum(p[0] for p in clusters[c_idx]) / len(clusters[c_idx]),
                                                        sum(p[1] for p in clusters[c_idx]) / len(clusters[c_idx]))
        inertia = sum((data[i][0] - centroids[labels[i]][0]) ** 2 + (data[i][1] - centroids[labels[i]][1]) ** 2 for i in
                      range(len(data)))
        if inertia < best_inertia: best_inertia, best_labels = inertia, labels[:]
    return best_labels


def dominates(a, b): return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def normalize_objs(pop_objs):
    arr = np.array(pop_objs, dtype=np.float32)
    mi, ma = arr.min(axis=0), arr.max(axis=0)
    return ((arr - mi) / (ma - mi + 1e-9)).tolist()


def fast_nondominated_sort(objs):
    S, n, fronts = [[] for _ in objs], [0] * len(objs), [[]]
    for p in range(len(objs)):
        for q in range(len(objs)):
            if dominates(objs[p], objs[q]):
                S[p].append(q)
            elif dominates(objs[q], objs[p]):
                n[p] += 1
        if n[p] == 0: fronts[0].append(p)
    i = 0
    while fronts[i]:
        nxt = []
        for p in fronts[i]:
            for q in S[p]:
                n[q] -= 1
                if n[q] == 0: nxt.append(q)
        i += 1;
        fronts.append(nxt)
    if not fronts[-1]: fronts.pop()
    return fronts


def crowding_distance(front, objs):
    dist = {i: 0.0 for i in front}
    for m in range(len(objs[0])):
        sf = sorted(front, key=lambda i: objs[i][m])
        f_min, f_max = objs[sf[0]][m], objs[sf[-1]][m]
        dist[sf[0]] = dist[sf[-1]] = float('inf')
        if f_max == f_min: continue
        for idx in range(1, len(sf) - 1): dist[sf[idx]] += (objs[sf[idx + 1]][m] - objs[sf[idx - 1]][m]) / (
                    f_max - f_min)
    return dist



def rebuild_penalty_maps(pop):
    WORST_NODE_DICT.clear()
    TOP_TARDY_NODES_DICT.clear()
    return [evaluate_individual(ind) for ind in pop]

def select_nsga2(pop, objs, k):
    fronts = fast_nondominated_sort(normalize_objs(objs))
    selected = []
    for front in fronts:
        if len(selected) + len(front) <= k:
            selected.extend(front)
        else:
            dist = crowding_distance(front, objs)
            selected.extend(sorted(front, key=lambda i: -dist[i])[:k - len(selected)])
            break
    return [pop[i] for i in selected], [objs[i] for i in selected]


# =====================================================================
# 【四】 纯手写遗传算子与变异策略 (引入：暴力路线缝合与多目标降本)
# =====================================================================
def repair_individual(ind):
    for j, gene in enumerate(ind):
        if gene[0] not in customer_allowed[j]:
            new_type = random.choice(customer_allowed[j])
            if new_type == 0:
                ind[j] = (0, random.randrange(num_vehicles))
            elif new_type == 1:
                ind[j] = (1, random.randrange(num_drones))
            else:
                ind[j] = (2, random.randrange(num_vehicles), random.randrange(num_car_drones))
    return ind


def crossover(ind1, ind2):
    c1, c2 = list(ind1), list(ind2)
    a, b = sorted(random.sample(range(len(ind1)), 2))
    c1[a:b], c2[a:b] = c2[a:b], c1[a:b]
    return repair_individual(c1), repair_individual(c2)


def time_window_aware_mutation(ind):
    """
    温和时间窗修复：按 tuple(ind) 读 top tardy customer，
    只修最迟到的 1~2 个客户，避免大幅破坏成本结构。
    """
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])
    if not tardy_nodes:
        if random.random() < 0.7:
            return load_aware_mode_mutation(ind)
        return random_mode_mutation(ind)

    for worst_idx in tardy_nodes[:2]:
        if worst_idx is None or worst_idx >= len(ind):
            continue
        allow = customer_allowed[worst_idx]
        truck_nodes, centers = _cluster_centers_from_ind(ind)
        used_trucks = set(truck_nodes.keys())
        free_trucks = [v for v in range(num_vehicles) if v not in used_trucks]
        nearest_vid = _nearest_truck_vid(worst_idx, centers)

        if 0 in allow and free_trucks:
            ind[worst_idx] = (0, free_trucks[0])
        elif 1 in allow:
            ind[worst_idx] = (1, random.randrange(num_drones))
        elif 2 in allow:
            ind[worst_idx] = (2, nearest_vid, random.randrange(num_car_drones))
        elif 0 in allow:
            ind[worst_idx] = (0, nearest_vid)

    return repair_individual(ind),

def single_point_truck_cleanup(ind, N):
    """
    【策略 D：单点卡车智商清理 (UAV Replacement)】
    逻辑：识别只服务 1 个客户的卡车，尝试将其转换为航空器。
    清理强度：随着 N 增大，单次清理数量增加 (N // 20)。
    """
    num_to_clean = max(1, N // 20)
    truck_usage = defaultdict(list)
    for i, gene in enumerate(ind):
        if gene[0] in [0, 2]:  # 卡车或车载模式
            truck_usage[gene[1]].append(i)

    # 筛选服务点数为 1 的卡车
    single_trucks = [vid for vid, clients in truck_usage.items() if len(clients) == 1]
    random.shuffle(single_trucks)

    cleaned_count = 0
    for vid in single_trucks:
        if cleaned_count >= num_to_clean: break
        target_cust_idx = truck_usage[vid][0]
        allow = customer_allowed[target_cust_idx]

        # 模式转换：直飞优先
        if 1 in allow:
            ind[target_cust_idx] = (1, random.randrange(num_drones))
            cleaned_count += 1
        elif 2 in allow:
            other_trucks = [t for t, cl in truck_usage.items() if len(cl) > 1]
            if other_trucks:
                ind[target_cust_idx] = (2, random.choice(other_trucks), 0)
                cleaned_count += 1
    return ind,


def random_mode_mutation(ind):
    """【策略 R：纯随机变异】"""
    i = random.randrange(len(ind))
    choices = [m for m in customer_allowed[i] if m != ind[i][0]]
    if choices:
        nt = random.choice(choices)
        if nt == 0:
            ind[i] = (0, random.randrange(num_vehicles))
        elif nt == 1:
            ind[i] = (1, sample_direct_id(ind))
        else:
            ind[i] = (2, random.randrange(num_vehicles), random.randrange(num_car_drones))
    return ind,
def load_aware_mode_mutation(ind):
    """
    【大邻域杀招：暴力路线缝合与双向降本】
    """
    truck_loads = defaultdict(list)
    for i, gene in enumerate(ind):
        if gene[0] == 0 or gene[0] == 2:
            truck_loads[gene[1]].append(i)

    active_trucks = list(truck_loads.keys())
    rand_val = random.random()

    # 🚨 策略 A (40%概率): 暴力路线缝合 (消灭重叠卡车)
    if len(active_trucks) >= 2 and rand_val < 0.40:
        candidates = [t for t in active_trucks if len(truck_loads[t]) <= 8]
        if candidates:
            t1 = random.choice(candidates)
            c1_x = sum(customer_positions[n][0] for n in truck_loads[t1]) / max(1, len(truck_loads[t1]))
            c1_y = sum(customer_positions[n][1] for n in truck_loads[t1]) / max(1, len(truck_loads[t1]))
            center_t1 = (c1_x, c1_y)

            # 找到相邻且总单量合并后可控 (<=16单) 的卡车进行吞并
            other_trucks = [t for t in active_trucks if t != t1 and len(truck_loads[t]) + len(truck_loads[t1]) <= 16]
            if other_trucks:
                best_t2 = min(other_trucks, key=lambda t: calculate_distance(center_t1,
                                                                             (sum(customer_positions[n][0] for n in
                                                                                  truck_loads[t]) / max(1, len(
                                                                                 truck_loads[t])),
                                                                              sum(customer_positions[n][1] for n in
                                                                                  truck_loads[t]) / max(1, len(
                                                                                  truck_loads[t])))))

                for target in truck_loads[best_t2]:
                    if ind[target][0] == 0:
                        ind[target] = (0, t1)
                    else:
                        ind[target] = (2, t1, random.randrange(num_car_drones))

    # 🚨 策略 B (40%概率): 昂贵直飞“精准”回收
    elif rand_val < 0.80:
        drones = [i for i, gene in enumerate(ind) if gene[0] == 1]
        if drones and active_trucks:
            drone_losses = []
            all_truck_nodes = [n for t, nodes in truck_loads.items() for n in nodes]
            for d_node in drones:
                pos = customer_positions[d_node]
                drone_c = PRECOMPUTED_EUCLIDEAN[0, d_node] * 2 * DRONE_UNIT_COST
                if all_truck_nodes:
                    min_man_dist = min(manhattan_distance(pos, customer_positions[n]) for n in all_truck_nodes)
                    truck_c = min_man_dist * VEHICLE_UNIT_COST
                else:
                    truck_c = float('inf')
                drone_losses.append((d_node, drone_c - truck_c))

            drone_losses.sort(key=lambda x: x[1], reverse=True)
            target = drone_losses[0][0]

            choices = [m for m in customer_allowed[target] if m != 1]
            if not choices: choices = [0]
            nt = random.choice(choices)
            pos = customer_positions[target]
            best_t = min(active_trucks, key=lambda t: sum(
                PRECOMPUTED_EUCLIDEAN[target, n] for n in truck_loads[t]) / max(1, len(truck_loads[t])))

            if nt == 0:
                ind[target] = (0, best_t)
            else:
                ind[target] = (2, best_t, random.randrange(num_car_drones))

    # 🚨 策略 C (20%概率): 刺头节点转车载
    else:
        truck_nodes = [i for i, gene in enumerate(ind) if gene[0] == 0]
        if truck_nodes:
            target = random.choice(truck_nodes)
            if 2 in customer_allowed[target]:
                ind[target] = (2, ind[target][1], random.randrange(num_car_drones))
            elif 1 in customer_allowed[target]:
                ind[target] = (1, random.randrange(num_drones))

    return ind,




def inter_cluster_exchange_mutation(ind, top_m=4):
    """
    簇间交互变异：
    - 找出被“远距离 truck 服务”的客户
    - 尝试改挂到更近的 truck
    - 或改成当地 truck 的 car-drone / direct
    """
    cand = list(ind)
    truck_nodes, centers = _cluster_centers_from_ind(cand)
    if len(centers) < 2:
        return cooperative_block_mutation(ind)

    scores = []
    for idx, gene in enumerate(cand):
        if gene[0] != 0:
            continue
        own_vid = gene[1]
        own_center = centers.get(own_vid, customer_positions[idx])
        own_d = calculate_distance(customer_positions[idx], own_center)

        other_vids = [vid for vid in centers.keys() if vid != own_vid]
        if not other_vids:
            continue
        best_other = min(other_vids, key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))
        other_d = calculate_distance(customer_positions[idx], centers[best_other])

        miscluster_score = own_d - other_d
        if miscluster_score > 0:
            scores.append((miscluster_score, idx, own_vid, best_other))

    if not scores:
        return cooperative_block_mutation(ind)

    scores.sort(reverse=True)
    chosen = scores[:top_m]

    for _, idx, own_vid, best_other in chosen:
        allow = customer_allowed[idx]
        local_candidates = []

        # 1) 直接换到更近 truck
        if 0 in allow:
            c = list(cand)
            c[idx] = (0, best_other)
            local_candidates.append(repair_individual(c))

        # 2) 变为更近 truck 的 car-drone
        if 2 in allow:
            for cdid in range(num_car_drones):
                c = list(cand)
                c[idx] = (2, best_other, cdid)
                local_candidates.append(repair_individual(c))

        # 3) 变直飞
        if 1 in allow:
            for did in range(num_drones):
                c = list(cand)
                c[idx] = (1, did)
                local_candidates.append(repair_individual(c))

        best_local = cand
        best_obj = evaluate_individual(cand)
        for c in local_candidates:
            obj = evaluate_individual(c)
            if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                best_local, best_obj = c, obj

        cand = best_local

    return repair_individual(cand),

def cooperative_block_mutation(ind, block_size=4):
    """
    协同块变异：
    - 不改单点
    - 一次挑 3~4 个相关客户联合改模式
    - 优先覆盖：tardy / edge / aerial 三类
    """
    cand = list(ind)
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])[:max(2, block_size)]
    aerial_nodes = [i for i, g in enumerate(cand) if g[0] in (1, 2)]
    random.shuffle(aerial_nodes)
    aerial_nodes = aerial_nodes[:max(1, block_size // 2)]

    truck_nodes, centers = _cluster_centers_from_ind(cand)
    edge_nodes = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if cand[i][0] == 0:
                edge_nodes.append((calculate_distance(customer_positions[i], center), i))
    edge_nodes = [i for _, i in sorted(edge_nodes, reverse=True)[:max(2, block_size)]]

    chosen = list(dict.fromkeys(tardy_nodes + edge_nodes + aerial_nodes))[:block_size]
    if not chosen:
        return random_mode_mutation(ind)

    truck_nodes, centers = _cluster_centers_from_ind(cand)
    for idx in chosen:
        allow = customer_allowed[idx]
        near_vid = _nearest_truck_vid(idx, centers) if centers else 0

        # 规则化地联合改，而不是纯随机
        if idx in tardy_nodes:
            if 1 in allow and random.random() < 0.7:
                cand[idx] = (1, random.randrange(num_drones))
            elif 2 in allow:
                cand[idx] = (2, near_vid, random.randrange(num_car_drones))
            elif 0 in allow:
                cand[idx] = (0, near_vid)
        elif idx in edge_nodes:
            if 2 in allow and random.random() < 0.7:
                cand[idx] = (2, near_vid, random.randrange(num_car_drones))
            elif 1 in allow:
                cand[idx] = (1, random.randrange(num_drones))
            elif 0 in allow:
                cand[idx] = (0, near_vid)
        else:
            # aerial 老客户做重平衡
            if 0 in allow and random.random() < 0.4:
                cand[idx] = (0, near_vid)
            elif 1 in allow and random.random() < 0.5:
                cand[idx] = (1, random.randrange(num_drones))
            elif 2 in allow:
                cand[idx] = (2, near_vid, random.randrange(num_car_drones))

    cand = repair_individual(cand)
    cand, = time_window_aware_mutation(cand)
    return repair_individual(cand),

def economic_structure_mutation(ind):
    """合并原有降本缝合与单点清理，减少算子数量但保留主要作用。"""
    if random.random() < 0.75:
        return load_aware_mode_mutation(ind)
    return single_point_truck_cleanup(ind, len(ind))


def evolve_one_generation(pop, objs, cx_pb, mut_pb, elite_memory, e_cx_pb, e_mut_pb, use_elite=True, stagnated=False):
    if use_elite:
        front = fast_nondominated_sort(normalize_objs(objs))[0]
        if front:
            dist = crowding_distance(front, objs)
            keep_n = max(1, int(math.ceil(len(front) * DEFAULT_ELITE_RATIO)))
            keep_idx = sorted(front, key=lambda i: -dist[i])[:keep_n]
            elite_pool = elite_memory + [repair_individual(list(pop[i])) for i in keep_idx]
            dedup = {}
            for ind in elite_pool:
                dedup[tuple(ind)] = ind
            elite_memory = list(dedup.values())[:100]

    offspring = []
    active_mut_pb = min(0.25, DEFAULT_BASE_MUT_PB * 3.0) if stagnated else DEFAULT_BASE_MUT_PB
    active_cx_pb = DEFAULT_CX_PB

    while len(offspring) < len(pop):
        i, j = random.sample(range(len(pop)), 2)
        p1 = pop[i] if dominates(objs[i], objs[j]) else pop[j]
        i, j = random.sample(range(len(pop)), 2)
        p2 = pop[i] if dominates(objs[i], objs[j]) else pop[j]

        c1, c2 = list(p1), list(p2)

        if random.random() < active_cx_pb:
            if elite_memory and random.random() < e_cx_pb:
                elite = random.choice(elite_memory)
                a, b = sorted(random.sample(range(len(c1)), 2))
                c1[a:b], c2[a:b] = elite[a:b], elite[a:b]
            else:
                c1, c2 = crossover(c1, c2)

        for c in [c1, c2]:
            if random.random() < active_mut_pb:
                if elite_memory and random.random() < e_mut_pb:
                    elite = random.choice(elite_memory)
                    pos = random.randrange(len(c))
                    c[pos] = elite[pos]
                else:
                    if stagnated:
                        strategies = ['TW', 'ECO', 'R']
                        weights = [30, 50, 20]
                    else:
                        strategies = ['TW', 'ECO', 'R']
                        weights = [45, 40, 15]
                    choice = random.choices(strategies, weights=weights, k=1)[0]
                    if choice == 'TW':
                        c, = time_window_aware_mutation(c)
                    elif choice == 'ECO':
                        c, = economic_structure_mutation(c)
                    else:
                        c, = random_mode_mutation(c)

            offspring.append(repair_individual(c))

    off_objs = [evaluate_individual(ind) for ind in offspring]
    return select_nsga2(pop + offspring, objs + off_objs, len(pop)) + (elite_memory,)



# =====================================================================
# 【五】 初始种群策略库 (包含基线算法与 HPP 15.1 纯净学术版)
# =====================================================================
def sample_direct_id(ind):
    """优先复用已有 direct drone id，避免无意义增加固定成本。"""
    used = sorted({g[1] for g in ind if len(g) >= 2 and g[0] == 1})
    unused = [d for d in range(num_drones) if d not in used]
    if used and (not unused or random.random() < 0.80):
        return random.choice(used)
    return random.choice(unused) if unused else random.randrange(num_drones)


def sample_car_id(ind, vid):
    """优先复用该 truck 已启用的 car-drone id。"""
    used = sorted({g[2] for g in ind if len(g) == 3 and g[0] == 2 and g[1] == vid})
    unused = [d for d in range(num_car_drones) if d not in used]
    if used and (not unused or random.random() < 0.80):
        return random.choice(used)
    return random.choice(unused) if unused else random.randrange(num_car_drones)

def init_population_random(pop_size, n_customers):
    """【基准】完全随机初始化"""
    pop = []
    for _ in range(pop_size):
        ind = []
        for i in range(n_customers):
            mode = random.choice(customer_allowed[i])
            if mode == 0:
                ind.append((0, random.randrange(num_vehicles)))
            elif mode == 1:
                ind.append((1, sample_direct_id(ind)))
            else:
                vid = random.randrange(num_vehicles)
                ind.append((2, vid, sample_car_id(ind, vid)))
        pop.append(repair_individual(ind))
    return pop



def _compute_csi_scores(candidate_idx):
    scores = []
    for i in candidate_idx:
        if 1 not in customer_allowed[i]:
            continue
        dist_depot = calculate_distance_from_warehouse(customer_positions[i])
        min_neighbor = min([calculate_distance(customer_positions[i], customer_positions[j])
                            for j in candidate_idx if i != j] + [1e9])
        csi_score = (min_neighbor * VEHICLE_UNIT_COST) - (dist_depot * 2 * DRONE_UNIT_COST)
        scores.append((i, csi_score))
    scores.sort(key=lambda x: x[1], reverse=True)
    return scores


def _cluster_centers(points, labels, k):
    centers = {}
    for c in range(k):
        cluster_pts = [points[j] for j in range(len(points)) if labels[j] == c]
        if cluster_pts:
            centers[c] = (
                sum(p[0] for p in cluster_pts) / len(cluster_pts),
                sum(p[1] for p in cluster_pts) / len(cluster_pts),
            )
        else:
            centers[c] = points[random.randrange(len(points))]
    return centers


def _assign_cluster_modes(unassigned_idx, k, bridge_ratio=0.0):
    if not unassigned_idx:
        return {}

    unassigned_pos = [customer_positions[i] for i in unassigned_idx]
    if len(unassigned_idx) <= k:
        labels = list(range(len(unassigned_idx)))
        k_eff = len(unassigned_idx)
    else:
        labels = custom_kmeans(unassigned_pos, k=k)
        k_eff = k

    centers = _cluster_centers(unassigned_pos, labels, k_eff)
    assign = {}

    for c in range(k_eff):
        cluster_nodes = [unassigned_idx[j] for j in range(len(unassigned_idx)) if labels[j] == c]
        cluster_nodes.sort(key=lambda x: calculate_distance(customer_positions[x], centers[c]), reverse=True)
        bridge_candidates = [i for i in cluster_nodes if 2 in customer_allowed[i]]
        bridge_limit = int(round(len(cluster_nodes) * bridge_ratio))
        bridge_limit = min(len(bridge_candidates), bridge_limit)
        bridge_set = set(bridge_candidates[:bridge_limit])

        for global_i in cluster_nodes:
            if global_i in bridge_set:
                assign[global_i] = (2, c, random.randrange(num_car_drones))
            else:
                assign[global_i] = (0, c)
    return assign


def init_population_kmeans_std(pop_size, n_customers):
    """
    纯净 KMeans 基线：
    - 标准空间聚类
    - 不做 CSI 经济剥离
    - 不做簇边缘车载桥接
    """
    pop = []
    n_cluster = int(pop_size * 0.85)

    for _ in range(n_cluster):
        ind = [None] * n_customers
        unassigned_idx = list(range(n_customers))
        k_trucks = max(1, min(num_vehicles, len(unassigned_idx)))  # 普通 KMeans：固定 k
        assignments = _assign_cluster_modes(unassigned_idx, k_trucks, bridge_ratio=0.0)
        for idx, gene in assignments.items():
            ind[idx] = gene
        pop.append(repair_individual(ind))

    while len(pop) < pop_size:
        pop.append(repair_individual(init_population_random(1, n_customers)[0]))
    return pop


def _mode_caps(n_customers):
    if n_customers <= 20:
        return 1, 1
    if n_customers <= 40:
        return 2, 2
    return max(2, math.ceil(n_customers * 0.05)), max(2, math.ceil(n_customers * 0.08))


def _sample_active_k(n_customers, spread=5):
    """不把 k 固死：在 [high-spread, high] 区间内随机取有效 truck 数。"""
    high_k = max(1, min(num_vehicles, n_customers))
    low_k = max(1, high_k - min(spread, max(0, high_k - 1)))
    return random.randint(low_k, high_k)


def _sample_k_from_band(n_customers, gap_low=0, gap_high=2):
    """
    在 [high-gap_high, high-gap_low] 这个区间里取 k。
    例如：
    - 高 k 类：gap_low=0, gap_high=2  -> [high-2, high]
    - 中 k 类：gap_low=3, gap_high=5  -> [high-5, high-3]
    """
    high_k = max(1, min(num_vehicles, n_customers))
    k_min = max(1, high_k - gap_high)
    k_max = max(k_min, high_k - gap_low)
    return random.randint(k_min, k_max)


def _build_truck_kmeans_band_ind(n_customers, gap_low=0, gap_high=2):
    ind = [None] * n_customers
    k_trucks = _sample_k_from_band(n_customers, gap_low, gap_high)
    assignments = _assign_cluster_modes(list(range(n_customers)), k_trucks, bridge_ratio=0.0)
    for idx, gene in assignments.items():
        ind[idx] = (0, gene[1])
    return repair_individual(ind)


def _build_truck_only_kmeans_ind(n_customers):
    ind = [None] * n_customers
    k_trucks = _sample_active_k(n_customers, spread=5)
    assignments = _assign_cluster_modes(list(range(n_customers)), k_trucks, bridge_ratio=0.0)
    for idx, gene in assignments.items():
        ind[idx] = (0, gene[1])
    return repair_individual(ind)


def _cluster_centers_from_ind(ind):
    truck_nodes = defaultdict(list)
    for i, gene in enumerate(ind):
        if gene[0] in (0, 2):
            truck_nodes[gene[1]].append(i)
    centers = {}
    for vid, nodes in truck_nodes.items():
        if nodes:
            centers[vid] = (
                sum(customer_positions[i][0] for i in nodes) / len(nodes),
                sum(customer_positions[i][1] for i in nodes) / len(nodes),
            )
    return truck_nodes, centers


def _nearest_truck_vid(idx, centers):
    if not centers:
        return 0
    return min(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))


def promote_profit_guided_modes(ind, direct_ratio=0.08, car_ratio=0.08):
    ind = list(ind)
    n_customers = len(ind)
    max_direct, max_car = _mode_caps(n_customers)

    csi_scores = _compute_csi_scores(list(range(n_customers)))
    positive_direct = [i for i, sc in csi_scores if sc > 0 and ind[i][0] == 0 and 1 in customer_allowed[i]]
    direct_limit = min(max_direct, max(0, int(round(n_customers * direct_ratio))))
    for i in positive_direct[:direct_limit]:
        ind[i] = (1, sample_direct_id(ind))

    truck_nodes, centers = _cluster_centers_from_ind(ind)
    car_candidates = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if ind[i][0] == 0 and 2 in customer_allowed[i]:
                edge_score = calculate_distance(customer_positions[i], center)
                car_candidates.append((edge_score, i, vid))

    car_candidates.sort(reverse=True)
    car_limit = min(max_car, max(0, int(round(n_customers * car_ratio))))
    for _, i, vid in car_candidates[:car_limit]:
        if ind[i][0] == 0:
            ind[i] = (2, vid, 0)

    return repair_individual(ind)


def economic_screening_repair(ind):
    ind = list(ind)
    n_customers = len(ind)
    max_direct, max_car = _mode_caps(n_customers)
    csi_map = {i: sc for i, sc in _compute_csi_scores(list(range(n_customers)))}
    truck_nodes, centers = _cluster_centers_from_ind(ind)

    directs = [i for i, gene in enumerate(ind) if gene[0] == 1]
    directs_sorted = sorted(directs, key=lambda i: csi_map.get(i, -1e18), reverse=True)
    keep_direct = set(directs_sorted[:max_direct])
    for i in directs:
        if i not in keep_direct or csi_map.get(i, -1e18) <= 0:
            vid = _nearest_truck_vid(i, centers)
            ind[i] = (0, vid)

    truck_nodes, centers = _cluster_centers_from_ind(ind)
    cars = [i for i, gene in enumerate(ind) if gene[0] == 2]
    def car_score(i):
        vid = ind[i][1]
        center = centers.get(vid, customer_positions[i])
        return calculate_distance(customer_positions[i], center)
    cars_sorted = sorted(cars, key=car_score, reverse=True)
    keep_car = set(cars_sorted[:max_car])
    for i in cars:
        vid = ind[i][1]
        if i not in keep_car or len(truck_nodes.get(vid, [])) <= 1:
            ind[i] = (0, vid)

    return repair_individual(ind)


def _build_medium_collab_seed(n_customers, direct_low=3, direct_high=6, car_low=2, car_high=4):
    """中协同种子：保留 truck 骨架，但主动放入少量直飞/车载。"""
    ind = _build_truck_kmeans_band_ind(n_customers, gap_low=1, gap_high=4)

    csi_scores = _compute_csi_scores(list(range(n_customers)))
    direct_candidates = [i for i, sc in csi_scores if sc > 0 and 1 in customer_allowed[i] and ind[i][0] == 0]
    direct_target = min(len(direct_candidates), random.randint(direct_low, direct_high))
    for i in direct_candidates[:direct_target]:
        ind[i] = (1, sample_direct_id(ind))

    truck_nodes, centers = _cluster_centers_from_ind(ind)
    car_candidates = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if ind[i][0] == 0 and 2 in customer_allowed[i]:
                edge_score = calculate_distance(customer_positions[i], center)
                car_candidates.append((edge_score, i, vid))
    car_candidates.sort(reverse=True)
    car_target = min(len(car_candidates), random.randint(car_low, car_high))
    for _, i, vid in car_candidates[:car_target]:
        ind[i] = (2, vid, sample_car_id(ind, vid))

    return economic_screening_repair(repair_individual(ind))


def _build_direct_priority_seed(n_customers, direct_low=5, direct_high=9, car_low=1, car_high=2):
    """直飞优先种子：优先把 CSI 高、仓库直飞有优势的点交给 direct。"""
    ind = _build_truck_kmeans_band_ind(n_customers, gap_low=0, gap_high=3)
    csi_scores = _compute_csi_scores(list(range(n_customers)))
    direct_candidates = [i for i, sc in csi_scores if sc > 0 and 1 in customer_allowed[i] and ind[i][0] == 0]
    direct_target = min(len(direct_candidates), random.randint(direct_low, direct_high))
    for i in direct_candidates[:direct_target]:
        ind[i] = (1, sample_direct_id(ind))

    truck_nodes, centers = _cluster_centers_from_ind(ind)
    car_candidates = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if ind[i][0] == 0 and 2 in customer_allowed[i]:
                edge_score = calculate_distance(customer_positions[i], center)
                car_candidates.append((edge_score, i, vid))
    car_candidates.sort(reverse=True)
    car_target = min(len(car_candidates), random.randint(car_low, car_high))
    for _, i, vid in car_candidates[:car_target]:
        ind[i] = (2, vid, sample_car_id(ind, vid))
    return economic_screening_repair(repair_individual(ind))


def _build_car_local_seed(n_customers, direct_low=1, direct_high=3, car_low=5, car_high=8):
    """车载局部优化种子：把各簇较远边缘点优先改成 carried drone。"""
    ind = _build_truck_kmeans_band_ind(n_customers, gap_low=1, gap_high=4)
    truck_nodes, centers = _cluster_centers_from_ind(ind)

    car_candidates = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if ind[i][0] == 0 and 2 in customer_allowed[i]:
                edge_score = calculate_distance(customer_positions[i], center)
                car_candidates.append((edge_score, i, vid))
    car_candidates.sort(reverse=True)
    car_target = min(len(car_candidates), random.randint(car_low, car_high))
    for _, i, vid in car_candidates[:car_target]:
        ind[i] = (2, vid, sample_car_id(ind, vid))

    # 再补少量 direct，用来修刺头
    csi_scores = _compute_csi_scores(list(range(n_customers)))
    direct_candidates = [i for i, sc in csi_scores if sc > 0 and 1 in customer_allowed[i] and ind[i][0] == 0]
    direct_target = min(len(direct_candidates), random.randint(direct_low, direct_high))
    for i in direct_candidates[:direct_target]:
        ind[i] = (1, sample_direct_id(ind))

    return economic_screening_repair(repair_individual(ind))


def _build_hybrid_service_seed(n_customers, direct_low=4, direct_high=7, car_low=4, car_high=7):
    """直飞 + 车载都比较积极的混合种子。"""
    ind = _build_truck_kmeans_band_ind(n_customers, gap_low=1, gap_high=4)

    csi_scores = _compute_csi_scores(list(range(n_customers)))
    direct_candidates = [i for i, sc in csi_scores if sc > 0 and 1 in customer_allowed[i] and ind[i][0] == 0]
    direct_target = min(len(direct_candidates), random.randint(direct_low, direct_high))
    for i in direct_candidates[:direct_target]:
        ind[i] = (1, sample_direct_id(ind))

    truck_nodes, centers = _cluster_centers_from_ind(ind)
    car_candidates = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if ind[i][0] == 0 and 2 in customer_allowed[i]:
                edge_score = calculate_distance(customer_positions[i], center)
                car_candidates.append((edge_score, i, vid))
    car_candidates.sort(reverse=True)
    car_target = min(len(car_candidates), random.randint(car_low, car_high))
    for _, i, vid in car_candidates[:car_target]:
        ind[i] = (2, vid, sample_car_id(ind, vid))

    return economic_screening_repair(repair_individual(ind))

def init_population_hpp(pop_size, n_customers):
    """
    v23 初始化：
    - 保留低成本 truck 骨架
    - 强化直飞种子
    - 强化车载局部种子
    - 保留直飞+车载混合种子
    """
    pop = []

    n_cost = int(pop_size * 0.20)
    n_direct = int(pop_size * 0.20)
    n_car = int(pop_size * 0.20)
    n_hybrid = int(pop_size * 0.20)
    structured_target = int(pop_size * 0.90)

    for _ in range(n_cost):
        ind = _build_truck_kmeans_band_ind(n_customers, gap_low=0, gap_high=2)
        pop.append(repair_individual(ind))

    for _ in range(n_direct):
        pop.append(_build_direct_priority_seed(n_customers, 5, 9, 1, 2))

    for _ in range(n_car):
        pop.append(_build_car_local_seed(n_customers, 1, 3, 5, 8))

    for _ in range(n_hybrid):
        pop.append(_build_hybrid_service_seed(n_customers, 4, 7, 4, 7))

    while len(pop) < structured_target:
        # 补一些偏服务但不过重的混合 seed
        ind = _build_hybrid_service_seed(n_customers, 4, 6, 3, 5)
        pop.append(repair_individual(ind))

    while len(pop) < pop_size:
        pop.append(init_population_random(1, n_customers)[0])

    return pop[:pop_size]

def penalty_lns_repair(ind, top_m=4):
    """后段温和修复：连续处理 top-m 迟到客户，但只做轻改动。"""
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])[:top_m]
    ind = list(ind)
    if not tardy_nodes:
        return repair_individual(ind)

    for worst_idx in tardy_nodes:
        if worst_idx is None or worst_idx >= len(ind):
            continue
        allow = customer_allowed[worst_idx]
        truck_nodes, centers = _cluster_centers_from_ind(ind)
        used_trucks = set(truck_nodes.keys())
        free_trucks = [v for v in range(num_vehicles) if v not in used_trucks]
        nearest_vid = _nearest_truck_vid(worst_idx, centers)

        if 0 in allow and free_trucks:
            ind[worst_idx] = (0, free_trucks[0])
        elif 1 in allow:
            ind[worst_idx] = (1, random.randrange(num_drones))
        elif 2 in allow:
            ind[worst_idx] = (2, nearest_vid, 0)
        elif 0 in allow:
            ind[worst_idx] = (0, nearest_vid)

    return repair_individual(ind)


def direct_rescue_lns(ind, top_m=4):
    """直飞救刺头：对 top tardy customers 优先尝试 direct。"""
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])[:top_m]
    best_ind = list(ind)
    best_obj = evaluate_individual(best_ind)
    for idx in tardy_nodes:
        if idx is None or idx >= len(best_ind) or 1 not in customer_allowed[idx]:
            continue
        for did in range(num_drones):
            cand = list(best_ind)
            cand[idx] = (1, did)
            cand = repair_individual(cand)
            obj = evaluate_individual(cand)
            if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                best_ind, best_obj = cand, obj
    return best_ind, best_obj


def car_bridge_lns(ind, top_m=4):
    """车载接边缘：把 top tardy/edge customers 挂到最近 truck 上。"""
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])[:top_m]
    best_ind = list(ind)
    best_obj = evaluate_individual(best_ind)
    truck_nodes, centers = _cluster_centers_from_ind(best_ind)

    for idx in tardy_nodes:
        if idx is None or idx >= len(best_ind) or 2 not in customer_allowed[idx]:
            continue
        if not centers:
            continue
        near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))[:2]
        for vid in near_vids:
            for cdid in range(num_car_drones):
                cand = list(best_ind)
                cand[idx] = (2, vid, cdid)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                    best_ind, best_obj = cand, obj
    return best_ind, best_obj


def truck_reanchor_lns(ind, top_m=4):
    """Truck 兜底：给迟到客户换更合适的 truck。"""
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(ind), [])[:top_m]
    best_ind = list(ind)
    best_obj = evaluate_individual(best_ind)
    truck_nodes, centers = _cluster_centers_from_ind(best_ind)
    used_trucks = set(truck_nodes.keys())
    free_trucks = [v for v in range(num_vehicles) if v not in used_trucks]

    for idx in tardy_nodes:
        if idx is None or idx >= len(best_ind) or 0 not in customer_allowed[idx]:
            continue
        candidate_vids = free_trucks[:2]
        if centers:
            near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))[:2]
            candidate_vids += near_vids
        candidate_vids = list(dict.fromkeys(candidate_vids))
        for vid in candidate_vids:
            cand = list(best_ind)
            cand[idx] = (0, vid)
            cand = repair_individual(cand)
            obj = evaluate_individual(cand)
            if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                best_ind, best_obj = cand, obj
    return best_ind, best_obj


def mode_swap_lns(ind, sample_n=4):
    """模式互换：把已有 aerial 客户在 direct / car / truck 间切换。"""
    best_ind = list(ind)
    best_obj = evaluate_individual(best_ind)
    aerial_idx = [i for i, g in enumerate(best_ind) if g[0] in (1, 2)]
    random.shuffle(aerial_idx)
    aerial_idx = aerial_idx[:sample_n]
    truck_nodes, centers = _cluster_centers_from_ind(best_ind)

    for idx in aerial_idx:
        allow = customer_allowed[idx]
        candidates = []

        if 1 in allow:
            for did in range(num_drones):
                cand = list(best_ind)
                cand[idx] = (1, did)
                candidates.append(repair_individual(cand))

        if 2 in allow and centers:
            near_vid = _nearest_truck_vid(idx, centers)
            for cdid in range(num_car_drones):
                cand = list(best_ind)
                cand[idx] = (2, near_vid, cdid)
                candidates.append(repair_individual(cand))

        if 0 in allow:
            near_vid = _nearest_truck_vid(idx, centers) if centers else 0
            cand = list(best_ind)
            cand[idx] = (0, near_vid)
            candidates.append(repair_individual(cand))

        for cand in candidates:
            obj = evaluate_individual(cand)
            if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                best_ind, best_obj = cand, obj

    return best_ind, best_obj


def air_service_counts(ind):
    d_cnt = sum(1 for g in ind if g[0] == 1)
    c_cnt = sum(1 for g in ind if g[0] == 2)
    return d_cnt, c_cnt


def adaptive_air_quota(curr_min_pen, curr_min_time):
    """在 v13 上做轻量 direct-bias，不把 car 推太重。"""
    if curr_min_pen >= 1500:
        return 5, 3
    elif curr_min_pen >= 800:
        return 4, 3
    else:
        return 3, 3

def force_air_quota_repair(ind, direct_target, car_target):
    """对空中客户数量不足的个体，强制补足一轮 direct/car 候选。"""
    best_ind = list(ind)
    best_obj = evaluate_individual(best_ind)

    d_cnt, c_cnt = air_service_counts(best_ind)
    truck_nodes, centers = _cluster_centers_from_ind(best_ind)

    # direct 候选：tardy + 高 CSI
    if d_cnt < direct_target:
        tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(best_ind), [])[:max(3, direct_target - d_cnt + 2)]
        csi_scores = _compute_csi_scores(list(range(len(best_ind))))
        csi_nodes = [i for i, sc in csi_scores if sc > 0]
        direct_candidates = list(dict.fromkeys(tardy_nodes + csi_nodes))[:max(4, direct_target - d_cnt + 3)]
        for idx in direct_candidates:
            if idx is None or idx >= len(best_ind) or 1 not in customer_allowed[idx]:
                continue
            for did in range(num_drones):
                cand = list(best_ind)
                cand[idx] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                    best_ind, best_obj = cand, obj

    # car 候选：边缘点 + tardy
    d_cnt, c_cnt = air_service_counts(best_ind)
    if c_cnt < car_target:
        truck_nodes, centers = _cluster_centers_from_ind(best_ind)
        edge_nodes = []
        for vid, nodes in truck_nodes.items():
            if not nodes:
                continue
            center = centers[vid]
            for i in nodes:
                if best_ind[i][0] == 0 and 2 in customer_allowed[i]:
                    edge_score = calculate_distance(customer_positions[i], center)
                    edge_nodes.append((edge_score, i))
        edge_nodes = [i for _, i in sorted(edge_nodes, reverse=True)]
        tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(best_ind), [])[:max(3, car_target - c_cnt + 2)]
        car_candidates = list(dict.fromkeys(tardy_nodes + edge_nodes))[:max(4, car_target - c_cnt + 3)]
        for idx in car_candidates:
            if idx is None or idx >= len(best_ind) or 2 not in customer_allowed[idx] or not centers:
                continue
            near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))[:2]
            for vid in near_vids:
                for cdid in range(num_car_drones):
                    cand = list(best_ind)
                    cand[idx] = (2, vid, cdid)
                    cand = repair_individual(cand)
                    obj = evaluate_individual(cand)
                    if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                        best_ind, best_obj = cand, obj

    return best_ind, best_obj


def _select_from_indices_nsga(indices, objs, k):
    if k <= 0 or not indices:
        return []
    if len(indices) <= k:
        return indices[:]

    sub_objs = [objs[i] for i in indices]
    fronts = fast_nondominated_sort(normalize_objs(sub_objs))
    chosen_local = []
    for front in fronts:
        front_global = [indices[i] for i in front]
        if len(chosen_local) + len(front_global) <= k:
            chosen_local.extend(front_global)
        else:
            dist = crowding_distance(front_global, objs)
            chosen_local.extend(sorted(front_global, key=lambda i: -dist[i])[:k - len(chosen_local)])
            break
    return chosen_local


def mode_stratified_reselect(pop, objs, k):
    """按空中客户数量分层保留：低协同 / 中协同 / 高协同。"""
    low, mid, high = [], [], []
    for i, ind in enumerate(pop):
        d_cnt, c_cnt = air_service_counts(ind)
        air_cnt = d_cnt + c_cnt
        if air_cnt <= 2:
            low.append(i)
        elif air_cnt <= 8:
            mid.append(i)
        else:
            high.append(i)

    keep_low = int(k * 0.25)
    keep_mid = int(k * 0.50)
    keep_high = k - keep_low - keep_mid

    selected = []
    selected += _select_from_indices_nsga(low, objs, min(keep_low, len(low)))
    selected += _select_from_indices_nsga(mid, objs, min(keep_mid, len(mid)))
    selected += _select_from_indices_nsga(high, objs, min(keep_high, len(high)))

    if len(selected) < k:
        remaining = [i for i in range(len(pop)) if i not in selected]
        selected += _select_from_indices_nsga(remaining, objs, k - len(selected))

    selected = selected[:k]
    return [pop[i] for i in selected], [objs[i] for i in selected]


def service_first_multimode_lns(ind, top_m=6, sweeps=2):
    """围绕 top tardy customers 做多轮三模式联合修复，目标先打到 0 罚分。"""
    current = list(ind)
    current_obj = evaluate_individual(current)

    for _ in range(sweeps):
        improved = False
        tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(current), [])[:top_m]
        if not tardy_nodes:
            break

        for idx in tardy_nodes:
            if idx is None or idx >= len(current):
                continue

            allow = customer_allowed[idx]
            truck_nodes, centers = _cluster_centers_from_ind(current)
            used_trucks = set(truck_nodes.keys())
            free_trucks = [v for v in range(num_vehicles) if v not in used_trucks]
            near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))[:2] if centers else [0]

            candidates = []

            # 1) direct
            if 1 in allow:
                for did in range(num_drones):
                    cand = list(current)
                    cand[idx] = (1, did)
                    candidates.append(repair_individual(cand))

            # 2) car-drone
            if 2 in allow:
                for vid in near_vids:
                    for cdid in range(num_car_drones):
                        cand = list(current)
                        cand[idx] = (2, vid, cdid)
                        candidates.append(repair_individual(cand))

            # 3) truck
            if 0 in allow:
                truck_choices = free_trucks[:2] + near_vids
                truck_choices = list(dict.fromkeys(truck_choices))
                for vid in truck_choices:
                    cand = list(current)
                    cand[idx] = (0, vid)
                    candidates.append(repair_individual(cand))

            best_local_ind, best_local_obj = current, current_obj
            for cand in candidates:
                obj = evaluate_individual(cand)
                if (obj[2], obj[1], obj[0]) < (best_local_obj[2], best_local_obj[1], best_local_obj[0]):
                    best_local_ind, best_local_obj = cand, obj

            if (best_local_obj[2], best_local_obj[1], best_local_obj[0]) < (current_obj[2], current_obj[1], current_obj[0]):
                current, current_obj = best_local_ind, best_local_obj
                improved = True

        if not improved:
            break

    return current, current_obj


def time_squeeze_lns(ind, sample_n=6):
    """在低罚分/0罚分基础上，优先用车载压时间。"""
    current = list(ind)
    current_obj = evaluate_individual(current)
    truck_nodes, centers = _cluster_centers_from_ind(current)

    # 先选边缘 truck 客户 + 一些 aerial 客户做模式微调
    edge_nodes = []
    for vid, nodes in truck_nodes.items():
        if not nodes:
            continue
        center = centers[vid]
        for i in nodes:
            if current[i][0] == 0:
                edge_nodes.append((calculate_distance(customer_positions[i], center), i))
    edge_nodes = [i for _, i in sorted(edge_nodes, reverse=True)[:sample_n]]

    aerial_nodes = [i for i, g in enumerate(current) if g[0] in (1, 2)]
    random.shuffle(aerial_nodes)
    candidates_idx = list(dict.fromkeys(edge_nodes + aerial_nodes[:sample_n]))

    for idx in candidates_idx:
        allow = customer_allowed[idx]
        best_local_ind, best_local_obj = current, current_obj

        if 2 in allow and centers:
            near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))[:2]
            for vid in near_vids:
                for cdid in range(num_car_drones):
                    cand = list(current)
                    cand[idx] = (2, vid, cdid)
                    cand = repair_individual(cand)
                    obj = evaluate_individual(cand)
                    if (obj[1], obj[2], obj[0]) < (best_local_obj[1], best_local_obj[2], best_local_obj[0]):
                        best_local_ind, best_local_obj = cand, obj

        if 1 in allow:
            for did in range(num_drones):
                cand = list(current)
                cand[idx] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if (obj[1], obj[2], obj[0]) < (best_local_obj[1], best_local_obj[2], best_local_obj[0]):
                    best_local_ind, best_local_obj = cand, obj

        if best_local_obj[2] <= current_obj[2] + 1e-6 and best_local_obj[1] < current_obj[1] - 1e-6:
            current, current_obj = best_local_ind, best_local_obj

    return current, current_obj


def cost_cleanup_lns(ind, sample_n=6):
    """对 0 罚分/低罚分解回收不必要的空中模式，压成本但不放飞 penalty。"""
    current = list(ind)
    current_obj = evaluate_individual(current)
    aerial_nodes = [i for i, g in enumerate(current) if g[0] in (1, 2)]
    random.shuffle(aerial_nodes)
    aerial_nodes = aerial_nodes[:sample_n]

    truck_nodes, centers = _cluster_centers_from_ind(current)
    for idx in aerial_nodes:
        allow = customer_allowed[idx]
        best_local_ind, best_local_obj = current, current_obj

        # 优先尝试拉回 truck
        if 0 in allow:
            near_vid = _nearest_truck_vid(idx, centers) if centers else 0
            cand = list(current)
            cand[idx] = (0, near_vid)
            cand = repair_individual(cand)
            obj = evaluate_individual(cand)
            if obj[2] <= current_obj[2] + 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                best_local_ind, best_local_obj = cand, obj

        # car -> direct / direct -> car
        if allow and current[idx][0] == 2 and 1 in allow:
            for did in range(num_drones):
                cand = list(current)
                cand[idx] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if obj[2] <= current_obj[2] + 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                    best_local_ind, best_local_obj = cand, obj

        if allow and current[idx][0] == 1 and 2 in allow and centers:
            near_vid = _nearest_truck_vid(idx, centers)
            for cdid in range(num_car_drones):
                cand = list(current)
                cand[idx] = (2, near_vid, cdid)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if obj[2] <= current_obj[2] + 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                    best_local_ind, best_local_obj = cand, obj

        if best_local_obj[0] < current_obj[0] - 1e-6:
            current, current_obj = best_local_ind, best_local_obj

    return current, current_obj



def zero_penalty_cleanup_lns(ind, sample_n=8):
    """在 0 罚分前提下，优先删冗余 car，再删冗余 direct，尽量回收成本。"""
    current = list(ind)
    current_obj = evaluate_individual(current)
    if current_obj[2] > 1e-6:
        return current, current_obj

    car_nodes = [i for i, g in enumerate(current) if g[0] == 2]
    direct_nodes = [i for i, g in enumerate(current) if g[0] == 1]
    target_nodes = car_nodes[:sample_n] + direct_nodes[:sample_n]

    truck_nodes, centers = _cluster_centers_from_ind(current)
    for idx in target_nodes:
        allow = customer_allowed[idx]
        best_local_ind, best_local_obj = current, current_obj

        # 1) 优先拉回 truck
        if 0 in allow:
            near_vid = _nearest_truck_vid(idx, centers) if centers else 0
            cand = list(current)
            cand[idx] = (0, near_vid)
            cand = repair_individual(cand)
            obj = evaluate_individual(cand)
            if obj[2] <= 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                best_local_ind, best_local_obj = cand, obj

        # 2) car -> direct
        if current[idx][0] == 2 and 1 in allow:
            for did in range(num_drones):
                cand = list(current)
                cand[idx] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if obj[2] <= 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                    best_local_ind, best_local_obj = cand, obj

        # 3) direct -> car
        if current[idx][0] == 1 and 2 in allow and centers:
            near_vid = _nearest_truck_vid(idx, centers)
            for cdid in range(num_car_drones):
                cand = list(current)
                cand[idx] = (2, near_vid, cdid)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if obj[2] <= 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                    best_local_ind, best_local_obj = cand, obj

        if best_local_obj[0] < current_obj[0] - 1e-6:
            current, current_obj = best_local_ind, best_local_obj
            truck_nodes, centers = _cluster_centers_from_ind(current)

    return current, current_obj


def car_removal_cleanup_lns(ind, sample_n=6):
    """
    专门针对 0 罚分重车载解的瘦身：
    - 先删 1 个 car
    - 再允许小范围重修复（direct / truck）
    - 目标：保持 penalty=0，并尽量降成本
    """
    current = list(ind)
    current_obj = evaluate_individual(current)
    if current_obj[2] > 1e-6:
        return current, current_obj

    car_nodes = [i for i, g in enumerate(current) if g[0] == 2]
    truck_nodes, centers = _cluster_centers_from_ind(current)

    # 优先删那些靠近 truck 中心、理论上更容易拉回地面/直飞的 car
    scored = []
    for idx in car_nodes:
        vid = current[idx][1]
        center = centers.get(vid, customer_positions[idx]) if centers else customer_positions[idx]
        dist_to_center = calculate_distance(customer_positions[idx], center)
        scored.append((dist_to_center, idx))
    scored = [idx for _, idx in sorted(scored)[:sample_n]]

    for idx in scored:
        allow = customer_allowed[idx]
        best_local_ind, best_local_obj = current, current_obj

        single_candidates = []

        # A. 删 1 car -> truck
        if 0 in allow:
            near_vid = _nearest_truck_vid(idx, centers) if centers else 0
            cand = list(current)
            cand[idx] = (0, near_vid)
            cand = repair_individual(cand)
            cand, obj = service_first_multimode_lns(cand, top_m=3, sweeps=1)
            single_candidates.append((cand, obj))

        # B. 删 1 car -> direct
        if 1 in allow:
            for did in range(num_drones):
                cand = list(current)
                cand[idx] = (1, did)
                cand = repair_individual(cand)
                cand, obj = service_first_multimode_lns(cand, top_m=3, sweeps=1)
                single_candidates.append((cand, obj))

        # C. 删 1 car，同时把另一个高迟到 truck 客户转成 direct 作为补偿
        tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(current), [])[:3]
        for j in tardy_nodes:
            if j is None or j == idx or j >= len(current):
                continue
            if 1 not in customer_allowed[j]:
                continue
            for did in range(num_drones):
                cand = list(current)
                if 0 in allow:
                    near_vid = _nearest_truck_vid(idx, centers) if centers else 0
                    cand[idx] = (0, near_vid)
                elif 1 in allow:
                    cand[idx] = (1, did)
                cand[j] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                single_candidates.append((cand, obj))

        for cand, obj in single_candidates:
            # 必须保持 0 罚分；时间允许轻微上升；成本必须下降
            if obj[2] <= 1e-6 and obj[1] <= current_obj[1] + 120 and obj[0] < best_local_obj[0] - 1e-6:
                best_local_ind, best_local_obj = cand, obj

        if best_local_obj[0] < current_obj[0] - 1e-6:
            current, current_obj = best_local_ind, best_local_obj
            truck_nodes, centers = _cluster_centers_from_ind(current)

    return current, current_obj


def block_car_removal_lns(ind, remove_k=2, candidate_pool=5):
    """
    成组删车载 + 局部重构：
    - 从 0 penalty 重车载解里选 2~3 个 car
    - 一次性拿掉
    - 再对这几个客户做局部模式重分配
    目标：保持 penalty=0，同时压成本。
    """
    import itertools

    current = list(ind)
    current_obj = evaluate_individual(current)
    if current_obj[2] > 1e-6:
        return current, current_obj

    car_nodes = [i for i, g in enumerate(current) if g[0] == 2]
    if len(car_nodes) < remove_k:
        return current, current_obj

    truck_nodes, centers = _cluster_centers_from_ind(current)

    # 候选 car：优先挑“更靠近 truck 中心”的，理论上更容易删掉
    scored = []
    for idx in car_nodes:
        vid = current[idx][1]
        center = centers.get(vid, customer_positions[idx]) if centers else customer_positions[idx]
        dist_to_center = calculate_distance(customer_positions[idx], center)
        scored.append((dist_to_center, idx))
    candidate_nodes = [idx for _, idx in sorted(scored)[:candidate_pool]]

    best_ind, best_obj = current, current_obj

    combo_sizes = [remove_k]
    if len(candidate_nodes) >= remove_k + 1:
        combo_sizes.append(remove_k + 1)

    for r in combo_sizes:
        for combo in itertools.combinations(candidate_nodes, r):
            cand = list(current)

            # 第一步：先把这些 car 全部拿回 truck
            for idx in combo:
                allow = customer_allowed[idx]
                if 0 in allow:
                    near_vid = _nearest_truck_vid(idx, centers) if centers else 0
                    cand[idx] = (0, near_vid)

            cand = repair_individual(cand)

            # 第二步：只在 combo 内做局部重分配，允许 direct / car / truck
            local_current = list(cand)
            local_obj = evaluate_individual(local_current)

            for idx in combo:
                allow = customer_allowed[idx]
                truck_nodes2, centers2 = _cluster_centers_from_ind(local_current)
                near_vids = sorted(centers2.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers2[vid]))[:2] if centers2 else [0]

                local_candidates = []

                if 0 in allow:
                    for vid in near_vids:
                        c = list(local_current)
                        c[idx] = (0, vid)
                        local_candidates.append(repair_individual(c))

                if 1 in allow:
                    for did in range(num_drones):
                        c = list(local_current)
                        c[idx] = (1, did)
                        local_candidates.append(repair_individual(c))

                if 2 in allow:
                    for vid in near_vids:
                        for cdid in range(num_car_drones):
                            c = list(local_current)
                            c[idx] = (2, vid, cdid)
                            local_candidates.append(repair_individual(c))

                best_local_ind, best_local_obj = local_current, local_obj
                for c in local_candidates:
                    obj = evaluate_individual(c)
                    if obj[2] <= 1e-6 and obj[1] <= current_obj[1] + 150 and obj[0] < best_local_obj[0] - 1e-6:
                        best_local_ind, best_local_obj = c, obj

                local_current, local_obj = best_local_ind, best_local_obj

            # 第三步：如果有轻微破坏，再做一轮小修复
            if local_obj[2] > 1e-6:
                local_current, local_obj = service_first_multimode_lns(local_current, top_m=3, sweeps=1)

            if local_obj[2] <= 1e-6 and local_obj[1] <= current_obj[1] + 150 and local_obj[0] < best_obj[0] - 1e-6:
                best_ind, best_obj = local_current, local_obj

    return best_ind, best_obj


def zero_penalty_subproblem_rebuild(ind, max_car=6, neighbor_extra=6):
    """
    对 0 罚分重车载解做局部子问题重构：
    - 抽出一批 car 客户
    - 再加一批与其相关的 truck 客户
    - 对这个小子集整体 destroy + rebuild
    目标：保持 penalty=0，时间不明显恶化，同时压成本。
    """
    current = list(ind)
    current_obj = evaluate_individual(current)
    if current_obj[2] > 1e-6:
        return current, current_obj

    car_nodes = [i for i, g in enumerate(current) if g[0] == 2]
    if len(car_nodes) < 2:
        return current, current_obj

    truck_nodes, centers = _cluster_centers_from_ind(current)

    # 1) 先选 car 子集：优先挑更靠近 truck 中心的，理论上更容易回收
    scored_car = []
    for idx in car_nodes:
        vid = current[idx][1]
        center = centers.get(vid, customer_positions[idx]) if centers else customer_positions[idx]
        dist_to_center = calculate_distance(customer_positions[idx], center)
        scored_car.append((dist_to_center, idx))
    chosen_car = [idx for _, idx in sorted(scored_car)[:max_car]]

    # 2) 再补一些相关 truck-only 邻居客户
    truck_only = [i for i, g in enumerate(current) if g[0] == 0]
    support_nodes = []
    for idx in chosen_car:
        near_truck_nodes = sorted(
            truck_only,
            key=lambda j: calculate_distance(customer_positions[idx], customer_positions[j])
        )[:2]
        support_nodes.extend(near_truck_nodes)
    support_nodes = list(dict.fromkeys(support_nodes))[:neighbor_extra]

    subset = list(dict.fromkeys(chosen_car + support_nodes))
    if not subset:
        return current, current_obj

    # 3) destroy：先把 subset 全部拉回最近 truck，作为起点
    rebuild = list(current)
    truck_nodes0, centers0 = _cluster_centers_from_ind(rebuild)
    for idx in subset:
        allow = customer_allowed[idx]
        near_vid = _nearest_truck_vid(idx, centers0) if centers0 else 0
        if 0 in allow:
            rebuild[idx] = (0, near_vid)
        elif 1 in allow:
            rebuild[idx] = (1, 0)
        elif 2 in allow:
            rebuild[idx] = (2, near_vid, 0)

    rebuild = repair_individual(rebuild)
    rebuild_obj = evaluate_individual(rebuild)

    # 4) rebuild：先重建 chosen_car，再重建 support_nodes
    rebuild_order = chosen_car + [i for i in subset if i not in chosen_car]

    for idx in rebuild_order:
        allow = customer_allowed[idx]
        truck_nodes1, centers1 = _cluster_centers_from_ind(rebuild)
        near_vids = sorted(centers1.keys(), key=lambda vid: calculate_distance(customer_positions[idx], centers1[vid]))[:2] if centers1 else [0]

        local_candidates = []

        if 0 in allow:
            for vid in near_vids:
                cand = list(rebuild)
                cand[idx] = (0, vid)
                local_candidates.append(repair_individual(cand))

        if 1 in allow:
            for did in range(num_drones):
                cand = list(rebuild)
                cand[idx] = (1, did)
                local_candidates.append(repair_individual(cand))

        if 2 in allow:
            for vid in near_vids:
                for cdid in range(num_car_drones):
                    cand = list(rebuild)
                    cand[idx] = (2, vid, cdid)
                    local_candidates.append(repair_individual(cand))

        best_local_ind, best_local_obj = rebuild, rebuild_obj
        for cand in local_candidates:
            obj = evaluate_individual(cand)
            # 局部重构阶段：仍然优先保证 penalty，再压 time，再压 cost
            if (obj[2], obj[1], obj[0]) < (best_local_obj[2], best_local_obj[1], best_local_obj[0]):
                best_local_ind, best_local_obj = cand, obj

        rebuild, rebuild_obj = best_local_ind, best_local_obj

    # 5) 接受条件：保 0 罚分，不明显拉坏时间，并压成本
    if rebuild_obj[2] <= 1e-6 and rebuild_obj[1] <= current_obj[1] + 150 and rebuild_obj[0] < current_obj[0] - 1e-6:
        return rebuild, rebuild_obj

    return current, current_obj

def update_service_archive(service_archive, pop, objs, cap=12):
    """维护一份低罚分/低时间 archive，避免 0 罚分解丢失。"""
    candidates = service_archive[:]
    candidates += [(list(pop[i]), objs[i]) for i in range(len(pop))]
    # 去重
    uniq = {}
    for ind, obj in candidates:
        uniq[tuple(ind)] = (list(ind), obj)
    merged = list(uniq.values())
    merged.sort(key=lambda x: (x[1][2], x[1][1], x[1][0]))
    return merged[:cap]


def inject_service_archive(pop, objs, service_archive, replace_k=4):
    if not service_archive:
        return pop, objs
    worst_idx = sorted(range(len(objs)), key=lambda i: (objs[i][2], objs[i][1], objs[i][0]), reverse=True)[:min(replace_k, len(service_archive))]
    for wi, (ind, obj) in zip(worst_idx, service_archive[:len(worst_idx)]):
        pop[wi] = list(ind)
        objs[wi] = obj
    return pop, objs


def update_cost_archive(cost_archive, pop, objs, cap=12):
    candidates = cost_archive[:]
    candidates += [(list(pop[i]), objs[i]) for i in range(len(pop))]
    uniq = {}
    for ind, obj in candidates:
        uniq[tuple(ind)] = (list(ind), obj)
    merged = list(uniq.values())
    merged.sort(key=lambda x: (x[1][0], x[1][2], x[1][1]))
    return merged[:cap]



def update_cost_feasible_archive(cost_feasible_archive, pop, objs, cap=12, pen_cap=100.0):
    """保留低成本且相对可行的骨架。"""
    candidates = cost_feasible_archive[:]
    candidates += [(list(pop[i]), objs[i]) for i in range(len(pop)) if objs[i][2] <= pen_cap]
    uniq = {}
    for ind, obj in candidates:
        key = tuple(ind)
        if key not in uniq or (obj[0], obj[2], obj[1]) < (uniq[key][1][0], uniq[key][1][2], uniq[key][1][1]):
            uniq[key] = (list(ind), obj)
    merged = list(uniq.values())
    merged.sort(key=lambda x: (x[1][0], x[1][2], x[1][1]))
    return merged[:cap]


def guided_bridge_recombine(cost_ind, service_ind):
    """
    桥接重组：
    - 以低成本解为底
    - 只从服务质量解里借用关键 air 模式
    - 用来打破“低成本盆地”和“0罚分盆地”的隔离
    """
    base = list(cost_ind)
    service = list(service_ind)

    # 先计算低成本解的刺头客户
    _ = evaluate_individual(base)
    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(base), [])[:6]

    # 1) 对最迟到客户，优先继承 service parent 的 air 模式
    for idx in tardy_nodes:
        if idx is None or idx >= len(base):
            continue
        if service[idx][0] in (1, 2):
            base[idx] = service[idx]

    # 2) 再随机继承 2~4 个 service parent 的 air customer
    service_air = [i for i, g in enumerate(service) if g[0] in (1, 2)]
    random.shuffle(service_air)
    for idx in service_air[:random.randint(2, 4)]:
        base[idx] = service[idx]

    # 3) 对一些明显“错簇”的 truck 客户尝试借 service parent 的模式
    truck_nodes, centers = _cluster_centers_from_ind(base)
    if len(centers) >= 2:
        scores = []
        for idx, gene in enumerate(base):
            if gene[0] != 0:
                continue
            own_vid = gene[1]
            own_center = centers.get(own_vid, customer_positions[idx])
            own_d = calculate_distance(customer_positions[idx], own_center)
            other_vids = [vid for vid in centers.keys() if vid != own_vid]
            if not other_vids:
                continue
            best_other = min(other_vids, key=lambda vid: calculate_distance(customer_positions[idx], centers[vid]))
            other_d = calculate_distance(customer_positions[idx], centers[best_other])
            miscluster_score = own_d - other_d
            if miscluster_score > 0 and service[idx][0] in (1, 2):
                scores.append((miscluster_score, idx))
        for _, idx in sorted(scores, reverse=True)[:3]:
            base[idx] = service[idx]

    return repair_individual(base)


def structured_competitive_reselect(pop, objs, k):
    """
    保留：
    - 低成本层
    - 低罚分层
    - direct-rich 层
    - car-rich 层
    - 中协同层
    """
    all_idx = list(range(len(pop)))
    zero_idx = [i for i in all_idx if objs[i][2] <= 1e-6]
    low_pen_idx = sorted(all_idx, key=lambda i: (objs[i][2], objs[i][1], objs[i][0]))
    low_cost_idx = sorted(all_idx, key=lambda i: (objs[i][0], objs[i][2], objs[i][1]))

    direct_rich_idx, car_rich_idx, medium_air_idx = [], [], []
    for i, ind in enumerate(pop):
        d_cnt = sum(1 for g in ind if g[0] == 1)
        c_cnt = sum(1 for g in ind if g[0] == 2)
        air_cnt = d_cnt + c_cnt
        if d_cnt >= 5 or d_cnt > c_cnt:
            direct_rich_idx.append(i)
        if c_cnt >= 5 or c_cnt > d_cnt:
            car_rich_idx.append(i)
        if 4 <= air_cnt <= 14:
            medium_air_idx.append(i)

    selected = []
    selected += _select_from_indices_nsga(zero_idx, objs, min(max(4, k // 10), len(zero_idx)))
    selected += _select_from_indices_nsga(low_pen_idx, objs, max(8, k // 4))
    selected += _select_from_indices_nsga(low_cost_idx, objs, max(6, k // 6))
    selected += _select_from_indices_nsga(direct_rich_idx, objs, max(6, k // 8))
    selected += _select_from_indices_nsga(car_rich_idx, objs, max(6, k // 8))
    selected += _select_from_indices_nsga(medium_air_idx, objs, max(8, k // 4))

    seen, dedup = set(), []
    for i in selected:
        if i not in seen:
            dedup.append(i)
            seen.add(i)

    if len(dedup) < k:
        remaining = [i for i in all_idx if i not in seen]
        dedup += _select_from_indices_nsga(remaining, objs, k - len(dedup))

    dedup = dedup[:k]
    return [pop[i] for i in dedup], [objs[i] for i in dedup]

def last_mile_zero_penalty_repair(ind, pen_cap=100):
    """
    对接近可行的解做最后一公里清零：
    1) 优先复用已有 direct id 飞 tardy customer
    2) 若 tardy 自己不能/不适合飞，则给它前面的同线拖累点让路
    3) 再尝试 truck fallback / 邻车接手
    """
    base = list(ind)
    base_obj = evaluate_individual(base)
    if not (0 < base_obj[2] <= pen_cap):
        return base, base_obj

    tardy_nodes = TOP_TARDY_NODES_DICT.get(tuple(base), [])
    if not tardy_nodes:
        return base, base_obj

    best_ind, best_obj = base, base_obj

    for worst_idx in tardy_nodes[:2]:
        if worst_idx is None or worst_idx >= len(base):
            continue

        allow = customer_allowed[worst_idx]

        # A. 先复用已有 direct id，不够再试全部 direct
        if 1 in allow:
            used_direct = sorted({g[1] for g in base if g[0] == 1})
            direct_order = used_direct + [d for d in range(num_drones) if d not in used_direct]
            for did in direct_order:
                cand = list(base)
                cand[worst_idx] = (1, did)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                    best_ind, best_obj = cand, obj
                if obj[2] <= 1e-6:
                    return cand, obj

        # B. 如果 tardy 本身不能/不值得飞，就给同条线里一个“拖累点”让路
        if base[worst_idx][0] == 0:
            host_vid = base[worst_idx][1]
            same_truck_nodes = [i for i, g in enumerate(base) if g[0] == 0 and g[1] == host_vid and i != worst_idx]
            if same_truck_nodes:
                center = _cluster_centers_from_ind(base)[1].get(host_vid, customer_positions[worst_idx])
                relievers = sorted(
                    same_truck_nodes,
                    key=lambda i: calculate_distance(customer_positions[i], center),
                    reverse=True
                )[:3]

                for ridx in relievers:
                    # 先把拖累点改 direct
                    if 1 in customer_allowed[ridx]:
                        used_direct = sorted({g[1] for g in base if g[0] == 1})
                        direct_order = used_direct + [d for d in range(num_drones) if d not in used_direct]
                        for did in direct_order:
                            cand = list(base)
                            cand[ridx] = (1, did)
                            cand = repair_individual(cand)
                            obj = evaluate_individual(cand)
                            if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                                best_ind, best_obj = cand, obj
                            if obj[2] <= 1e-6:
                                return cand, obj

                    # 再试把拖累点改 car，减轻 truck 绕路
                    if 2 in customer_allowed[ridx]:
                        cand = list(base)
                        cand[ridx] = (2, host_vid, sample_car_id(cand, host_vid))
                        cand = repair_individual(cand)
                        obj = evaluate_individual(cand)
                        if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                            best_ind, best_obj = cand, obj
                        if obj[2] <= 1e-6:
                            return cand, obj

        # C. truck fallback：邻近 truck / 空闲 truck 接手 tardy
        truck_nodes, centers = _cluster_centers_from_ind(base)
        used_trucks = set(truck_nodes.keys())
        free_trucks = [v for v in range(num_vehicles) if v not in used_trucks]
        near_vids = sorted(centers.keys(), key=lambda vid: calculate_distance(customer_positions[worst_idx], centers[vid]))[:2] if centers else [0]
        truck_choices = list(dict.fromkeys(free_trucks[:2] + near_vids))

        if 0 in allow:
            for vid in truck_choices:
                cand = list(base)
                cand[worst_idx] = (0, vid)
                cand = repair_individual(cand)
                obj = evaluate_individual(cand)
                if (obj[2], obj[1], obj[0]) < (best_obj[2], best_obj[1], best_obj[0]):
                    best_ind, best_obj = cand, obj
                if obj[2] <= 1e-6:
                    return cand, obj

    return best_ind, best_obj


def update_high_penalty_streak(high_pen_streak, pop, objs, best_pen):
    threshold = max(200.0, 5.0 * max(best_pen, 1.0))
    present = set()

    for ind, obj in zip(pop, objs):
        key = tuple(ind)
        present.add(key)
        if obj[2] > threshold:
            high_pen_streak[key] = high_pen_streak.get(key, 0) + 1
        else:
            high_pen_streak[key] = 0

    for key in list(high_pen_streak.keys()):
        if key not in present:
            del high_pen_streak[key]

    return high_pen_streak


def soft_filter_persistent_high_penalty(pop, objs, high_pen_streak, best_pen, keep_quota=2):
    """
    高罚分解第一次出现可以保留；
    如果连续多代都还在，而且当前已经有较低罚分解存在，就开始软处理。
    """
    if best_pen > 200:
        return pop, objs

    threshold = max(200.0, 5.0 * max(best_pen, 1.0))
    persistent_idx = [
        i for i, (ind, obj) in enumerate(zip(pop, objs))
        if obj[2] > threshold and high_pen_streak.get(tuple(ind), 0) >= 2
    ]

    if not persistent_idx:
        return pop, objs

    keep_idx = set(sorted(persistent_idx, key=lambda i: (objs[i][0], objs[i][1], objs[i][2]))[:keep_quota])

    new_pop, new_objs = [], []
    for i, (ind, obj) in enumerate(zip(pop, objs)):
        if i in persistent_idx and i not in keep_idx:
            continue
        new_pop.append(ind)
        new_objs.append(obj)

    return new_pop, new_objs

def update_global_pareto_archive(archive_pop, archive_objs, pop, objs, cap=200):
    """累计全程非支配解，不只看最后一代。"""
    curr_front = fast_nondominated_sort(normalize_objs(objs))[0]
    merged_pop = list(archive_pop) + [list(pop[i]) for i in curr_front]
    merged_objs = list(archive_objs) + [objs[i] for i in curr_front]

    # 先去重：同一染色体只保留更优目标值
    uniq = {}
    for ind_i, obj_i in zip(merged_pop, merged_objs):
        key = tuple(ind_i)
        if key not in uniq or (obj_i[2], obj_i[1], obj_i[0]) < (uniq[key][1][2], uniq[key][1][1], uniq[key][1][0]):
            uniq[key] = (ind_i, obj_i)

    dedup_pop = [v[0] for v in uniq.values()]
    dedup_objs = [v[1] for v in uniq.values()]

    # 只保留累计集合中的第一前沿
    f0 = fast_nondominated_sort(normalize_objs(dedup_objs))[0]
    front_pop = [dedup_pop[i] for i in f0]
    front_objs = [dedup_objs[i] for i in f0]

    # 如果前沿太大，用 NSGA-II crowding 截断，但不低于 cap
    if len(front_pop) > cap:
        front_pop, front_objs = select_nsga2(front_pop, front_objs, cap)

    return front_pop, front_objs

def run_nsga2_pure(seed_val, n_customers, pop_init_func, use_elite=False, n_gen=300, pop_size=80):
    random.seed(seed_val)
    np.random.seed(seed_val)
    st = time.time()
    pop = pop_init_func(pop_size, n_customers)
    objs = rebuild_penalty_maps(pop)

    elite_memory = []
    service_archive = []
    cost_archive = []
    cost_feasible_archive = []
    high_pen_streak = {}

    global_archive = []
    global_archive_objs = []

    stag_cnt = 0
    best_pen_hist = float('inf')
    history_cost = [min(o[0] for o in objs)]
    convergence_gen = n_gen
    is_hpp = (pop_init_func.__name__ == 'init_population_hpp')

    global_archive, global_archive_objs = update_global_pareto_archive(global_archive, global_archive_objs, pop, objs, cap=120)

    for gen in range(1, n_gen + 1):
        curr_min_pen = min(o[2] for o in objs)
        curr_min_time = min(o[1] for o in objs)

        if curr_min_pen > 0 and abs(curr_min_pen - best_pen_hist) < 1e-5:
            stag_cnt += 1
        else:
            stag_cnt, best_pen_hist = 0, curr_min_pen

        stagnated = stag_cnt >= 10

        pop, objs, elite_memory = evolve_one_generation(
            pop, objs, DEFAULT_CX_PB, DEFAULT_BASE_MUT_PB, elite_memory,
            0.1 if use_elite else 0.0,
            0.2 if use_elite else 0.0,
            use_elite=use_elite,
            stagnated=stagnated
        )
        objs = rebuild_penalty_maps(pop)

        if is_hpp:
            has_zero_penalty = any(o[2] <= 1e-6 for o in objs)
            service_archive = update_service_archive(service_archive, pop, objs, cap=12)
            cost_archive = update_cost_archive(cost_archive, pop, objs, cap=12)
            cost_feasible_archive = update_cost_feasible_archive(cost_feasible_archive, pop, objs, cap=12, pen_cap=100.0)

            # A. dual archive bridge：降频、减半，保留效果同时降低额外评估成本
            if service_archive and (cost_archive or cost_feasible_archive) and ((gen % 8 == 0) or stagnated):
                bridge_children = []
                cost_parent_pool = cost_feasible_archive if cost_feasible_archive else cost_archive
                for _ in range(1):
                    cost_ind, _ = random.choice(cost_parent_pool[:min(6, len(cost_parent_pool))])
                    service_ind, _ = random.choice(service_archive[:min(6, len(service_archive))])
                    bridge_children.append(guided_bridge_recombine(cost_ind, service_ind))
                bridge_children = [repair_individual(ind) for ind in bridge_children]
                pop.extend(bridge_children)
                objs.extend([evaluate_individual(ind) for ind in bridge_children])

            # A2. 前半程跨簇/协同块探索：降频且每个个体只做一种重型变异
            if gen <= int(0.35 * n_gen) and ((gen % 8 == 0) or stagnated):
                exploratory_idx = sorted(range(len(objs)), key=lambda i: (objs[i][0], objs[i][2], objs[i][1]))[:max(3, pop_size // 20)]
                exploratory_children = []
                for wi in exploratory_idx[:3]:
                    try:
                        if random.random() < 0.5:
                            exploratory_children.append(inter_cluster_exchange_mutation(list(pop[wi]), top_m=3)[0])
                        else:
                            exploratory_children.append(cooperative_block_mutation(list(pop[wi]), block_size=3)[0])
                    except Exception:
                        pass
                if exploratory_children:
                    exploratory_children = [repair_individual(ind) for ind in exploratory_children]
                    pop.extend(exploratory_children)
                    objs.extend([evaluate_individual(ind) for ind in exploratory_children])

            # B. 无 0 罚分时：小批量定向修复 + 早接受
            if not has_zero_penalty:
                direct_target, car_target = adaptive_air_quota(curr_min_pen, curr_min_time)

                near_feasible = sorted(range(len(objs)), key=lambda i: (objs[i][2], objs[i][1], objs[i][0]))[:max(3, pop_size // 16)]
                low_cost_infeasible = [i for i in range(len(objs)) if objs[i][2] > 0]
                low_cost_infeasible = sorted(low_cost_infeasible, key=lambda i: (objs[i][0], objs[i][2], objs[i][1]))[:max(3, pop_size // 16)]
                target_idx = sorted(set(near_feasible + low_cost_infeasible))[:6]

                if (gen % 4 == 0) or stagnated:
                    for wi in target_idx:
                        old_ind = pop[wi]
                        old_obj = objs[wi]

                        # 先试直飞急救；若已清零则直接接受，不再做其余重型尝试
                        best_ind, best_obj = direct_rescue_lns(old_ind, top_m=2)
                        if best_obj[2] <= 1e-6 and (best_obj[1], best_obj[0]) <= (old_obj[1], old_obj[0]):
                            pop[wi], objs[wi] = best_ind, best_obj
                            continue

                        candidates = [(old_ind, old_obj), (best_ind, best_obj)]
                        candidates.append(service_first_multimode_lns(old_ind, top_m=2, sweeps=1))
                        if old_obj[2] > 50 or stagnated:
                            candidates.append(force_air_quota_repair(old_ind, direct_target, car_target))
                        if gen % 6 == 0:
                            c_ind = economic_structure_mutation(list(old_ind))[0]
                            c_ind = repair_individual(c_ind)
                            candidates.append((c_ind, evaluate_individual(c_ind)))

                        best_ind, best_obj = min(candidates, key=lambda x: (x[1][2], x[1][1], x[1][0]))
                        if (best_obj[2] < old_obj[2] - 1e-6) or                            (abs(best_obj[2] - old_obj[2]) < 1e-6 and best_obj[1] < old_obj[1] - 1e-6) or                            (abs(best_obj[2] - old_obj[2]) < 1e-6 and abs(best_obj[1] - old_obj[1]) < 1e-6 and best_obj[0] < old_obj[0] - 1e-6):
                            pop[wi], objs[wi] = best_ind, best_obj

                if curr_min_pen <= 100 and ((gen % 3 == 0) or stagnated):
                    near_zero_idx = sorted(
                        [i for i in range(len(objs)) if 0 < objs[i][2] <= 100],
                        key=lambda i: (objs[i][2], objs[i][1], objs[i][0])
                    )[:max(2, pop_size // 20)]

                    for wi in near_zero_idx:
                        old_ind = pop[wi]
                        old_obj = objs[wi]
                        new_ind, new_obj = last_mile_zero_penalty_repair(old_ind, pen_cap=100)
                        if (new_obj[2], new_obj[1], new_obj[0]) < (old_obj[2], old_obj[1], old_obj[0]):
                            pop[wi], objs[wi] = new_ind, new_obj

            else:
                # C. 已有 0 罚分时，分层做 cleanup：只打磨一小批 0 罚分强解
                zero_like = sorted([i for i in range(len(objs)) if objs[i][2] <= 1e-6], key=lambda i: (objs[i][0], objs[i][1]))[:max(3, pop_size // 18)]

                if (gen % 4 == 0) or stagnated:
                    for wi in zero_like:
                        old_ind = pop[wi]
                        old_obj = objs[wi]
                        candidates = [(old_ind, old_obj)]
                        candidates.append(time_squeeze_lns(old_ind, sample_n=3))
                        candidates.append(cost_cleanup_lns(old_ind, sample_n=3))
                        best_ind, best_obj = min(candidates, key=lambda x: (x[1][2], x[1][0], x[1][1]))
                        if ((best_obj[2] < old_obj[2] - 1e-6) or
                            (abs(best_obj[2] - old_obj[2]) < 1e-6 and best_obj[1] < old_obj[1] - 1e-6) or
                            (abs(best_obj[2] - old_obj[2]) < 1e-6 and abs(best_obj[1] - old_obj[1]) < 1e-6 and best_obj[0] < old_obj[0] - 1e-6)):
                            pop[wi], objs[wi] = best_ind, best_obj

                # 对非零罚分但不大的个体，保留一小条修复通道，避免“只要有一个 0 就全员停止修复”
                residual_idx = sorted(
                    [i for i in range(len(objs)) if 0 < objs[i][2] <= 100.0],
                    key=lambda i: (objs[i][2], objs[i][1], objs[i][0])
                )[:max(2, pop_size // 24)]
                if residual_idx and ((gen % 5 == 0) or stagnated):
                    for wi in residual_idx:
                        old_ind = pop[wi]
                        old_obj = objs[wi]
                        cand_ind, cand_obj = direct_rescue_lns(old_ind, top_m=2)
                        if (cand_obj[2], cand_obj[1], cand_obj[0]) < (old_obj[2], old_obj[1], old_obj[0]):
                            pop[wi], objs[wi] = cand_ind, cand_obj

                # C2. 专门压最低成本端：缩小频率和候选数
                if (gen % 3 == 0) or stagnated:
                    cost_focus_idx = sorted(
                        [i for i in range(len(objs)) if objs[i][2] <= 100.0],
                        key=lambda i: (objs[i][0], objs[i][2], objs[i][1])
                    )[:max(3, pop_size // 18)]

                    for wi in cost_focus_idx:
                        old_ind = pop[wi]
                        old_obj = objs[wi]
                        c1 = repair_individual(economic_structure_mutation(list(old_ind))[0])
                        c3, c3_obj = cost_cleanup_lns(old_ind, sample_n=4)
                        candidates = [
                            (old_ind, old_obj),
                            (c1, evaluate_individual(c1)),
                            (c3, c3_obj),
                        ]
                        if cost_feasible_archive and service_archive and gen % 6 == 0:
                            try:
                                base_ind, _ = random.choice(cost_feasible_archive[:min(4, len(cost_feasible_archive))])
                                srv_ind, _ = random.choice(service_archive[:min(4, len(service_archive))])
                                cb = repair_individual(guided_bridge_recombine(base_ind, srv_ind))
                                candidates.append((cb, evaluate_individual(cb)))
                            except Exception:
                                pass

                        def _cost_focus_rank(item):
                            obj = item[1]
                            return (0 if obj[2] <= 1e-6 else 1, min(obj[2], 100.0), obj[0], obj[1])

                        best_ind, best_obj = min(candidates, key=_cost_focus_rank)
                        if _cost_focus_rank((best_ind, best_obj)) < _cost_focus_rank((old_ind, old_obj)):
                            pop[wi], objs[wi] = best_ind, best_obj

            # 这里不立即 rebuild，全都做完后再统一更新一次
            has_zero_penalty = any(o[2] <= 1e-6 for o in objs)
            service_archive = update_service_archive(service_archive, pop, objs, cap=12)
            cost_archive = update_cost_archive(cost_archive, pop, objs, cap=12)
            cost_feasible_archive = update_cost_feasible_archive(
                cost_feasible_archive, pop, objs, cap=12,
                pen_cap=(0.0 if has_zero_penalty else 100.0)
            )

            # D. 后 30% 代才启用高罚分软过滤
            if gen >= int(0.70 * n_gen):
                best_pen_now = min(o[2] for o in objs)
                high_pen_streak = update_high_penalty_streak(high_pen_streak, pop, objs, best_pen_now)
                pop, objs = soft_filter_persistent_high_penalty(pop, objs, high_pen_streak, best_pen_now, keep_quota=2)

            uniq = {}
            for ind_i, obj_i in zip(pop, objs):
                key = tuple(ind_i)
                if key not in uniq or (obj_i[2], obj_i[1], obj_i[0]) < (uniq[key][1][2], uniq[key][1][1], uniq[key][1][0]):
                    uniq[key] = (ind_i, obj_i)
            pop = [v[0] for v in uniq.values()]
            objs = [v[1] for v in uniq.values()]

            # HPP 专属分层竞争重选不再每代执行：每 3 代或停滞时执行一次；
            # 其他代使用标准 NSGA-II 截断，减少额外分层排序开销。
            if (gen % 3 == 0) or stagnated:
                pop, objs = structured_competitive_reselect(pop, objs, pop_size)
            elif len(pop) > pop_size:
                pop, objs = select_nsga2(pop, objs, pop_size)

            # 兜底：防止 HPP 过滤/去重/重选后种群过小，保证下一代至少可抽 2 个父代
            if len(pop) < 2:
                refill = init_population_random(max(2, pop_size), n_customers)
                pop = [repair_individual(list(ind)) for ind in refill]
                objs = [evaluate_individual(ind) for ind in pop]
            elif len(pop) < pop_size:
                refill = init_population_random(pop_size - len(pop), n_customers)
                pop.extend([repair_individual(list(ind)) for ind in refill])
                objs = [evaluate_individual(ind) for ind in pop]

        # 历史 archive 降频维护：每 5 代或最后一代更新一次，容量从 180 降至 120。
        if (gen % 5 == 0) or (gen == n_gen):
            global_archive, global_archive_objs = update_global_pareto_archive(
                global_archive, global_archive_objs, pop, objs, cap=120
            )
        history_cost.append(min(o[0] for o in objs))
        convergence_gen = n_gen

    if global_archive:
        return global_archive, global_archive_objs, time.time() - st, history_cost, convergence_gen

    front = fast_nondominated_sort(normalize_objs(objs))[0]
    return [pop[i] for i in front], [objs[i] for i in front], time.time() - st, history_cost, convergence_gen

def run_kmeans_init_nsga2(s, N): return run_nsga2_pure(s, N, init_population_kmeans_std, True, n_gen=100, pop_size=100)


def run_hpp_init_nsga2(s, N): return run_nsga2_pure(s, N, init_population_hpp, True, n_gen=100, pop_size=100)

def fleet_caps(N):
    num_tr = min(15, max(1, math.ceil(N / 10)))   # 20客户->2车，40客户->4车
    num_dr = 5                                    # 先保持与你当前启发式一致
    return num_tr, num_dr
def set_environment_from_precomputed(pre):
    """Set the heuristic environment from a static precomputed input dictionary.

    Use this in batch scripts after calling precompute_inputs.ensure_precomputed().
    It avoids recalculating distance matrices, noise feasibility, customer_allowed,
    recovery candidates, and r_car(i,j,p) in every seed.
    """
    global customer_positions, weights, time_windows, num_customers
    global num_vehicles, num_drones, num_car_drones, customer_allowed
    global WORST_NODE_DICT, TOP_TARDY_NODES_DICT, facility_positions
    global ROUTE_EVAL_CACHE, DRONE_SET_CACHE
    global precomputed_manhattan, PRECOMPUTED_EUCLIDEAN
    global CAR_RANGE_OK_MATRIX, RECOVERY_CANDIDATES_MAP, warehouse_position

    warehouse_position = tuple(pre["warehouse_position"])
    customer_positions = [tuple(p) for p in pre["customer_positions"]]
    weights = list(pre["weights"])
    time_windows = [tuple(tw) for tw in pre["time_windows"]]
    facility_positions = [tuple(p) for p in pre.get("facility_positions", [])]

    num_customers = int(pre["N"])
    # Allow external scripts to override fleet_caps before calling this function.
    num_vehicles, num_drones = fleet_caps(num_customers)
    num_car_drones = int(pre.get("num_car_drones", 1))

    precomputed_manhattan = np.asarray(pre["manhattan_matrix"], dtype=float)
    PRECOMPUTED_EUCLIDEAN = np.asarray(pre["euclidean_matrix"], dtype=float)
    CAR_RANGE_OK_MATRIX = np.asarray(pre["car_range_ok_matrix"], dtype=bool)
    RECOVERY_CANDIDATES_MAP = pre.get("recovery_candidates", None)
    customer_allowed = [list(x) for x in pre["customer_allowed"]]

    WORST_NODE_DICT = {}
    TOP_TARDY_NODES_DICT = {}
    ROUTE_EVAL_CACHE = {}
    DRONE_SET_CACHE = {}


def set_environment_for_N(N):
    global customer_positions, weights, time_windows, num_customers, num_vehicles, num_drones, num_car_drones, customer_allowed, WORST_NODE_DICT, TOP_TARDY_NODES_DICT, facility_positions, ROUTE_EVAL_CACHE, DRONE_SET_CACHE, CAR_RANGE_OK_MATRIX, RECOVERY_CANDIDATES_MAP

    customer_positions = ORIGINAL_POSITIONS[:N]
    weights = ORIGINAL_WEIGHTS[:N + 1]
    time_windows = ORIGINAL_TW[:N + 1]
    num_customers = N
    num_vehicles, num_drones = fleet_caps(N)
    num_car_drones = 1

    random.seed(SEED)
    facility_positions = [
        (random.uniform(0, 100 * scale), random.uniform(0, 100 * scale))
        for _ in range(100)
    ]

    precompute_data(customer_positions)
    RECOVERY_CANDIDATES_MAP = None
    CAR_RANGE_OK_MATRIX = _build_car_range_ok_matrix(N)
    WORST_NODE_DICT = {}
    TOP_TARDY_NODES_DICT = {}
    ROUTE_EVAL_CACHE = {}
    DRONE_SET_CACHE = {}

    customer_allowed = []
    for idx in range(1, N + 1):
        pos = customer_positions[idx - 1]
        w = weights[idx]
        allow = [0]
        noise_ok = all(attenuated_LA_at_point(pos, fpos) <= FACILITY_NOISE_THRESHOLD_DB
                       for fpos in facility_positions)
        if w <= car_drone_payload and noise_ok:
            if has_any_car_range_feasible(idx):
                allow.append(2)
            if calculate_distance_from_warehouse(pos) * 2 <= DRONE_MAX_RANGE:
                allow.append(1)
        customer_allowed.append(allow)

def visualize_solution(individual, customer_positions, warehouse_position, time_windows, filename="VRP_Solution.png"):
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    from collections import defaultdict

    veh_c, car_c, drn_assign = [], [], []
    for i, gene in enumerate(individual, start=1):
        if gene[0] == 0:
            veh_c.append((gene[1], i))
        elif gene[0] == 1:
            drn_assign.append((gene[1], i))
        else:
            car_c.append((gene[1], gene[2], i))

    vehicle_routes = {}
    veh_arrivals = {}
    cust_by_vehicle = defaultdict(list)
    for vid, cust in veh_c: cust_by_vehicle[vid].append(cust)

    for vid, cl in cust_by_vehicle.items():
        rt, mat = solve_vrptw_alns(cl, customer_positions, time_windows)
        c, t, arr = evaluate_vehicle(rt, mat, cl, wait_time)
        vehicle_routes[vid] = rt
        veh_arrivals.update(arr)

    _, _, _, drone_log = evaluate_car_drone(car_c, customer_positions, vehicle_routes, veh_arrivals, time_windows,
                                            wait_time=wait_time)
    drn_c = [cust for _, cust in drn_assign]

    plt.figure(figsize=(14, 14))
    colors = list(mcolors.TABLEAU_COLORS.values()) * 3

    plt.scatter(warehouse_position[0], warehouse_position[1], c='red', marker='*', s=600, zorder=10, edgecolors='black',
                label='Depot')

    for cid in drn_c:
        pos = customer_positions[cid - 1]
        plt.plot([warehouse_position[0], pos[0]], [warehouse_position[1], pos[1]], color='#2ca02c', linestyle='--',
                 alpha=0.3, linewidth=1.5)
        plt.scatter(pos[0], pos[1], c='#2ca02c', marker='^', s=120, edgecolors='black', zorder=5)
    if drn_c: plt.scatter([], [], c='#2ca02c', marker='^', s=120, edgecolors='black', label='Direct Drone')

    truck_legend, car_drone_legend = False, False

    for vid, route in vehicle_routes.items():
        if len(route) <= 2 and not drone_log.get((vid, 0)): continue
        color = colors[vid % len(colors)]

        rx = [warehouse_position[0] if n == 0 else customer_positions[n - 1][0] for n in route]
        ry = [warehouse_position[1] if n == 0 else customer_positions[n - 1][1] for n in route]
        plt.plot(rx, ry, color=color, linewidth=2.5, linestyle='-', alpha=0.8)

        tx = [customer_positions[n - 1][0] for n in route if n != 0]
        ty = [customer_positions[n - 1][1] for n in route if n != 0]
        plt.scatter(tx, ty, c=color, marker='o', s=100, edgecolors='black', zorder=6)
        if not truck_legend:
            plt.scatter([], [], c='gray', marker='o', edgecolors='black', s=100, label='Truck')
            truck_legend = True

    for key, logs in drone_log.items():
        vid, cdid = key
        color = colors[vid % len(colors)]
        for log in logs:
            rel, ret, cust_idx, _, _, _, _ = log
            rel_pos = warehouse_position if rel == 0 else customer_positions[rel - 1]
            ret_pos = warehouse_position if ret == 0 else customer_positions[ret - 1]
            cust_pos = customer_positions[cust_idx - 1]

            plt.annotate('', xy=cust_pos, xytext=rel_pos,
                         arrowprops=dict(arrowstyle='->', color=color, linestyle=':', lw=2.5, alpha=0.9))
            plt.annotate('', xy=ret_pos, xytext=cust_pos,
                         arrowprops=dict(arrowstyle='->', color=color, linestyle=':', lw=2.5, alpha=0.9))

            plt.scatter(cust_pos[0], cust_pos[1], c=color, marker='s', s=120, edgecolors='black', zorder=7)
            if not car_drone_legend:
                plt.scatter([], [], c='gray', marker='s', edgecolors='black', s=120, label='Car-mounted Drone')
                car_drone_legend = True

    plt.title('Optimal Multi-Modal Routing Topology (HPP Algorithm)', fontsize=18, fontweight='bold', pad=15)
    plt.xlabel('X Coordinate (m)', fontsize=14)
    plt.ylabel('Y Coordinate (m)', fontsize=14)
    plt.grid(True, linestyle='--', alpha=0.4)
    plt.legend(loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0., fontsize=12, frameon=True, shadow=True)
    plt.tight_layout()
    plt.savefig(filename, dpi=400, bbox_inches='tight')
    plt.close()


def generate_holographic_report(best_f_ind, filename):
    from collections import defaultdict
    veh_c, car_c, drn_assign = [], [], []
    for i, gene in enumerate(best_f_ind, start=1):
        if gene[0] == 0:
            veh_c.append((gene[1], i))
        elif gene[0] == 1:
            drn_assign.append((gene[1], i))
        else:
            car_c.append((gene[1], gene[2], i))

    vehicle_routes = {}
    veh_arrivals = {}
    cust_by_vehicle = defaultdict(list)
    for vid, cust in veh_c: cust_by_vehicle[vid].append(cust)

    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"\n{'=' * 60}\n🌟 全息时间轴与拓扑路线报告 (供手动 Debug) 🌟\n{'=' * 60}\n")
        f.write(f"【原始染色体数组】:\nRAW_CHROMOSOME = {best_f_ind}\n\n")

        drn_assign = [(gene[1], i) for i, gene in enumerate(best_f_ind, start=1) if gene[0] == 1]
        drn_c = [cust for _, cust in drn_assign]
        _, _, drn_arrivals = evaluate_drone(drn_assign, customer_positions, time_windows)
        f.write(f"✈️ [直飞无人机群] (共 {len(drn_c)} 架次)\n")
        for cid in drn_c:
            pos = customer_positions[cid - 1]
            euc_dist = calculate_distance(warehouse_position, pos)
            tw = time_windows[cid]
            arr_t = drn_arrivals.get(cid, 0)
            status = "✅准时" if arr_t <= tw[1] else f"⚠️微小延误 (超 {arr_t - tw[1]:.1f}s)"
            f.write(
                f"   └─ 送达客户 {cid:02d} | 欧式距离: {euc_dist:.1f}m | 抵达时间: {arr_t:.1f}s | 时间窗: [{tw[0]}, {tw[1]}] | {status}\n")

        f.write(f"\n🚛 [卡车与车载无人机 联合编队]\n")
        for vid, cl in cust_by_vehicle.items():
            rt, mat = solve_vrptw_alns(cl, customer_positions, time_windows)
            c, t, arr = evaluate_vehicle(rt, mat, cl, wait_time)
            vehicle_routes[vid] = rt
            veh_arrivals.update(arr)

            _, _, car_arr, drone_log = evaluate_car_drone([x for x in car_c if x[0] == vid], customer_positions,
                                                          {vid: rt}, veh_arrivals, time_windows, wait_time)

            c_logs = drone_log.get((vid, 0), [])
            if len(rt) <= 2 and not c_logs: continue

            f.write(f"\n   [编队 {vid:02d}] 路线序列 (0为仓库): {rt}\n")
            for node in rt:
                if node == 0: continue
                cid = node
                tw = time_windows[cid]
                arr_t = veh_arrivals.get(cid, 0)
                status = "✅准时" if arr_t <= tw[1] else f"⚠️微小延误 (超 {arr_t - tw[1]:.1f}s)"
                f.write(
                    f"      ├─ 🚛 卡车到达客户 {cid:02d} | 抵达时间: {arr_t:.1f}s | 时间窗: [{tw[0]}, {tw[1]}] | {status}\n")

            for log in c_logs:
                rel, ret, cid, rtime, atime, rctime, _ = log
                tw = time_windows[cid]
                status = "✅准时" if atime <= tw[1] else f"⚠️微小延误 (超 {atime - tw[1]:.1f}s)"
                f.write(
                    f"      └─ 🛸 车载送达客户 {cid:02d} | 从节点 {rel} 起飞 -> 节点 {ret} 回收 | 送达时间: {atime:.1f}s | 时间窗: [{tw[0]}, {tw[1]}] | {status}\n")
        f.write(f"\n{'=' * 60}\n\n")


import os



def summarize_front_modes(pareto_front, pareto_objs=None):
    truck_services, direct_services, car_services = [], [], []
    active_trucks, active_directs, active_cars = [], [], []
    pure_truck_count = 0

    zero_penalty_count = 0
    zero_penalty_time_best = None
    zero_penalty_cost_best = None

    for idx, ind in enumerate(pareto_front):
        truck_services.append(sum(1 for g in ind if g[0] == 0))
        direct_services.append(sum(1 for g in ind if g[0] == 1))
        car_services.append(sum(1 for g in ind if g[0] == 2))

        tset = {g[1] for g in ind if g[0] == 0} | {g[1] for g in ind if g[0] == 2}
        dset = {g[1] for g in ind if g[0] == 1}
        cset = {(g[1], g[2]) for g in ind if g[0] == 2}
        active_trucks.append(len(tset))
        active_directs.append(len(dset))
        active_cars.append(len(cset))

        if sum(1 for g in ind if g[0] in (1, 2)) == 0:
            pure_truck_count += 1

        if pareto_objs is not None:
            pen = pareto_objs[idx][2]
            if pen <= 1e-6:
                zero_penalty_count += 1
                if zero_penalty_time_best is None or pareto_objs[idx][1] < zero_penalty_time_best:
                    zero_penalty_time_best = pareto_objs[idx][1]
                if zero_penalty_cost_best is None or pareto_objs[idx][0] < zero_penalty_cost_best:
                    zero_penalty_cost_best = pareto_objs[idx][0]

    n = len(pareto_front) if pareto_front else 1
    return {
        'TruckService_Avg': round(float(np.mean(truck_services)), 6) if truck_services else 0.0,
        'DirectService_Avg': round(float(np.mean(direct_services)), 6) if direct_services else 0.0,
        'CarService_Avg': round(float(np.mean(car_services)), 6) if car_services else 0.0,
        'AirService_Avg': round(float(np.mean(np.array(direct_services) + np.array(car_services))), 6) if truck_services else 0.0,
        'ActiveTruck_Avg': round(float(np.mean(active_trucks)), 6) if active_trucks else 0.0,
        'ActiveDirect_Avg': round(float(np.mean(active_directs)), 6) if active_directs else 0.0,
        'ActiveCar_Avg': round(float(np.mean(active_cars)), 6) if active_cars else 0.0,
        'PureTruck_Ratio': round(pure_truck_count / n, 6),
        'ZeroPenalty_Count': zero_penalty_count,
        'ZeroPenalty_Ratio': round(zero_penalty_count / n, 6),
        'ZeroPenaltyTime_Best': round(float(zero_penalty_time_best), 6) if zero_penalty_time_best is not None else None,
        'ZeroPenaltyCost_Best': round(float(zero_penalty_cost_best), 6) if zero_penalty_cost_best is not None else None,
    }

def summarize_individual_modes(ind):
    truck_service = sum(1 for g in ind if g[0] == 0)
    direct_service = sum(1 for g in ind if g[0] == 1)
    car_service = sum(1 for g in ind if g[0] == 2)
    active_trucks = len({g[1] for g in ind if g[0] == 0} | {g[1] for g in ind if g[0] == 2})
    active_direct = len({g[1] for g in ind if g[0] == 1})
    active_car = len({(g[1], g[2]) for g in ind if g[0] == 2})
    return {
        'TruckService_Count': truck_service,
        'DirectService_Count': direct_service,
        'CarService_Count': car_service,
        'AirService_Count': direct_service + car_service,
        'ActiveTruck_Count': active_trucks,
        'ActiveDirect_Count': active_direct,
        'ActiveCar_Count': active_car,
    }

def collect_key_chromosomes(pareto_front, pareto_objs, algo_name, N, run_id):
    rows = []
    if not pareto_front:
        return rows

    best_cost_idx = min(range(len(pareto_objs)), key=lambda i: pareto_objs[i][0])
    best_time_idx = min(range(len(pareto_objs)), key=lambda i: pareto_objs[i][1])
    best_pen_idx = min(range(len(pareto_objs)), key=lambda i: pareto_objs[i][2])

    key_cases = [
        ('MinCost', best_cost_idx),
        ('MinTime', best_time_idx),
        ('MinPenalty', best_pen_idx),
    ]

    for tag, idx in key_cases:
        ind = pareto_front[idx]
        obj = pareto_objs[idx]
        mode_info = summarize_individual_modes(ind)
        rows.append({
            'N': N,
            'Run': run_id,
            'Algorithm': algo_name,
                'Version': ALGO_VERSION,
            'KeyType': tag,
            'Cost': round(obj[0], 6),
            'Time': round(obj[1], 6),
            'Penalty': round(obj[2], 6),
            'TruckService_Count': mode_info['TruckService_Count'],
            'DirectService_Count': mode_info['DirectService_Count'],
            'CarService_Count': mode_info['CarService_Count'],
            'Chromosome': str(ind),
        })
    return rows


def _decode_chromosome(chromosome):
    veh_c, car_c, drn_assign = [], [], []
    for i, gene in enumerate(chromosome, start=1):
        if gene[0] == 0:
            veh_c.append((gene[1], i))
        elif gene[0] == 1:
            drn_assign.append((gene[1], i))
        else:
            car_c.append((gene[1], gene[2], i))
    return veh_c, car_c, drn_assign


def _rebuild_solution_for_plot(chromosome):
    chromosome = _repair_orphan_car_assignments(chromosome)
    veh_c, car_c, drn_assign = _decode_chromosome(chromosome)

    veh_arrivals, vehicle_routes = {}, {}
    cust_by_vehicle = defaultdict(list)
    for vid, cust in veh_c:
        cust_by_vehicle[vid].append(cust)

    for vid, cl in cust_by_vehicle.items():
        rt, mat = solve_vrptw_alns(cl, customer_positions, time_windows, alpha=0.5, max_iter=10)
        _, _, arr = evaluate_vehicle(rt, mat, cl, wait_time)
        vehicle_routes[vid] = rt
        veh_arrivals.update(arr)

    _, _, _, drone_log = evaluate_car_drone(
        car_c, customer_positions, vehicle_routes, veh_arrivals, time_windows, wait_time=wait_time
    )
    return vehicle_routes, drone_log, drn_assign


def plot_chromosome_solution(chromosome, title, save_path):
    vehicle_routes, drone_log, drn_assign = _rebuild_solution_for_plot(chromosome)

    plt.figure(figsize=(11, 11))
    wx, wy = warehouse_position
    plt.scatter([wx], [wy], marker='*', s=260, label='Warehouse')

    cmap = plt.cm.get_cmap('tab10', max(10, num_vehicles + 1))
    truck_color = {vid: cmap(vid % 10) for vid in range(max(10, num_vehicles + 1))}

    # 1) truck 路线：每个 truck 固定一个颜色
    first_truck_label = True
    for vid, route in vehicle_routes.items():
        xs, ys = [], []
        for node in route:
            if node == 0:
                x, y = warehouse_position
            else:
                x, y = customer_positions[node - 1]
            xs.append(x)
            ys.append(y)
        plt.plot(xs, ys, linewidth=2.0, color=truck_color[vid],
                 label='Truck Route' if first_truck_label else None)
        first_truck_label = False
        for node in route:
            if node != 0:
                x, y = customer_positions[node - 1]
                plt.text(x, y, f'T{vid}', fontsize=6, color=truck_color[vid])

    # 2) direct：统一黑色虚线，突出“独立于 truck”
    first_direct_label = True
    for did, cust in drn_assign:
        cx, cy = customer_positions[cust - 1]
        plt.plot([wx, cx], [wy, cy], linestyle='--', linewidth=1.4, color='black',
                 label='Direct Arc' if first_direct_label else None)
        plt.plot([cx, wx], [cy, wy], linestyle='--', linewidth=1.4, color='black')
        plt.scatter([cx], [cy], marker='^', s=60, color='black',
                    label='Direct Customer' if first_direct_label else None)
        plt.text(cx, cy, f'D{did}', fontsize=6, color='black')
        first_direct_label = False

    # 3) car-drone：和所属 truck 同色，这样一眼看清谁是谁的车载无人机
    first_car_label = True
    for (vid, cdid), logs in drone_log.items():
        color = truck_color[vid]
        for rel, ret, cust_idx, rtime, atime, rctime, wait_duration in logs:
            if rel == 0:
                rx, ry = warehouse_position
            else:
                rx, ry = customer_positions[rel - 1]
            if ret == 0:
                tx, ty = warehouse_position
            else:
                tx, ty = customer_positions[ret - 1]
            cx, cy = customer_positions[cust_idx - 1]

            plt.plot([rx, cx], [ry, cy], linestyle='-.', linewidth=1.5, color=color,
                     label='Car-Drone Arc' if first_car_label else None)
            plt.plot([cx, tx], [cy, ty], linestyle='-.', linewidth=1.5, color=color)
            plt.scatter([cx], [cy], marker='s', s=60, color=color,
                        label='Car-Drone Customer' if first_car_label else None)
            plt.text(cx, cy, f'C{vid}', fontsize=6, color=color)
            first_car_label = False

    plt.title(title)
    plt.legend(loc='best', fontsize=8)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=220)
    plt.close()

def export_key_chromosome_plots(key_df, folder_name):
    import ast
    hpp_df = key_df[key_df['Algorithm'] == 'HPP-init-NSGA2']
    for _, row in hpp_df.iterrows():
        set_environment_for_N(int(row['N']))
        chrom = ast.literal_eval(row['Chromosome'])
        name = f"{row['Algorithm']}_Run{row['Run']}_{row['KeyType']}.png".replace(" ", "_")
        save_path = os.path.join(folder_name, name)
        title = f"{row['Algorithm']} | Run {row['Run']} | {row['KeyType']} | C={row['Cost']:.2f}, T={row['Time']:.1f}, P={row['Penalty']:.1f}"
        plot_chromosome_solution(chrom, title, save_path)

def filter_report_front(pareto_front, pareto_objs):
    """
    报告前沿：
    - 内部完整前沿保留不动
    - 论文/图表展示时过滤极端高罚分点
    """
    if not pareto_front:
        return [], [], None

    best_pen = min(o[2] for o in pareto_objs)
    pen_cap = max(100.0, 5.0 * max(best_pen, 1.0))

    idx = [i for i, o in enumerate(pareto_objs) if o[2] <= pen_cap]
    if not idx:
        idx = sorted(range(len(pareto_objs)), key=lambda i: (pareto_objs[i][2], pareto_objs[i][1], pareto_objs[i][0]))[:max(3, min(10, len(pareto_objs)))]

    front = [pareto_front[i] for i in idx]
    objs = [pareto_objs[i] for i in idx]
    return front, objs, pen_cap


def build_frontier_dataframe(pareto_front, pareto_objs, algo_name, N, run_id, front_tag, pen_cap=None):
    rows = []
    for idx, (ind, obj) in enumerate(zip(pareto_front, pareto_objs), start=1):
        mode_info = summarize_individual_modes(ind)
        rows.append({
            'N': N,
            'Run': run_id,
            'Algorithm': algo_name,
            'Version': ALGO_VERSION,
            'FrontType': front_tag,
            'PenaltyCap': pen_cap,
            'PointID': idx,
            'Cost': round(obj[0], 6),
            'Time': round(obj[1], 6),
            'Penalty': round(obj[2], 6),
            'TruckService_Count': mode_info['TruckService_Count'],
            'DirectService_Count': mode_info['DirectService_Count'],
            'CarService_Count': mode_info['CarService_Count'],
            'AirService_Count': mode_info['AirService_Count'],
            'ActiveTruck_Count': mode_info['ActiveTruck_Count'],
            'ActiveDirect_Count': mode_info['ActiveDirect_Count'],
            'ActiveCar_Count': mode_info['ActiveCar_Count'],
            'Chromosome': str(ind),
        })
    return pd.DataFrame(rows)


def plot_frontier_3d(pareto_objs, title, save_path):
    if not pareto_objs:
        return
    from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    xs = [o[0] for o in pareto_objs]
    ys = [o[1] for o in pareto_objs]
    zs = [o[2] for o in pareto_objs]
    ax.scatter(xs, ys, zs, s=28, depthshade=True)
    ax.set_xlabel('Cost')
    ax.set_ylabel('Time')
    ax.set_zlabel('Penalty')
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(save_path, dpi=220)
    plt.close()


def plot_frontier_2d(pareto_objs, title, save_path):
    if not pareto_objs:
        return
    costs = [o[0] for o in pareto_objs]
    times = [o[1] for o in pareto_objs]
    pens = [o[2] for o in pareto_objs]
    plt.figure(figsize=(7.5, 6))
    sc = plt.scatter(costs, times, c=pens, s=34)
    plt.xlabel('Cost')
    plt.ylabel('Time')
    plt.title(title)
    cbar = plt.colorbar(sc)
    cbar.set_label('Penalty')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=220)
    plt.close()


def export_frontier_bundle(pareto_front, pareto_objs, algo_name, N, run_id, front_tag, folder_name, pen_cap=None):
    df = build_frontier_dataframe(pareto_front, pareto_objs, algo_name, N, run_id, front_tag, pen_cap)
    csv_name = f"Frontier_{front_tag}_N{N}_Run{run_id}_{algo_name}.csv".replace(' ', '_')
    df.to_csv(os.path.join(folder_name, csv_name), index=False)

    plot_frontier_3d(
        pareto_objs,
        f"{algo_name} | Run {run_id} | {front_tag} Frontier (3D)",
        os.path.join(folder_name, f"Frontier_{front_tag}_3D_N{N}_Run{run_id}_{algo_name}.png".replace(' ', '_'))
    )
    plot_frontier_2d(
        pareto_objs,
        f"{algo_name} | Run {run_id} | {front_tag} Frontier (Cost-Time, color=Penalty)",
        os.path.join(folder_name, f"Frontier_{front_tag}_2D_N{N}_Run{run_id}_{algo_name}.png".replace(' ', '_'))
    )
    return df


def build_run_row(N, run_id, algo_name, pareto_front, pareto_objs, rt, conv_gen, hv_ref, front_tag, pen_cap=None):
    if not pareto_objs:
        return {
            'N': N, 'Run': run_id, 'Algorithm': algo_name, 'Version': ALGO_VERSION,
            'FrontType': front_tag, 'PenaltyCap': pen_cap,
            'Pareto_Count': 0, 'HV': None, 'LocalMetric': round(rt, 6), 'Conv_Gen': conv_gen
        }

    mode_stats = summarize_front_modes(pareto_front, pareto_objs)
    curr_hv = hv.hypervolume(pareto_objs, hv_ref)
    return {
        'N': N,
        'Run': run_id,
        'Algorithm': algo_name,
        'Version': ALGO_VERSION,
        'FrontType': front_tag,
        'PenaltyCap': pen_cap,
        'Pareto_Count': len(pareto_objs),
        'HV': round(curr_hv, 6),
        'LocalMetric': round(rt, 6),
        'Conv_Gen': conv_gen,
        'Cost_Min': round(min(o[0] for o in pareto_objs), 6),
        'Cost_Mean': round(float(np.mean([o[0] for o in pareto_objs])), 6),
        'Cost_Max': round(max(o[0] for o in pareto_objs), 6),
        'Time_Min': round(min(o[1] for o in pareto_objs), 6),
        'Time_Mean': round(float(np.mean([o[1] for o in pareto_objs])), 6),
        'Time_Max': round(max(o[1] for o in pareto_objs), 6),
        'Pen_Min': round(min(o[2] for o in pareto_objs), 6),
        'Pen_Mean': round(float(np.mean([o[2] for o in pareto_objs])), 6),
        'Pen_Max': round(max(o[2] for o in pareto_objs), 6),
        'TruckService_Avg': mode_stats['TruckService_Avg'],
        'DirectService_Avg': mode_stats['DirectService_Avg'],
        'CarService_Avg': mode_stats['CarService_Avg'],
        'AirService_Avg': mode_stats['AirService_Avg'],
        'ActiveTruck_Avg': mode_stats['ActiveTruck_Avg'],
        'ActiveDirect_Avg': mode_stats['ActiveDirect_Avg'],
        'ActiveCar_Avg': mode_stats['ActiveCar_Avg'],
        'PureTruck_Ratio': mode_stats['PureTruck_Ratio'],
        'ZeroPenalty_Count': mode_stats['ZeroPenalty_Count'],
        'ZeroPenalty_Ratio': mode_stats['ZeroPenalty_Ratio'],
        'ZeroPenaltyTime_Best': mode_stats['ZeroPenaltyTime_Best'],
        'ZeroPenaltyCost_Best': mode_stats['ZeroPenaltyCost_Best']
    }


def build_scale_summary(run_df, front_tag):
    rows = []
    if run_df.empty:
        return pd.DataFrame(rows)

    for algo_name in sorted(run_df['Algorithm'].unique()):
        sub = run_df[run_df['Algorithm'] == algo_name]
        rows.append({
            'N': int(sub['N'].iloc[0]),
            'Algorithm': algo_name,
            'Version': ALGO_VERSION,
            'FrontType': front_tag,
            'Cost_Min_Best': round(sub['Cost_Min'].min(), 6),
            'Cost_Min_Mean': round(sub['Cost_Min'].mean(), 6),
            'Cost_Min_Std': round(sub['Cost_Min'].std(ddof=0), 6),
            'Cost_Min_Worst': round(sub['Cost_Min'].max(), 6),
            'Time_Min_Best': round(sub['Time_Min'].min(), 6),
            'Time_Min_Mean': round(sub['Time_Min'].mean(), 6),
            'Time_Min_Std': round(sub['Time_Min'].std(ddof=0), 6),
            'Time_Min_Worst': round(sub['Time_Min'].max(), 6),
            'Pen_Min_Best': round(sub['Pen_Min'].min(), 6),
            'Pen_Min_Mean': round(sub['Pen_Min'].mean(), 6),
            'Pen_Min_Std': round(sub['Pen_Min'].std(ddof=0), 6),
            'Pen_Min_Worst': round(sub['Pen_Min'].max(), 6),
            'HV_Best': round(sub['HV'].max(), 6),
            'HV_Mean': round(sub['HV'].mean(), 6),
            'HV_Std': round(sub['HV'].std(ddof=0), 6),
            'LocalMetric_Mean': round(sub['LocalMetric'].mean(), 6),
            'LocalMetric_Std': round(sub['LocalMetric'].std(ddof=0), 6),
            'ParetoCount_Mean': round(sub['Pareto_Count'].mean(), 6),
            'ParetoCount_Std': round(sub['Pareto_Count'].std(ddof=0), 6),
            'TruckService_Avg': round(sub['TruckService_Avg'].mean(), 6),
            'DirectService_Avg': round(sub['DirectService_Avg'].mean(), 6),
            'CarService_Avg': round(sub['CarService_Avg'].mean(), 6),
            'AirService_Avg': round(sub['AirService_Avg'].mean(), 6),
            'ActiveTruck_Avg': round(sub['ActiveTruck_Avg'].mean(), 6),
            'ActiveDirect_Avg': round(sub['ActiveDirect_Avg'].mean(), 6),
            'ActiveCar_Avg': round(sub['ActiveCar_Avg'].mean(), 6),
            'PureTruck_Ratio': round(sub['PureTruck_Ratio'].mean(), 6),
            'ZeroPenalty_Count_Mean': round(sub['ZeroPenalty_Count'].mean(), 6),
            'ZeroPenalty_Ratio_Mean': round(sub['ZeroPenalty_Ratio'].mean(), 6),
        })
    return pd.DataFrame(rows)

def main():
    import pandas as pd
    import numpy as np
    from deap.tools._hypervolume import hv

    test_scales = [100]
    num_runs = 2
    hv_ref = (1000.0, 50000.0, 100000.0)

    algorithms = {
        "KMeans-init-NSGA2": run_kmeans_init_nsga2,
        "HPP-init-NSGA2": run_hpp_init_nsga2,
    }

    master_dir = "Master_Results"
    os.makedirs(master_dir, exist_ok=True)

    all_summary_full = []
    all_summary_report = []

    for N in test_scales:
        folder_name = f"Results_N{N}"
        os.makedirs(folder_name, exist_ok=True)

        print(f"\n\n{'=' * 80}\n🚀 开始基准测试 | 规模 N = {N} | 目标文件夹: {folder_name}\n{'=' * 80}")
        set_environment_for_N(N)

        run_rows_full = []
        run_rows_report = []
        key_chrom_rows_full = []
        key_chrom_rows_report = []

        for i in range(1, num_runs + 1):
            seed = 42 + i
            print(f"Run {i:02d}/{num_runs} |", end=" ", flush=True)

            for algo_name, algo_func in algorithms.items():
                print(f"{algo_name[:6]}...", end=" ", flush=True)
                pareto_front, pareto_objs, rt, history_cost, conv_gen = algo_func(seed, N)

                # 完整内部前沿
                export_frontier_bundle(pareto_front, pareto_objs, algo_name, N, i, 'FULL', folder_name, pen_cap=None)
                run_rows_full.append(build_run_row(N, i, algo_name, pareto_front, pareto_objs, rt, conv_gen, hv_ref, 'FULL', pen_cap=None))
                if algo_name == 'HPP-init-NSGA2':
                    key_chrom_rows_full.extend(collect_key_chromosomes(pareto_front, pareto_objs, algo_name, N, i))

                # 报告前沿
                rep_front, rep_objs, pen_cap = filter_report_front(pareto_front, pareto_objs)
                export_frontier_bundle(rep_front, rep_objs, algo_name, N, i, 'REPORT', folder_name, pen_cap=pen_cap)
                run_rows_report.append(build_run_row(N, i, algo_name, rep_front, rep_objs, rt, conv_gen, hv_ref, 'REPORT', pen_cap=pen_cap))
                if algo_name == 'HPP-init-NSGA2':
                    key_chrom_rows_report.extend(collect_key_chromosomes(rep_front, rep_objs, algo_name, N, i))

            print(" Done.")

        # Run-level
        run_df_full = pd.DataFrame(run_rows_full)
        run_df_report = pd.DataFrame(run_rows_report)
        run_df_full.to_csv(os.path.join(folder_name, f"Run_Level_Metrics_Full_N{N}.csv"), index=False)
        run_df_report.to_csv(os.path.join(folder_name, f"Run_Level_Metrics_Report_N{N}.csv"), index=False)

        # Key chromosomes
        key_df_full = pd.DataFrame(key_chrom_rows_full)
        key_df_report = pd.DataFrame(key_chrom_rows_report)
        key_df_full.to_csv(os.path.join(folder_name, f"Key_Chromosomes_Full_N{N}.csv"), index=False)
        key_df_report.to_csv(os.path.join(folder_name, f"Key_Chromosomes_Report_N{N}.csv"), index=False)
        export_key_chromosome_plots(key_df_full, folder_name)
        export_key_chromosome_plots(key_df_report, folder_name)

        # Scale summaries
        scale_full = build_scale_summary(run_df_full, 'FULL')
        scale_report = build_scale_summary(run_df_report, 'REPORT')
        scale_full.to_csv(os.path.join(folder_name, f"Scale_Summary_Full_N{N}.csv"), index=False)
        scale_report.to_csv(os.path.join(folder_name, f"Scale_Summary_Report_N{N}.csv"), index=False)

        if not scale_full.empty:
            all_summary_full.extend(scale_full.to_dict('records'))
        if not scale_report.empty:
            all_summary_report.extend(scale_report.to_dict('records'))

    pd.DataFrame(all_summary_full).to_csv(os.path.join(master_dir, 'Algorithm_Scale_Summary_Full.csv'), index=False)
    pd.DataFrame(all_summary_report).to_csv(os.path.join(master_dir, 'Algorithm_Scale_Summary_Report.csv'), index=False)
    print("\n✅ 完成。已同时输出 FULL 内部前沿 与 REPORT 报告前沿。")


if __name__ == '__main__': main()