# Reproducibility Package for Revised Manuscript

This package contains the public materials needed to support the revised computational experiments.

## Included materials

- `generated_instance_list_revised.csv`: generated-instance list and resource settings.
- `code_core_examples/`: selected core code and experiment scripts for parameter calibration and calibrated MOPSO comparison.
- `results_public/`: updated result tables supporting the revised computational experiments.
- `docs/section_6_1_full_parameter_calibration_public.md`: full parameter-calibration summary and supporting records.

## Scope

The package includes selected code needed to understand and reproduce the revised experiments. It does not include manuscript-editing scripts, local temporary files, full development history, or other materials unrelated to the public reproducibility record.

## Experiments Covered

- Improved NSGA-II Taguchi L9 parameter configuration.
- Improved NSGA-II boundary and cross-instance checks.
- MOPSO Taguchi L9 parameter configuration.
- MOPSO local boundary check.
- Calibrated MOPSO rerun for the medium- and large-scale algorithm-comparison table.

## Notes

The raw Solomon benchmark data are publicly available benchmark instances. The processed instance list and resource configurations used in the manuscript are provided in `generated_instance_list_revised.csv`.
