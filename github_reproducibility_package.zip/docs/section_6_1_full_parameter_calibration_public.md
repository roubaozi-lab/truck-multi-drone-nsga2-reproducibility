# Full Parameter Calibration Summary

This document summarizes the parameter-calibration and supplementary checks described in Section 6.1 of the revised manuscript. The public result tables in this package report objective-performance and selection-score values used to support the revised computational experiments.

## Improved NSGA-II

The improved NSGA-II calibration uses a Taguchi L9 orthogonal design. The selected setting is:

- Pc = 0.60
- Pm = 0.15
- Npop = 100
- ER = 0.15

Additional boundary and cross-instance checks are provided in `results_public/nsga2_boundary_cross_instance`.

## MOPSO Baseline

The MOPSO baseline calibration uses a Taguchi L9 orthogonal design under the same population and generation budget used for the algorithm comparison. The selected setting is:

- P_PBest = 0.20
- P_Leader = 0.60
- P_Mutation = 0.10
- Archive capacity = 50

The MOPSO Taguchi results, local boundary check, and calibrated Table 8 rerun outputs are provided in `results_public`.

## Selection Score

The normalized selection score jointly considers Pareto-front quality, solution diversity, and objective performance. Hypervolume and non-dominated-front size are benefit indicators, while total cost, maximum completion time, and service delay are cost indicators.
